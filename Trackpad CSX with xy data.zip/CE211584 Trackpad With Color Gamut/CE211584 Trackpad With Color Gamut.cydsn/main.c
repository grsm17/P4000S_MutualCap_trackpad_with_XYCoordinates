/******************************************************************************
* File Name: main.c
*
* Version: 2.00
*
* Description:  This code example demonstrates how to use CapSense trackpad 
*               to input RGB color code for color mixing with PSoC 4 S-Series device.
*
* Related Document: CE211584 Trackpad with Color Gamut.pdf
*
* Hardware Dependency: See code example document CE211584 Trackpad with Color Gamut.pdf
*
******************************************************************************
* Copyright (2016), Cypress Semiconductor Corporation.
******************************************************************************
* This software, including source code, documentation and related materials
* ("Software") is owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and 
* foreign), United States copyright laws and international treaty provisions. 
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the 
* Cypress source code and derivative works for the sole purpose of creating 
* custom software in support of licensee product, such licensee product to be
* used only in conjunction with Cypress's integrated circuit as specified in the
* applicable agreement. Any reproduction, modification, translation, compilation,
* or representation of this Software except as specified above is prohibited 
* without the express written permission of Cypress.
* 
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, 
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes to the Software without notice. 
* Cypress does not assume any liability arising out of the application or use
* of Software or any product or circuit described in the Software. Cypress does
* not authorize its products for use as critical components in any products 
* where a malfunction or failure may reasonably be expected to result in 
* significant injury or death ("ACTIVE Risk Product"). By including Cypress's 
* product in a ACTIVE Risk Product, the manufacturer of such system or application
* assumes all risk of such use and in doing so indemnifies Cypress against all
* liability. Use of this Software may be limited by and subject to the applicable
* Cypress software license agreement.
*****************************************************************************/
/*******************************************************************************
*   Included Headers
*******************************************************************************/
#include <project.h>

/* Include boolean function definition */
#include <stdbool.h>



/* Include sprintf API definitions */
#include <stdio.h>

//#define TUNER   1     //enable this line to use tuner on i2c port.otherwise use standard i2c port


struct {
	uint16 xpos0;
    uint16 xpos1;
	uint16 ypos0;
    uint16 ypos1;
    //uint8  touchid[2];
	uint8  status;
} i2c_buffer;

/******************************************************************************
* Function Name: main
*******************************************************************************
*
* Summary: This function implements the state machine for device operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Theory: 
*   main() performs following functions:
*  1: Initialize the CapSense, EZI2C and PWM Components
*  2: Scans trackpad, buttons and performs color mixing and brightness control using
*     RGB LED
* 
* Side Effects: None
*
* Note:None
*
*******************************************************************************/

int main()
{    
    
    
   
    /* Enable interrupts. This is required for CapSense and I2C operation */ 
    CyGlobalIntEnable; 
    
    /* Initialize I2C component for CapSense tuner */
    EZI2C_Start();
    
    /* Set up communication data buffer to CapSense data structure to 
    * expose to I2C master at primary slave address request
    */
    
    #ifdef TUNER 
    EZI2C_EzI2CSetBuffer1(sizeof(CapSense_dsRam), sizeof(CapSense_dsRam),\
                         (uint8 *)&CapSense_dsRam);
    #else
    
    EZI2C_EzI2CSetBuffer1(sizeof(i2c_buffer), 0, &i2c_buffer);
    
    #endif

    /* Initialize CapSense block */
    CapSense_Start();
    
    CapSense_InitializeAllBaselines();
    
    for(;;)
    {        
        
                /* Initiate new scan only if the CapSense hardware is idle */
                if(CapSense_NOT_BUSY == CapSense_IsBusy())
                {
                    
                    #ifdef TUNER
                    /* Update CapSense parameters set via CapSense tuner */
                    CapSense_RunTuner();   
                    
                    #endif
                    
                    /*Scan trackpad and buttons*/
                    CapSense_ScanAllWidgets();
        
                    CapSense_ProcessAllWidgets();
                    
                    
               
                }
                
                #ifndef TUNER
                if(CapSense_IsAnyWidgetActive())
                {
                    
                    i2c_buffer.status=1;
                    
                    if((CapSense_dsRam.wdgtList.trackpad.touch[0].x | CapSense_dsRam.wdgtList.trackpad.touch[0].y) != 0xffff)
                    {
                    //i2c_buffer.touchid[0] = CapSense_dsRam.wdgtList.trackpad.touch[0u].id;
                    i2c_buffer.xpos0 = CapSense_dsRam.wdgtList.trackpad.touch[0].x;
                    i2c_buffer.ypos0 = CapSense_dsRam.wdgtList.trackpad.touch[0].y;
                    }
                    
                    if((CapSense_dsRam.wdgtList.trackpad.touch[1].x | CapSense_dsRam.wdgtList.trackpad.touch[1].y) != 0xffff)
                    {
                   // i2c_buffer.touchid[1] = CapSense_dsRam.wdgtList.trackpad.touch[1u].id;
                    i2c_buffer.xpos1 = CapSense_dsRam.wdgtList.trackpad.touch[1].x;
                    i2c_buffer.ypos1 = CapSense_dsRam.wdgtList.trackpad.touch[1].y;
                    }
                }
    
                else
                {
                   i2c_buffer.status=0; 
                }
                    
                #endif

    }
}
