/*******************************************************************************
* File Name: SHIELD_GND.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SHIELD_GND_ALIASES_H) /* Pins SHIELD_GND_ALIASES_H */
#define CY_PINS_SHIELD_GND_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define SHIELD_GND_0			(SHIELD_GND__0__PC)
#define SHIELD_GND_0_PS		(SHIELD_GND__0__PS)
#define SHIELD_GND_0_PC		(SHIELD_GND__0__PC)
#define SHIELD_GND_0_DR		(SHIELD_GND__0__DR)
#define SHIELD_GND_0_SHIFT	(SHIELD_GND__0__SHIFT)
#define SHIELD_GND_0_INTR	((uint16)((uint16)0x0003u << (SHIELD_GND__0__SHIFT*2u)))

#define SHIELD_GND_INTR_ALL	 ((uint16)(SHIELD_GND_0_INTR))


#endif /* End Pins SHIELD_GND_ALIASES_H */


/* [] END OF FILE */
