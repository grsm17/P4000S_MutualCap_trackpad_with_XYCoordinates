/*******************************************************************************
* File Name: PrISM_Blue_PM.c
* Version 2.10
*
* Description:
*  This file contains the setup, control, and status commands to support
*  the component operations in the low power mode.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "PrISM_Blue.h"

static PrISM_Blue_BACKUP_STRUCT PrISM_Blue_backup;


/*******************************************************************************
* Function Name: PrISM_Blue_SaveConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to save here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PrISM_Blue_SaveConfig(void)
{

}


/*******************************************************************************
* Function Name: PrISM_Blue_Sleep
********************************************************************************
*
* Summary:
*  Stops the component operation and saves the user configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PrISM_Blue_Sleep(void)
{
    if(0u != (PrISM_Blue_BLOCK_CONTROL_REG & PrISM_Blue_MASK))
    {
        PrISM_Blue_backup.enableState = 1u;
    }
    else
    {
        PrISM_Blue_backup.enableState = 0u;
    }

    PrISM_Blue_Stop();
    PrISM_Blue_SaveConfig();
}


/*******************************************************************************
* Function Name: PrISM_Blue_RestoreConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to restore here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PrISM_Blue_RestoreConfig(void)
{

}


/*******************************************************************************
* Function Name: PrISM_Blue_Wakeup
********************************************************************************
*
* Summary:
*  Restores the user configuration and restores the enable state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PrISM_Blue_Wakeup(void)
{
    PrISM_Blue_RestoreConfig();

    if(0u != PrISM_Blue_backup.enableState)
    {
        PrISM_Blue_Enable();
    }
}


/* [] END OF FILE */
