/***************************************************************************//**
* \file CapSense_RegisterMap.h
* \version 3.10
*
* \brief
*   This file provides the definitions for the component data structure register.
*
* \see CapSense P4 v3.10 Datasheet
*
*//*****************************************************************************
* Copyright (2016), Cypress Semiconductor Corporation.
********************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and
* foreign), United States copyright laws and international treaty provisions.
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the
* Cypress Source Code and derivative works for the sole purpose of creating
* custom software in support of licensee product to be used only in conjunction
* with a Cypress integrated circuit as specified in the applicable agreement.
* Any reproduction, modification, translation, compilation, or representation of
* this software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the
* materials described herein. Cypress does not assume any liability arising out
* of the application or use of any product or circuit described herein. Cypress
* does not authorize its products for use as critical components in life-support
* systems where a malfunction or failure may reasonably be expected to result in
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of
* such use and in doing so indemnifies Cypress against all charges. Use may be
* limited by and subject to the applicable Cypress software license agreement.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CapSense_REGISTER_MAP_H)
#define CY_CAPSENSE_CapSense_REGISTER_MAP_H

#include <cytypes.h>
#include "CapSense_Configuration.h"
#include "CapSense_Structure.h"

/*****************************************************************************/
/* RAM Data structure register definitions                                   */
/*****************************************************************************/
#define CapSense_CONFIG_ID_VALUE                            (CapSense_dsRam.configId)
#define CapSense_CONFIG_ID_OFFSET                           (0u)
#define CapSense_CONFIG_ID_SIZE                             (2u)
#define CapSense_CONFIG_ID_PARAM_ID                         (0x87000000u)

#define CapSense_DEVICE_ID_VALUE                            (CapSense_dsRam.deviceId)
#define CapSense_DEVICE_ID_OFFSET                           (2u)
#define CapSense_DEVICE_ID_SIZE                             (2u)
#define CapSense_DEVICE_ID_PARAM_ID                         (0x8B000002u)

#define CapSense_TUNER_CMD_VALUE                            (CapSense_dsRam.tunerCmd)
#define CapSense_TUNER_CMD_OFFSET                           (4u)
#define CapSense_TUNER_CMD_SIZE                             (2u)
#define CapSense_TUNER_CMD_PARAM_ID                         (0xAD000004u)

#define CapSense_SCAN_COUNTER_VALUE                         (CapSense_dsRam.scanCounter)
#define CapSense_SCAN_COUNTER_OFFSET                        (6u)
#define CapSense_SCAN_COUNTER_SIZE                          (2u)
#define CapSense_SCAN_COUNTER_PARAM_ID                      (0x8A000006u)

#define CapSense_STATUS_VALUE                               (CapSense_dsRam.status)
#define CapSense_STATUS_OFFSET                              (8u)
#define CapSense_STATUS_SIZE                                (4u)
#define CapSense_STATUS_PARAM_ID                            (0xCA000008u)

#define CapSense_WDGT_ENABLE0_VALUE                         (CapSense_dsRam.wdgtEnable[0u])
#define CapSense_WDGT_ENABLE0_OFFSET                        (12u)
#define CapSense_WDGT_ENABLE0_SIZE                          (4u)
#define CapSense_WDGT_ENABLE0_PARAM_ID                      (0xE000000Cu)

#define CapSense_WDGT_STATUS0_VALUE                         (CapSense_dsRam.wdgtStatus[0u])
#define CapSense_WDGT_STATUS0_OFFSET                        (16u)
#define CapSense_WDGT_STATUS0_SIZE                          (4u)
#define CapSense_WDGT_STATUS0_PARAM_ID                      (0xCD000010u)

#define CapSense_SNS_STATUS0_VALUE                          (CapSense_dsRam.snsStatus[0u])
#define CapSense_SNS_STATUS0_OFFSET                         (20u)
#define CapSense_SNS_STATUS0_SIZE                           (1u)
#define CapSense_SNS_STATUS0_PARAM_ID                       (0x4B000014u)

#define CapSense_CSD0_CONFIG_VALUE                          (CapSense_dsRam.csd0Config)
#define CapSense_CSD0_CONFIG_OFFSET                         (22u)
#define CapSense_CSD0_CONFIG_SIZE                           (2u)
#define CapSense_CSD0_CONFIG_PARAM_ID                       (0xA9800016u)

#define CapSense_MOD_CSX_CLK_VALUE                          (CapSense_dsRam.modCsxClk)
#define CapSense_MOD_CSX_CLK_OFFSET                         (24u)
#define CapSense_MOD_CSX_CLK_SIZE                           (1u)
#define CapSense_MOD_CSX_CLK_PARAM_ID                       (0x6E800018u)

#define CapSense_SNS_CSX_CLK_VALUE                          (CapSense_dsRam.snsCsxClk)
#define CapSense_SNS_CSX_CLK_OFFSET                         (25u)
#define CapSense_SNS_CSX_CLK_SIZE                           (1u)
#define CapSense_SNS_CSX_CLK_PARAM_ID                       (0x68800019u)

#define CapSense_TRACKPAD_RESOLUTION_VALUE                  (CapSense_dsRam.wdgtList.trackpad.resolution)
#define CapSense_TRACKPAD_RESOLUTION_OFFSET                 (28u)
#define CapSense_TRACKPAD_RESOLUTION_SIZE                   (2u)
#define CapSense_TRACKPAD_RESOLUTION_PARAM_ID               (0xA780001Cu)

#define CapSense_TRACKPAD_FINGER_TH_VALUE                   (CapSense_dsRam.wdgtList.trackpad.fingerTh)
#define CapSense_TRACKPAD_FINGER_TH_OFFSET                  (30u)
#define CapSense_TRACKPAD_FINGER_TH_SIZE                    (2u)
#define CapSense_TRACKPAD_FINGER_TH_PARAM_ID                (0xAB80001Eu)

#define CapSense_TRACKPAD_NOISE_TH_VALUE                    (CapSense_dsRam.wdgtList.trackpad.noiseTh)
#define CapSense_TRACKPAD_NOISE_TH_OFFSET                   (32u)
#define CapSense_TRACKPAD_NOISE_TH_SIZE                     (1u)
#define CapSense_TRACKPAD_NOISE_TH_PARAM_ID                 (0x63800020u)

#define CapSense_TRACKPAD_NNOISE_TH_VALUE                   (CapSense_dsRam.wdgtList.trackpad.nNoiseTh)
#define CapSense_TRACKPAD_NNOISE_TH_OFFSET                  (33u)
#define CapSense_TRACKPAD_NNOISE_TH_SIZE                    (1u)
#define CapSense_TRACKPAD_NNOISE_TH_PARAM_ID                (0x65800021u)

#define CapSense_TRACKPAD_HYSTERESIS_VALUE                  (CapSense_dsRam.wdgtList.trackpad.hysteresis)
#define CapSense_TRACKPAD_HYSTERESIS_OFFSET                 (34u)
#define CapSense_TRACKPAD_HYSTERESIS_SIZE                   (1u)
#define CapSense_TRACKPAD_HYSTERESIS_PARAM_ID               (0x6F800022u)

#define CapSense_TRACKPAD_ON_DEBOUNCE_VALUE                 (CapSense_dsRam.wdgtList.trackpad.onDebounce)
#define CapSense_TRACKPAD_ON_DEBOUNCE_OFFSET                (35u)
#define CapSense_TRACKPAD_ON_DEBOUNCE_SIZE                  (1u)
#define CapSense_TRACKPAD_ON_DEBOUNCE_PARAM_ID              (0x69800023u)

#define CapSense_TRACKPAD_LOW_BSLN_RST_VALUE                (CapSense_dsRam.wdgtList.trackpad.lowBslnRst)
#define CapSense_TRACKPAD_LOW_BSLN_RST_OFFSET               (36u)
#define CapSense_TRACKPAD_LOW_BSLN_RST_SIZE                 (1u)
#define CapSense_TRACKPAD_LOW_BSLN_RST_PARAM_ID             (0x62800024u)

#define CapSense_TRACKPAD_BSLN_COEFF_VALUE                  (CapSense_dsRam.wdgtList.trackpad.bslnCoeff)
#define CapSense_TRACKPAD_BSLN_COEFF_OFFSET                 (37u)
#define CapSense_TRACKPAD_BSLN_COEFF_SIZE                   (1u)
#define CapSense_TRACKPAD_BSLN_COEFF_PARAM_ID               (0x64800025u)

#define CapSense_TRACKPAD_SNS_CLK_SOURCE_VALUE              (CapSense_dsRam.wdgtList.trackpad.snsClkSource)
#define CapSense_TRACKPAD_SNS_CLK_SOURCE_OFFSET             (38u)
#define CapSense_TRACKPAD_SNS_CLK_SOURCE_SIZE               (1u)
#define CapSense_TRACKPAD_SNS_CLK_SOURCE_PARAM_ID           (0x45800026u)

#define CapSense_TRACKPAD_VELOCITY_VALUE                    (CapSense_dsRam.wdgtList.trackpad.velocity)
#define CapSense_TRACKPAD_VELOCITY_OFFSET                   (40u)
#define CapSense_TRACKPAD_VELOCITY_SIZE                     (4u)
#define CapSense_TRACKPAD_VELOCITY_PARAM_ID                 (0xEB000028u)

#define CapSense_TRACKPAD_TOUCH0_X_VALUE                    (CapSense_dsRam.wdgtList.trackpad.touch[0u].x)
#define CapSense_TRACKPAD_TOUCH0_X_OFFSET                   (44u)
#define CapSense_TRACKPAD_TOUCH0_X_SIZE                     (2u)
#define CapSense_TRACKPAD_TOUCH0_X_PARAM_ID                 (0x8E00002Cu)

#define CapSense_TRACKPAD_TOUCH0_Y_VALUE                    (CapSense_dsRam.wdgtList.trackpad.touch[0u].y)
#define CapSense_TRACKPAD_TOUCH0_Y_OFFSET                   (46u)
#define CapSense_TRACKPAD_TOUCH0_Y_SIZE                     (2u)
#define CapSense_TRACKPAD_TOUCH0_Y_PARAM_ID                 (0x8200002Eu)

#define CapSense_TRACKPAD_TOUCH0_Z_VALUE                    (CapSense_dsRam.wdgtList.trackpad.touch[0u].z)
#define CapSense_TRACKPAD_TOUCH0_Z_OFFSET                   (48u)
#define CapSense_TRACKPAD_TOUCH0_Z_SIZE                     (1u)
#define CapSense_TRACKPAD_TOUCH0_Z_PARAM_ID                 (0x40000030u)

#define CapSense_TRACKPAD_TOUCH0_ID_VALUE                   (CapSense_dsRam.wdgtList.trackpad.touch[0u].id)
#define CapSense_TRACKPAD_TOUCH0_ID_OFFSET                  (49u)
#define CapSense_TRACKPAD_TOUCH0_ID_SIZE                    (1u)
#define CapSense_TRACKPAD_TOUCH0_ID_PARAM_ID                (0x46000031u)

#define CapSense_TRACKPAD_TOUCH1_X_VALUE                    (CapSense_dsRam.wdgtList.trackpad.touch[1u].x)
#define CapSense_TRACKPAD_TOUCH1_X_OFFSET                   (50u)
#define CapSense_TRACKPAD_TOUCH1_X_SIZE                     (2u)
#define CapSense_TRACKPAD_TOUCH1_X_PARAM_ID                 (0x84000032u)

#define CapSense_TRACKPAD_TOUCH1_Y_VALUE                    (CapSense_dsRam.wdgtList.trackpad.touch[1u].y)
#define CapSense_TRACKPAD_TOUCH1_Y_OFFSET                   (52u)
#define CapSense_TRACKPAD_TOUCH1_Y_SIZE                     (2u)
#define CapSense_TRACKPAD_TOUCH1_Y_PARAM_ID                 (0x89000034u)

#define CapSense_TRACKPAD_TOUCH1_Z_VALUE                    (CapSense_dsRam.wdgtList.trackpad.touch[1u].z)
#define CapSense_TRACKPAD_TOUCH1_Z_OFFSET                   (54u)
#define CapSense_TRACKPAD_TOUCH1_Z_SIZE                     (1u)
#define CapSense_TRACKPAD_TOUCH1_Z_PARAM_ID                 (0x4D000036u)

#define CapSense_TRACKPAD_TOUCH1_ID_VALUE                   (CapSense_dsRam.wdgtList.trackpad.touch[1u].id)
#define CapSense_TRACKPAD_TOUCH1_ID_OFFSET                  (55u)
#define CapSense_TRACKPAD_TOUCH1_ID_SIZE                    (1u)
#define CapSense_TRACKPAD_TOUCH1_ID_PARAM_ID                (0x4B000037u)

#define CapSense_TRACKPAD_RX0_TX0_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[0u].raw[0u])
#define CapSense_TRACKPAD_RX0_TX0_RAW0_OFFSET               (56u)
#define CapSense_TRACKPAD_RX0_TX0_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX0_RAW0_PARAM_ID             (0x8A000038u)

#define CapSense_TRACKPAD_RX0_TX0_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[0u].raw[1u])
#define CapSense_TRACKPAD_RX0_TX0_RAW1_OFFSET               (58u)
#define CapSense_TRACKPAD_RX0_TX0_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX0_RAW1_PARAM_ID             (0x8600003Au)

#define CapSense_TRACKPAD_RX0_TX0_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[0u].raw[2u])
#define CapSense_TRACKPAD_RX0_TX0_RAW2_OFFSET               (60u)
#define CapSense_TRACKPAD_RX0_TX0_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX0_RAW2_PARAM_ID             (0x8B00003Cu)

#define CapSense_TRACKPAD_RX0_TX0_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[0u].bsln[0u])
#define CapSense_TRACKPAD_RX0_TX0_BSLN0_OFFSET              (62u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN0_PARAM_ID            (0x8700003Eu)

#define CapSense_TRACKPAD_RX0_TX0_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[0u].bsln[1u])
#define CapSense_TRACKPAD_RX0_TX0_BSLN1_OFFSET              (64u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN1_PARAM_ID            (0x8A000040u)

#define CapSense_TRACKPAD_RX0_TX0_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[0u].bsln[2u])
#define CapSense_TRACKPAD_RX0_TX0_BSLN2_OFFSET              (66u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN2_PARAM_ID            (0x86000042u)

#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[0u].bslnExt[0u])
#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT0_OFFSET          (68u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT0_PARAM_ID        (0x43000044u)

#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[0u].bslnExt[1u])
#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT1_OFFSET          (69u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT1_PARAM_ID        (0x45000045u)

#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[0u].bslnExt[2u])
#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT2_OFFSET          (70u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX0_BSLN_EXT2_PARAM_ID        (0x4F000046u)

#define CapSense_TRACKPAD_RX0_TX0_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[0u].diff)
#define CapSense_TRACKPAD_RX0_TX0_DIFF_OFFSET               (72u)
#define CapSense_TRACKPAD_RX0_TX0_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX0_DIFF_PARAM_ID             (0x88000048u)

#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[0u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT0_OFFSET  (74u)
#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT0_PARAM_ID (0x4C00004Au)

#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[0u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT1_OFFSET  (75u)
#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT1_PARAM_ID (0x4A00004Bu)

#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[0u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT2_OFFSET  (76u)
#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX0_NEG_BSLN_RST_CNT2_PARAM_ID (0x4100004Cu)

#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[0u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT0_OFFSET  (78u)
#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT0_PARAM_ID (0x8500004Eu)

#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[0u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT1_OFFSET  (80u)
#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT1_PARAM_ID (0x8F000050u)

#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[0u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT2_OFFSET  (82u)
#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX0_POS_BLSN_RST_CNT2_PARAM_ID (0x83000052u)

#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[0u].idacComp[0u])
#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP0_OFFSET         (84u)
#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP0_PARAM_ID       (0x46000054u)

#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[0u].idacComp[1u])
#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP1_OFFSET         (85u)
#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP1_PARAM_ID       (0x40000055u)

#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[0u].idacComp[2u])
#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP2_OFFSET         (86u)
#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX0_IDAC_COMP2_PARAM_ID       (0x4A000056u)

#define CapSense_TRACKPAD_RX0_TX1_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[1u].raw[0u])
#define CapSense_TRACKPAD_RX0_TX1_RAW0_OFFSET               (88u)
#define CapSense_TRACKPAD_RX0_TX1_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX1_RAW0_PARAM_ID             (0x8D000058u)

#define CapSense_TRACKPAD_RX0_TX1_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[1u].raw[1u])
#define CapSense_TRACKPAD_RX0_TX1_RAW1_OFFSET               (90u)
#define CapSense_TRACKPAD_RX0_TX1_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX1_RAW1_PARAM_ID             (0x8100005Au)

#define CapSense_TRACKPAD_RX0_TX1_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[1u].raw[2u])
#define CapSense_TRACKPAD_RX0_TX1_RAW2_OFFSET               (92u)
#define CapSense_TRACKPAD_RX0_TX1_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX1_RAW2_PARAM_ID             (0x8C00005Cu)

#define CapSense_TRACKPAD_RX0_TX1_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[1u].bsln[0u])
#define CapSense_TRACKPAD_RX0_TX1_BSLN0_OFFSET              (94u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN0_PARAM_ID            (0x8000005Eu)

#define CapSense_TRACKPAD_RX0_TX1_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[1u].bsln[1u])
#define CapSense_TRACKPAD_RX0_TX1_BSLN1_OFFSET              (96u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN1_PARAM_ID            (0x80000060u)

#define CapSense_TRACKPAD_RX0_TX1_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[1u].bsln[2u])
#define CapSense_TRACKPAD_RX0_TX1_BSLN2_OFFSET              (98u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN2_PARAM_ID            (0x8C000062u)

#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[1u].bslnExt[0u])
#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT0_OFFSET          (100u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT0_PARAM_ID        (0x49000064u)

#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[1u].bslnExt[1u])
#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT1_OFFSET          (101u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT1_PARAM_ID        (0x4F000065u)

#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[1u].bslnExt[2u])
#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT2_OFFSET          (102u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX1_BSLN_EXT2_PARAM_ID        (0x45000066u)

#define CapSense_TRACKPAD_RX0_TX1_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[1u].diff)
#define CapSense_TRACKPAD_RX0_TX1_DIFF_OFFSET               (104u)
#define CapSense_TRACKPAD_RX0_TX1_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX1_DIFF_PARAM_ID             (0x82000068u)

#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[1u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT0_OFFSET  (106u)
#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT0_PARAM_ID (0x4600006Au)

#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[1u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT1_OFFSET  (107u)
#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT1_PARAM_ID (0x4000006Bu)

#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[1u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT2_OFFSET  (108u)
#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX1_NEG_BSLN_RST_CNT2_PARAM_ID (0x4B00006Cu)

#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[1u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT0_OFFSET  (110u)
#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT0_PARAM_ID (0x8F00006Eu)

#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[1u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT1_OFFSET  (112u)
#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT1_PARAM_ID (0x85000070u)

#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[1u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT2_OFFSET  (114u)
#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX1_POS_BLSN_RST_CNT2_PARAM_ID (0x89000072u)

#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[1u].idacComp[0u])
#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP0_OFFSET         (116u)
#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP0_PARAM_ID       (0x4C000074u)

#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[1u].idacComp[1u])
#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP1_OFFSET         (117u)
#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP1_PARAM_ID       (0x4A000075u)

#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[1u].idacComp[2u])
#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP2_OFFSET         (118u)
#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX1_IDAC_COMP2_PARAM_ID       (0x40000076u)

#define CapSense_TRACKPAD_RX0_TX2_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[2u].raw[0u])
#define CapSense_TRACKPAD_RX0_TX2_RAW0_OFFSET               (120u)
#define CapSense_TRACKPAD_RX0_TX2_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX2_RAW0_PARAM_ID             (0x87000078u)

#define CapSense_TRACKPAD_RX0_TX2_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[2u].raw[1u])
#define CapSense_TRACKPAD_RX0_TX2_RAW1_OFFSET               (122u)
#define CapSense_TRACKPAD_RX0_TX2_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX2_RAW1_PARAM_ID             (0x8B00007Au)

#define CapSense_TRACKPAD_RX0_TX2_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[2u].raw[2u])
#define CapSense_TRACKPAD_RX0_TX2_RAW2_OFFSET               (124u)
#define CapSense_TRACKPAD_RX0_TX2_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX2_RAW2_PARAM_ID             (0x8600007Cu)

#define CapSense_TRACKPAD_RX0_TX2_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[2u].bsln[0u])
#define CapSense_TRACKPAD_RX0_TX2_BSLN0_OFFSET              (126u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN0_PARAM_ID            (0x8A00007Eu)

#define CapSense_TRACKPAD_RX0_TX2_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[2u].bsln[1u])
#define CapSense_TRACKPAD_RX0_TX2_BSLN1_OFFSET              (128u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN1_PARAM_ID            (0x84000080u)

#define CapSense_TRACKPAD_RX0_TX2_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[2u].bsln[2u])
#define CapSense_TRACKPAD_RX0_TX2_BSLN2_OFFSET              (130u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN2_PARAM_ID            (0x88000082u)

#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[2u].bslnExt[0u])
#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT0_OFFSET          (132u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT0_PARAM_ID        (0x4D000084u)

#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[2u].bslnExt[1u])
#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT1_OFFSET          (133u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT1_PARAM_ID        (0x4B000085u)

#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[2u].bslnExt[2u])
#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT2_OFFSET          (134u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX2_BSLN_EXT2_PARAM_ID        (0x41000086u)

#define CapSense_TRACKPAD_RX0_TX2_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[2u].diff)
#define CapSense_TRACKPAD_RX0_TX2_DIFF_OFFSET               (136u)
#define CapSense_TRACKPAD_RX0_TX2_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX2_DIFF_PARAM_ID             (0x86000088u)

#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[2u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT0_OFFSET  (138u)
#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT0_PARAM_ID (0x4200008Au)

#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[2u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT1_OFFSET  (139u)
#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT1_PARAM_ID (0x4400008Bu)

#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[2u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT2_OFFSET  (140u)
#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX2_NEG_BSLN_RST_CNT2_PARAM_ID (0x4F00008Cu)

#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[2u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT0_OFFSET  (142u)
#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT0_PARAM_ID (0x8B00008Eu)

#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[2u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT1_OFFSET  (144u)
#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT1_PARAM_ID (0x81000090u)

#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[2u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT2_OFFSET  (146u)
#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX2_POS_BLSN_RST_CNT2_PARAM_ID (0x8D000092u)

#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[2u].idacComp[0u])
#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP0_OFFSET         (148u)
#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP0_PARAM_ID       (0x48000094u)

#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[2u].idacComp[1u])
#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP1_OFFSET         (149u)
#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP1_PARAM_ID       (0x4E000095u)

#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[2u].idacComp[2u])
#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP2_OFFSET         (150u)
#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX2_IDAC_COMP2_PARAM_ID       (0x44000096u)

#define CapSense_TRACKPAD_RX0_TX3_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[3u].raw[0u])
#define CapSense_TRACKPAD_RX0_TX3_RAW0_OFFSET               (152u)
#define CapSense_TRACKPAD_RX0_TX3_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX3_RAW0_PARAM_ID             (0x83000098u)

#define CapSense_TRACKPAD_RX0_TX3_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[3u].raw[1u])
#define CapSense_TRACKPAD_RX0_TX3_RAW1_OFFSET               (154u)
#define CapSense_TRACKPAD_RX0_TX3_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX3_RAW1_PARAM_ID             (0x8F00009Au)

#define CapSense_TRACKPAD_RX0_TX3_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[3u].raw[2u])
#define CapSense_TRACKPAD_RX0_TX3_RAW2_OFFSET               (156u)
#define CapSense_TRACKPAD_RX0_TX3_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX3_RAW2_PARAM_ID             (0x8200009Cu)

#define CapSense_TRACKPAD_RX0_TX3_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[3u].bsln[0u])
#define CapSense_TRACKPAD_RX0_TX3_BSLN0_OFFSET              (158u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN0_PARAM_ID            (0x8E00009Eu)

#define CapSense_TRACKPAD_RX0_TX3_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[3u].bsln[1u])
#define CapSense_TRACKPAD_RX0_TX3_BSLN1_OFFSET              (160u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN1_PARAM_ID            (0x8E0000A0u)

#define CapSense_TRACKPAD_RX0_TX3_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[3u].bsln[2u])
#define CapSense_TRACKPAD_RX0_TX3_BSLN2_OFFSET              (162u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN2_PARAM_ID            (0x820000A2u)

#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[3u].bslnExt[0u])
#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT0_OFFSET          (164u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT0_PARAM_ID        (0x470000A4u)

#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[3u].bslnExt[1u])
#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT1_OFFSET          (165u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT1_PARAM_ID        (0x410000A5u)

#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[3u].bslnExt[2u])
#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT2_OFFSET          (166u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX3_BSLN_EXT2_PARAM_ID        (0x4B0000A6u)

#define CapSense_TRACKPAD_RX0_TX3_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[3u].diff)
#define CapSense_TRACKPAD_RX0_TX3_DIFF_OFFSET               (168u)
#define CapSense_TRACKPAD_RX0_TX3_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX3_DIFF_PARAM_ID             (0x8C0000A8u)

#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[3u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT0_OFFSET  (170u)
#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT0_PARAM_ID (0x480000AAu)

#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[3u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT1_OFFSET  (171u)
#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT1_PARAM_ID (0x4E0000ABu)

#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[3u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT2_OFFSET  (172u)
#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX3_NEG_BSLN_RST_CNT2_PARAM_ID (0x450000ACu)

#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[3u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT0_OFFSET  (174u)
#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT0_PARAM_ID (0x810000AEu)

#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[3u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT1_OFFSET  (176u)
#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT1_PARAM_ID (0x8B0000B0u)

#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[3u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT2_OFFSET  (178u)
#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX3_POS_BLSN_RST_CNT2_PARAM_ID (0x870000B2u)

#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[3u].idacComp[0u])
#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP0_OFFSET         (180u)
#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP0_PARAM_ID       (0x420000B4u)

#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[3u].idacComp[1u])
#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP1_OFFSET         (181u)
#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP1_PARAM_ID       (0x440000B5u)

#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[3u].idacComp[2u])
#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP2_OFFSET         (182u)
#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX3_IDAC_COMP2_PARAM_ID       (0x4E0000B6u)

#define CapSense_TRACKPAD_RX0_TX4_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[4u].raw[0u])
#define CapSense_TRACKPAD_RX0_TX4_RAW0_OFFSET               (184u)
#define CapSense_TRACKPAD_RX0_TX4_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX4_RAW0_PARAM_ID             (0x890000B8u)

#define CapSense_TRACKPAD_RX0_TX4_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[4u].raw[1u])
#define CapSense_TRACKPAD_RX0_TX4_RAW1_OFFSET               (186u)
#define CapSense_TRACKPAD_RX0_TX4_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX4_RAW1_PARAM_ID             (0x850000BAu)

#define CapSense_TRACKPAD_RX0_TX4_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[4u].raw[2u])
#define CapSense_TRACKPAD_RX0_TX4_RAW2_OFFSET               (188u)
#define CapSense_TRACKPAD_RX0_TX4_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX4_RAW2_PARAM_ID             (0x880000BCu)

#define CapSense_TRACKPAD_RX0_TX4_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[4u].bsln[0u])
#define CapSense_TRACKPAD_RX0_TX4_BSLN0_OFFSET              (190u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN0_PARAM_ID            (0x840000BEu)

#define CapSense_TRACKPAD_RX0_TX4_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[4u].bsln[1u])
#define CapSense_TRACKPAD_RX0_TX4_BSLN1_OFFSET              (192u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN1_PARAM_ID            (0x890000C0u)

#define CapSense_TRACKPAD_RX0_TX4_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[4u].bsln[2u])
#define CapSense_TRACKPAD_RX0_TX4_BSLN2_OFFSET              (194u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN2_PARAM_ID            (0x850000C2u)

#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[4u].bslnExt[0u])
#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT0_OFFSET          (196u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT0_PARAM_ID        (0x400000C4u)

#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[4u].bslnExt[1u])
#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT1_OFFSET          (197u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT1_PARAM_ID        (0x460000C5u)

#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[4u].bslnExt[2u])
#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT2_OFFSET          (198u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX4_BSLN_EXT2_PARAM_ID        (0x4C0000C6u)

#define CapSense_TRACKPAD_RX0_TX4_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[4u].diff)
#define CapSense_TRACKPAD_RX0_TX4_DIFF_OFFSET               (200u)
#define CapSense_TRACKPAD_RX0_TX4_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX4_DIFF_PARAM_ID             (0x8B0000C8u)

#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[4u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT0_OFFSET  (202u)
#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT0_PARAM_ID (0x4F0000CAu)

#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[4u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT1_OFFSET  (203u)
#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT1_PARAM_ID (0x490000CBu)

#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[4u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT2_OFFSET  (204u)
#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX4_NEG_BSLN_RST_CNT2_PARAM_ID (0x420000CCu)

#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[4u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT0_OFFSET  (206u)
#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT0_PARAM_ID (0x860000CEu)

#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[4u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT1_OFFSET  (208u)
#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT1_PARAM_ID (0x8C0000D0u)

#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[4u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT2_OFFSET  (210u)
#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX4_POS_BLSN_RST_CNT2_PARAM_ID (0x800000D2u)

#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[4u].idacComp[0u])
#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP0_OFFSET         (212u)
#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP0_PARAM_ID       (0x450000D4u)

#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[4u].idacComp[1u])
#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP1_OFFSET         (213u)
#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP1_PARAM_ID       (0x430000D5u)

#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[4u].idacComp[2u])
#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP2_OFFSET         (214u)
#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX4_IDAC_COMP2_PARAM_ID       (0x490000D6u)

#define CapSense_TRACKPAD_RX0_TX5_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[5u].raw[0u])
#define CapSense_TRACKPAD_RX0_TX5_RAW0_OFFSET               (216u)
#define CapSense_TRACKPAD_RX0_TX5_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX5_RAW0_PARAM_ID             (0x8E0000D8u)

#define CapSense_TRACKPAD_RX0_TX5_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[5u].raw[1u])
#define CapSense_TRACKPAD_RX0_TX5_RAW1_OFFSET               (218u)
#define CapSense_TRACKPAD_RX0_TX5_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX5_RAW1_PARAM_ID             (0x820000DAu)

#define CapSense_TRACKPAD_RX0_TX5_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[5u].raw[2u])
#define CapSense_TRACKPAD_RX0_TX5_RAW2_OFFSET               (220u)
#define CapSense_TRACKPAD_RX0_TX5_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX5_RAW2_PARAM_ID             (0x8F0000DCu)

#define CapSense_TRACKPAD_RX0_TX5_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[5u].bsln[0u])
#define CapSense_TRACKPAD_RX0_TX5_BSLN0_OFFSET              (222u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN0_PARAM_ID            (0x830000DEu)

#define CapSense_TRACKPAD_RX0_TX5_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[5u].bsln[1u])
#define CapSense_TRACKPAD_RX0_TX5_BSLN1_OFFSET              (224u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN1_PARAM_ID            (0x830000E0u)

#define CapSense_TRACKPAD_RX0_TX5_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[5u].bsln[2u])
#define CapSense_TRACKPAD_RX0_TX5_BSLN2_OFFSET              (226u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN2_PARAM_ID            (0x8F0000E2u)

#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[5u].bslnExt[0u])
#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT0_OFFSET          (228u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT0_PARAM_ID        (0x4A0000E4u)

#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[5u].bslnExt[1u])
#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT1_OFFSET          (229u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT1_PARAM_ID        (0x4C0000E5u)

#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[5u].bslnExt[2u])
#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT2_OFFSET          (230u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX5_BSLN_EXT2_PARAM_ID        (0x460000E6u)

#define CapSense_TRACKPAD_RX0_TX5_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[5u].diff)
#define CapSense_TRACKPAD_RX0_TX5_DIFF_OFFSET               (232u)
#define CapSense_TRACKPAD_RX0_TX5_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX5_DIFF_PARAM_ID             (0x810000E8u)

#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[5u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT0_OFFSET  (234u)
#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT0_PARAM_ID (0x450000EAu)

#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[5u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT1_OFFSET  (235u)
#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT1_PARAM_ID (0x430000EBu)

#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[5u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT2_OFFSET  (236u)
#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX5_NEG_BSLN_RST_CNT2_PARAM_ID (0x480000ECu)

#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[5u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT0_OFFSET  (238u)
#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT0_PARAM_ID (0x8C0000EEu)

#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[5u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT1_OFFSET  (240u)
#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT1_PARAM_ID (0x860000F0u)

#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[5u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT2_OFFSET  (242u)
#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX5_POS_BLSN_RST_CNT2_PARAM_ID (0x8A0000F2u)

#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[5u].idacComp[0u])
#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP0_OFFSET         (244u)
#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP0_PARAM_ID       (0x4F0000F4u)

#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[5u].idacComp[1u])
#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP1_OFFSET         (245u)
#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP1_PARAM_ID       (0x490000F5u)

#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[5u].idacComp[2u])
#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP2_OFFSET         (246u)
#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX5_IDAC_COMP2_PARAM_ID       (0x430000F6u)

#define CapSense_TRACKPAD_RX0_TX6_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[6u].raw[0u])
#define CapSense_TRACKPAD_RX0_TX6_RAW0_OFFSET               (248u)
#define CapSense_TRACKPAD_RX0_TX6_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX6_RAW0_PARAM_ID             (0x840000F8u)

#define CapSense_TRACKPAD_RX0_TX6_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[6u].raw[1u])
#define CapSense_TRACKPAD_RX0_TX6_RAW1_OFFSET               (250u)
#define CapSense_TRACKPAD_RX0_TX6_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX6_RAW1_PARAM_ID             (0x880000FAu)

#define CapSense_TRACKPAD_RX0_TX6_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[6u].raw[2u])
#define CapSense_TRACKPAD_RX0_TX6_RAW2_OFFSET               (252u)
#define CapSense_TRACKPAD_RX0_TX6_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX6_RAW2_PARAM_ID             (0x850000FCu)

#define CapSense_TRACKPAD_RX0_TX6_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[6u].bsln[0u])
#define CapSense_TRACKPAD_RX0_TX6_BSLN0_OFFSET              (254u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN0_PARAM_ID            (0x890000FEu)

#define CapSense_TRACKPAD_RX0_TX6_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[6u].bsln[1u])
#define CapSense_TRACKPAD_RX0_TX6_BSLN1_OFFSET              (256u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN1_PARAM_ID            (0x8C000100u)

#define CapSense_TRACKPAD_RX0_TX6_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[6u].bsln[2u])
#define CapSense_TRACKPAD_RX0_TX6_BSLN2_OFFSET              (258u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN2_PARAM_ID            (0x80000102u)

#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[6u].bslnExt[0u])
#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT0_OFFSET          (260u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT0_PARAM_ID        (0x45000104u)

#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[6u].bslnExt[1u])
#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT1_OFFSET          (261u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT1_PARAM_ID        (0x43000105u)

#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[6u].bslnExt[2u])
#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT2_OFFSET          (262u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX0_TX6_BSLN_EXT2_PARAM_ID        (0x49000106u)

#define CapSense_TRACKPAD_RX0_TX6_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[6u].diff)
#define CapSense_TRACKPAD_RX0_TX6_DIFF_OFFSET               (264u)
#define CapSense_TRACKPAD_RX0_TX6_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX0_TX6_DIFF_PARAM_ID             (0x8E000108u)

#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[6u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT0_OFFSET  (266u)
#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT0_PARAM_ID (0x4A00010Au)

#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[6u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT1_OFFSET  (267u)
#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT1_PARAM_ID (0x4C00010Bu)

#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[6u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT2_OFFSET  (268u)
#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX0_TX6_NEG_BSLN_RST_CNT2_PARAM_ID (0x4700010Cu)

#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[6u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT0_OFFSET  (270u)
#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT0_PARAM_ID (0x8300010Eu)

#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[6u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT1_OFFSET  (272u)
#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT1_PARAM_ID (0x89000110u)

#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[6u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT2_OFFSET  (274u)
#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX0_TX6_POS_BLSN_RST_CNT2_PARAM_ID (0x85000112u)

#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[6u].idacComp[0u])
#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP0_OFFSET         (276u)
#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP0_PARAM_ID       (0x40000114u)

#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[6u].idacComp[1u])
#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP1_OFFSET         (277u)
#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP1_PARAM_ID       (0x46000115u)

#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[6u].idacComp[2u])
#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP2_OFFSET         (278u)
#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX0_TX6_IDAC_COMP2_PARAM_ID       (0x4C000116u)

#define CapSense_TRACKPAD_RX1_TX0_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[7u].raw[0u])
#define CapSense_TRACKPAD_RX1_TX0_RAW0_OFFSET               (280u)
#define CapSense_TRACKPAD_RX1_TX0_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX0_RAW0_PARAM_ID             (0x8B000118u)

#define CapSense_TRACKPAD_RX1_TX0_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[7u].raw[1u])
#define CapSense_TRACKPAD_RX1_TX0_RAW1_OFFSET               (282u)
#define CapSense_TRACKPAD_RX1_TX0_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX0_RAW1_PARAM_ID             (0x8700011Au)

#define CapSense_TRACKPAD_RX1_TX0_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[7u].raw[2u])
#define CapSense_TRACKPAD_RX1_TX0_RAW2_OFFSET               (284u)
#define CapSense_TRACKPAD_RX1_TX0_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX0_RAW2_PARAM_ID             (0x8A00011Cu)

#define CapSense_TRACKPAD_RX1_TX0_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[7u].bsln[0u])
#define CapSense_TRACKPAD_RX1_TX0_BSLN0_OFFSET              (286u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN0_PARAM_ID            (0x8600011Eu)

#define CapSense_TRACKPAD_RX1_TX0_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[7u].bsln[1u])
#define CapSense_TRACKPAD_RX1_TX0_BSLN1_OFFSET              (288u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN1_PARAM_ID            (0x86000120u)

#define CapSense_TRACKPAD_RX1_TX0_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[7u].bsln[2u])
#define CapSense_TRACKPAD_RX1_TX0_BSLN2_OFFSET              (290u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN2_PARAM_ID            (0x8A000122u)

#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[7u].bslnExt[0u])
#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT0_OFFSET          (292u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT0_PARAM_ID        (0x4F000124u)

#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[7u].bslnExt[1u])
#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT1_OFFSET          (293u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT1_PARAM_ID        (0x49000125u)

#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[7u].bslnExt[2u])
#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT2_OFFSET          (294u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX0_BSLN_EXT2_PARAM_ID        (0x43000126u)

#define CapSense_TRACKPAD_RX1_TX0_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[7u].diff)
#define CapSense_TRACKPAD_RX1_TX0_DIFF_OFFSET               (296u)
#define CapSense_TRACKPAD_RX1_TX0_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX0_DIFF_PARAM_ID             (0x84000128u)

#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[7u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT0_OFFSET  (298u)
#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT0_PARAM_ID (0x4000012Au)

#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[7u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT1_OFFSET  (299u)
#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT1_PARAM_ID (0x4600012Bu)

#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[7u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT2_OFFSET  (300u)
#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX0_NEG_BSLN_RST_CNT2_PARAM_ID (0x4D00012Cu)

#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[7u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT0_OFFSET  (302u)
#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT0_PARAM_ID (0x8900012Eu)

#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[7u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT1_OFFSET  (304u)
#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT1_PARAM_ID (0x83000130u)

#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[7u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT2_OFFSET  (306u)
#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX0_POS_BLSN_RST_CNT2_PARAM_ID (0x8F000132u)

#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[7u].idacComp[0u])
#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP0_OFFSET         (308u)
#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP0_PARAM_ID       (0x4A000134u)

#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[7u].idacComp[1u])
#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP1_OFFSET         (309u)
#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP1_PARAM_ID       (0x4C000135u)

#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[7u].idacComp[2u])
#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP2_OFFSET         (310u)
#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX0_IDAC_COMP2_PARAM_ID       (0x46000136u)

#define CapSense_TRACKPAD_RX1_TX1_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[8u].raw[0u])
#define CapSense_TRACKPAD_RX1_TX1_RAW0_OFFSET               (312u)
#define CapSense_TRACKPAD_RX1_TX1_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX1_RAW0_PARAM_ID             (0x81000138u)

#define CapSense_TRACKPAD_RX1_TX1_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[8u].raw[1u])
#define CapSense_TRACKPAD_RX1_TX1_RAW1_OFFSET               (314u)
#define CapSense_TRACKPAD_RX1_TX1_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX1_RAW1_PARAM_ID             (0x8D00013Au)

#define CapSense_TRACKPAD_RX1_TX1_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[8u].raw[2u])
#define CapSense_TRACKPAD_RX1_TX1_RAW2_OFFSET               (316u)
#define CapSense_TRACKPAD_RX1_TX1_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX1_RAW2_PARAM_ID             (0x8000013Cu)

#define CapSense_TRACKPAD_RX1_TX1_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[8u].bsln[0u])
#define CapSense_TRACKPAD_RX1_TX1_BSLN0_OFFSET              (318u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN0_PARAM_ID            (0x8C00013Eu)

#define CapSense_TRACKPAD_RX1_TX1_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[8u].bsln[1u])
#define CapSense_TRACKPAD_RX1_TX1_BSLN1_OFFSET              (320u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN1_PARAM_ID            (0x81000140u)

#define CapSense_TRACKPAD_RX1_TX1_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[8u].bsln[2u])
#define CapSense_TRACKPAD_RX1_TX1_BSLN2_OFFSET              (322u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN2_PARAM_ID            (0x8D000142u)

#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[8u].bslnExt[0u])
#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT0_OFFSET          (324u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT0_PARAM_ID        (0x48000144u)

#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[8u].bslnExt[1u])
#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT1_OFFSET          (325u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT1_PARAM_ID        (0x4E000145u)

#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[8u].bslnExt[2u])
#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT2_OFFSET          (326u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX1_BSLN_EXT2_PARAM_ID        (0x44000146u)

#define CapSense_TRACKPAD_RX1_TX1_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[8u].diff)
#define CapSense_TRACKPAD_RX1_TX1_DIFF_OFFSET               (328u)
#define CapSense_TRACKPAD_RX1_TX1_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX1_DIFF_PARAM_ID             (0x83000148u)

#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[8u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT0_OFFSET  (330u)
#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT0_PARAM_ID (0x4700014Au)

#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[8u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT1_OFFSET  (331u)
#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT1_PARAM_ID (0x4100014Bu)

#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[8u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT2_OFFSET  (332u)
#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX1_NEG_BSLN_RST_CNT2_PARAM_ID (0x4A00014Cu)

#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[8u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT0_OFFSET  (334u)
#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT0_PARAM_ID (0x8E00014Eu)

#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[8u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT1_OFFSET  (336u)
#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT1_PARAM_ID (0x84000150u)

#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[8u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT2_OFFSET  (338u)
#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX1_POS_BLSN_RST_CNT2_PARAM_ID (0x88000152u)

#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[8u].idacComp[0u])
#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP0_OFFSET         (340u)
#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP0_PARAM_ID       (0x4D000154u)

#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[8u].idacComp[1u])
#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP1_OFFSET         (341u)
#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP1_PARAM_ID       (0x4B000155u)

#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[8u].idacComp[2u])
#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP2_OFFSET         (342u)
#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX1_IDAC_COMP2_PARAM_ID       (0x41000156u)

#define CapSense_TRACKPAD_RX1_TX2_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[9u].raw[0u])
#define CapSense_TRACKPAD_RX1_TX2_RAW0_OFFSET               (344u)
#define CapSense_TRACKPAD_RX1_TX2_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX2_RAW0_PARAM_ID             (0x86000158u)

#define CapSense_TRACKPAD_RX1_TX2_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[9u].raw[1u])
#define CapSense_TRACKPAD_RX1_TX2_RAW1_OFFSET               (346u)
#define CapSense_TRACKPAD_RX1_TX2_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX2_RAW1_PARAM_ID             (0x8A00015Au)

#define CapSense_TRACKPAD_RX1_TX2_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[9u].raw[2u])
#define CapSense_TRACKPAD_RX1_TX2_RAW2_OFFSET               (348u)
#define CapSense_TRACKPAD_RX1_TX2_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX2_RAW2_PARAM_ID             (0x8700015Cu)

#define CapSense_TRACKPAD_RX1_TX2_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[9u].bsln[0u])
#define CapSense_TRACKPAD_RX1_TX2_BSLN0_OFFSET              (350u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN0_PARAM_ID            (0x8B00015Eu)

#define CapSense_TRACKPAD_RX1_TX2_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[9u].bsln[1u])
#define CapSense_TRACKPAD_RX1_TX2_BSLN1_OFFSET              (352u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN1_PARAM_ID            (0x8B000160u)

#define CapSense_TRACKPAD_RX1_TX2_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[9u].bsln[2u])
#define CapSense_TRACKPAD_RX1_TX2_BSLN2_OFFSET              (354u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN2_PARAM_ID            (0x87000162u)

#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[9u].bslnExt[0u])
#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT0_OFFSET          (356u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT0_PARAM_ID        (0x42000164u)

#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[9u].bslnExt[1u])
#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT1_OFFSET          (357u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT1_PARAM_ID        (0x44000165u)

#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[9u].bslnExt[2u])
#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT2_OFFSET          (358u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX2_BSLN_EXT2_PARAM_ID        (0x4E000166u)

#define CapSense_TRACKPAD_RX1_TX2_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[9u].diff)
#define CapSense_TRACKPAD_RX1_TX2_DIFF_OFFSET               (360u)
#define CapSense_TRACKPAD_RX1_TX2_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX2_DIFF_PARAM_ID             (0x89000168u)

#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[9u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT0_OFFSET  (362u)
#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT0_PARAM_ID (0x4D00016Au)

#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[9u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT1_OFFSET  (363u)
#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT1_PARAM_ID (0x4B00016Bu)

#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[9u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT2_OFFSET  (364u)
#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX2_NEG_BSLN_RST_CNT2_PARAM_ID (0x4000016Cu)

#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[9u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT0_OFFSET  (366u)
#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT0_PARAM_ID (0x8400016Eu)

#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[9u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT1_OFFSET  (368u)
#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT1_PARAM_ID (0x8E000170u)

#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[9u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT2_OFFSET  (370u)
#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX2_POS_BLSN_RST_CNT2_PARAM_ID (0x82000172u)

#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[9u].idacComp[0u])
#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP0_OFFSET         (372u)
#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP0_PARAM_ID       (0x47000174u)

#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[9u].idacComp[1u])
#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP1_OFFSET         (373u)
#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP1_PARAM_ID       (0x41000175u)

#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[9u].idacComp[2u])
#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP2_OFFSET         (374u)
#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX2_IDAC_COMP2_PARAM_ID       (0x4B000176u)

#define CapSense_TRACKPAD_RX1_TX3_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[10u].raw[0u])
#define CapSense_TRACKPAD_RX1_TX3_RAW0_OFFSET               (376u)
#define CapSense_TRACKPAD_RX1_TX3_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX3_RAW0_PARAM_ID             (0x8C000178u)

#define CapSense_TRACKPAD_RX1_TX3_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[10u].raw[1u])
#define CapSense_TRACKPAD_RX1_TX3_RAW1_OFFSET               (378u)
#define CapSense_TRACKPAD_RX1_TX3_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX3_RAW1_PARAM_ID             (0x8000017Au)

#define CapSense_TRACKPAD_RX1_TX3_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[10u].raw[2u])
#define CapSense_TRACKPAD_RX1_TX3_RAW2_OFFSET               (380u)
#define CapSense_TRACKPAD_RX1_TX3_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX3_RAW2_PARAM_ID             (0x8D00017Cu)

#define CapSense_TRACKPAD_RX1_TX3_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[10u].bsln[0u])
#define CapSense_TRACKPAD_RX1_TX3_BSLN0_OFFSET              (382u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN0_PARAM_ID            (0x8100017Eu)

#define CapSense_TRACKPAD_RX1_TX3_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[10u].bsln[1u])
#define CapSense_TRACKPAD_RX1_TX3_BSLN1_OFFSET              (384u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN1_PARAM_ID            (0x8F000180u)

#define CapSense_TRACKPAD_RX1_TX3_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[10u].bsln[2u])
#define CapSense_TRACKPAD_RX1_TX3_BSLN2_OFFSET              (386u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN2_PARAM_ID            (0x83000182u)

#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[10u].bslnExt[0u])
#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT0_OFFSET          (388u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT0_PARAM_ID        (0x46000184u)

#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[10u].bslnExt[1u])
#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT1_OFFSET          (389u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT1_PARAM_ID        (0x40000185u)

#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[10u].bslnExt[2u])
#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT2_OFFSET          (390u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX3_BSLN_EXT2_PARAM_ID        (0x4A000186u)

#define CapSense_TRACKPAD_RX1_TX3_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[10u].diff)
#define CapSense_TRACKPAD_RX1_TX3_DIFF_OFFSET               (392u)
#define CapSense_TRACKPAD_RX1_TX3_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX3_DIFF_PARAM_ID             (0x8D000188u)

#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[10u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT0_OFFSET  (394u)
#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT0_PARAM_ID (0x4900018Au)

#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[10u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT1_OFFSET  (395u)
#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT1_PARAM_ID (0x4F00018Bu)

#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[10u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT2_OFFSET  (396u)
#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX3_NEG_BSLN_RST_CNT2_PARAM_ID (0x4400018Cu)

#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[10u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT0_OFFSET  (398u)
#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT0_PARAM_ID (0x8000018Eu)

#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[10u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT1_OFFSET  (400u)
#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT1_PARAM_ID (0x8A000190u)

#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[10u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT2_OFFSET  (402u)
#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX3_POS_BLSN_RST_CNT2_PARAM_ID (0x86000192u)

#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[10u].idacComp[0u])
#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP0_OFFSET         (404u)
#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP0_PARAM_ID       (0x43000194u)

#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[10u].idacComp[1u])
#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP1_OFFSET         (405u)
#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP1_PARAM_ID       (0x45000195u)

#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[10u].idacComp[2u])
#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP2_OFFSET         (406u)
#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX3_IDAC_COMP2_PARAM_ID       (0x4F000196u)

#define CapSense_TRACKPAD_RX1_TX4_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[11u].raw[0u])
#define CapSense_TRACKPAD_RX1_TX4_RAW0_OFFSET               (408u)
#define CapSense_TRACKPAD_RX1_TX4_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX4_RAW0_PARAM_ID             (0x88000198u)

#define CapSense_TRACKPAD_RX1_TX4_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[11u].raw[1u])
#define CapSense_TRACKPAD_RX1_TX4_RAW1_OFFSET               (410u)
#define CapSense_TRACKPAD_RX1_TX4_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX4_RAW1_PARAM_ID             (0x8400019Au)

#define CapSense_TRACKPAD_RX1_TX4_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[11u].raw[2u])
#define CapSense_TRACKPAD_RX1_TX4_RAW2_OFFSET               (412u)
#define CapSense_TRACKPAD_RX1_TX4_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX4_RAW2_PARAM_ID             (0x8900019Cu)

#define CapSense_TRACKPAD_RX1_TX4_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[11u].bsln[0u])
#define CapSense_TRACKPAD_RX1_TX4_BSLN0_OFFSET              (414u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN0_PARAM_ID            (0x8500019Eu)

#define CapSense_TRACKPAD_RX1_TX4_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[11u].bsln[1u])
#define CapSense_TRACKPAD_RX1_TX4_BSLN1_OFFSET              (416u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN1_PARAM_ID            (0x850001A0u)

#define CapSense_TRACKPAD_RX1_TX4_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[11u].bsln[2u])
#define CapSense_TRACKPAD_RX1_TX4_BSLN2_OFFSET              (418u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN2_PARAM_ID            (0x890001A2u)

#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[11u].bslnExt[0u])
#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT0_OFFSET          (420u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT0_PARAM_ID        (0x4C0001A4u)

#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[11u].bslnExt[1u])
#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT1_OFFSET          (421u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT1_PARAM_ID        (0x4A0001A5u)

#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[11u].bslnExt[2u])
#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT2_OFFSET          (422u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX4_BSLN_EXT2_PARAM_ID        (0x400001A6u)

#define CapSense_TRACKPAD_RX1_TX4_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[11u].diff)
#define CapSense_TRACKPAD_RX1_TX4_DIFF_OFFSET               (424u)
#define CapSense_TRACKPAD_RX1_TX4_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX4_DIFF_PARAM_ID             (0x870001A8u)

#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[11u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT0_OFFSET  (426u)
#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT0_PARAM_ID (0x430001AAu)

#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[11u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT1_OFFSET  (427u)
#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT1_PARAM_ID (0x450001ABu)

#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[11u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT2_OFFSET  (428u)
#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX4_NEG_BSLN_RST_CNT2_PARAM_ID (0x4E0001ACu)

#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[11u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT0_OFFSET  (430u)
#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT0_PARAM_ID (0x8A0001AEu)

#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[11u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT1_OFFSET  (432u)
#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT1_PARAM_ID (0x800001B0u)

#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[11u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT2_OFFSET  (434u)
#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX4_POS_BLSN_RST_CNT2_PARAM_ID (0x8C0001B2u)

#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[11u].idacComp[0u])
#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP0_OFFSET         (436u)
#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP0_PARAM_ID       (0x490001B4u)

#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[11u].idacComp[1u])
#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP1_OFFSET         (437u)
#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP1_PARAM_ID       (0x4F0001B5u)

#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[11u].idacComp[2u])
#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP2_OFFSET         (438u)
#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX4_IDAC_COMP2_PARAM_ID       (0x450001B6u)

#define CapSense_TRACKPAD_RX1_TX5_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[12u].raw[0u])
#define CapSense_TRACKPAD_RX1_TX5_RAW0_OFFSET               (440u)
#define CapSense_TRACKPAD_RX1_TX5_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX5_RAW0_PARAM_ID             (0x820001B8u)

#define CapSense_TRACKPAD_RX1_TX5_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[12u].raw[1u])
#define CapSense_TRACKPAD_RX1_TX5_RAW1_OFFSET               (442u)
#define CapSense_TRACKPAD_RX1_TX5_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX5_RAW1_PARAM_ID             (0x8E0001BAu)

#define CapSense_TRACKPAD_RX1_TX5_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[12u].raw[2u])
#define CapSense_TRACKPAD_RX1_TX5_RAW2_OFFSET               (444u)
#define CapSense_TRACKPAD_RX1_TX5_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX5_RAW2_PARAM_ID             (0x830001BCu)

#define CapSense_TRACKPAD_RX1_TX5_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[12u].bsln[0u])
#define CapSense_TRACKPAD_RX1_TX5_BSLN0_OFFSET              (446u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN0_PARAM_ID            (0x8F0001BEu)

#define CapSense_TRACKPAD_RX1_TX5_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[12u].bsln[1u])
#define CapSense_TRACKPAD_RX1_TX5_BSLN1_OFFSET              (448u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN1_PARAM_ID            (0x820001C0u)

#define CapSense_TRACKPAD_RX1_TX5_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[12u].bsln[2u])
#define CapSense_TRACKPAD_RX1_TX5_BSLN2_OFFSET              (450u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN2_PARAM_ID            (0x8E0001C2u)

#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[12u].bslnExt[0u])
#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT0_OFFSET          (452u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT0_PARAM_ID        (0x4B0001C4u)

#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[12u].bslnExt[1u])
#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT1_OFFSET          (453u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT1_PARAM_ID        (0x4D0001C5u)

#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[12u].bslnExt[2u])
#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT2_OFFSET          (454u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX5_BSLN_EXT2_PARAM_ID        (0x470001C6u)

#define CapSense_TRACKPAD_RX1_TX5_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[12u].diff)
#define CapSense_TRACKPAD_RX1_TX5_DIFF_OFFSET               (456u)
#define CapSense_TRACKPAD_RX1_TX5_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX5_DIFF_PARAM_ID             (0x800001C8u)

#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[12u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT0_OFFSET  (458u)
#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT0_PARAM_ID (0x440001CAu)

#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[12u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT1_OFFSET  (459u)
#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT1_PARAM_ID (0x420001CBu)

#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[12u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT2_OFFSET  (460u)
#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX5_NEG_BSLN_RST_CNT2_PARAM_ID (0x490001CCu)

#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[12u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT0_OFFSET  (462u)
#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT0_PARAM_ID (0x8D0001CEu)

#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[12u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT1_OFFSET  (464u)
#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT1_PARAM_ID (0x870001D0u)

#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[12u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT2_OFFSET  (466u)
#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX5_POS_BLSN_RST_CNT2_PARAM_ID (0x8B0001D2u)

#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[12u].idacComp[0u])
#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP0_OFFSET         (468u)
#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP0_PARAM_ID       (0x4E0001D4u)

#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[12u].idacComp[1u])
#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP1_OFFSET         (469u)
#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP1_PARAM_ID       (0x480001D5u)

#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[12u].idacComp[2u])
#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP2_OFFSET         (470u)
#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX5_IDAC_COMP2_PARAM_ID       (0x420001D6u)

#define CapSense_TRACKPAD_RX1_TX6_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[13u].raw[0u])
#define CapSense_TRACKPAD_RX1_TX6_RAW0_OFFSET               (472u)
#define CapSense_TRACKPAD_RX1_TX6_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX6_RAW0_PARAM_ID             (0x850001D8u)

#define CapSense_TRACKPAD_RX1_TX6_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[13u].raw[1u])
#define CapSense_TRACKPAD_RX1_TX6_RAW1_OFFSET               (474u)
#define CapSense_TRACKPAD_RX1_TX6_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX6_RAW1_PARAM_ID             (0x890001DAu)

#define CapSense_TRACKPAD_RX1_TX6_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[13u].raw[2u])
#define CapSense_TRACKPAD_RX1_TX6_RAW2_OFFSET               (476u)
#define CapSense_TRACKPAD_RX1_TX6_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX6_RAW2_PARAM_ID             (0x840001DCu)

#define CapSense_TRACKPAD_RX1_TX6_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[13u].bsln[0u])
#define CapSense_TRACKPAD_RX1_TX6_BSLN0_OFFSET              (478u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN0_PARAM_ID            (0x880001DEu)

#define CapSense_TRACKPAD_RX1_TX6_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[13u].bsln[1u])
#define CapSense_TRACKPAD_RX1_TX6_BSLN1_OFFSET              (480u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN1_PARAM_ID            (0x880001E0u)

#define CapSense_TRACKPAD_RX1_TX6_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[13u].bsln[2u])
#define CapSense_TRACKPAD_RX1_TX6_BSLN2_OFFSET              (482u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN2_PARAM_ID            (0x840001E2u)

#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[13u].bslnExt[0u])
#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT0_OFFSET          (484u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT0_PARAM_ID        (0x410001E4u)

#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[13u].bslnExt[1u])
#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT1_OFFSET          (485u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT1_PARAM_ID        (0x470001E5u)

#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[13u].bslnExt[2u])
#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT2_OFFSET          (486u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX1_TX6_BSLN_EXT2_PARAM_ID        (0x4D0001E6u)

#define CapSense_TRACKPAD_RX1_TX6_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[13u].diff)
#define CapSense_TRACKPAD_RX1_TX6_DIFF_OFFSET               (488u)
#define CapSense_TRACKPAD_RX1_TX6_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX1_TX6_DIFF_PARAM_ID             (0x8A0001E8u)

#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[13u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT0_OFFSET  (490u)
#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT0_PARAM_ID (0x4E0001EAu)

#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[13u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT1_OFFSET  (491u)
#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT1_PARAM_ID (0x480001EBu)

#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[13u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT2_OFFSET  (492u)
#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX1_TX6_NEG_BSLN_RST_CNT2_PARAM_ID (0x430001ECu)

#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[13u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT0_OFFSET  (494u)
#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT0_PARAM_ID (0x870001EEu)

#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[13u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT1_OFFSET  (496u)
#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT1_PARAM_ID (0x8D0001F0u)

#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[13u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT2_OFFSET  (498u)
#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX1_TX6_POS_BLSN_RST_CNT2_PARAM_ID (0x810001F2u)

#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[13u].idacComp[0u])
#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP0_OFFSET         (500u)
#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP0_PARAM_ID       (0x440001F4u)

#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[13u].idacComp[1u])
#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP1_OFFSET         (501u)
#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP1_PARAM_ID       (0x420001F5u)

#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[13u].idacComp[2u])
#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP2_OFFSET         (502u)
#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX1_TX6_IDAC_COMP2_PARAM_ID       (0x480001F6u)

#define CapSense_TRACKPAD_RX2_TX0_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[14u].raw[0u])
#define CapSense_TRACKPAD_RX2_TX0_RAW0_OFFSET               (504u)
#define CapSense_TRACKPAD_RX2_TX0_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX0_RAW0_PARAM_ID             (0x8F0001F8u)

#define CapSense_TRACKPAD_RX2_TX0_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[14u].raw[1u])
#define CapSense_TRACKPAD_RX2_TX0_RAW1_OFFSET               (506u)
#define CapSense_TRACKPAD_RX2_TX0_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX0_RAW1_PARAM_ID             (0x830001FAu)

#define CapSense_TRACKPAD_RX2_TX0_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[14u].raw[2u])
#define CapSense_TRACKPAD_RX2_TX0_RAW2_OFFSET               (508u)
#define CapSense_TRACKPAD_RX2_TX0_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX0_RAW2_PARAM_ID             (0x8E0001FCu)

#define CapSense_TRACKPAD_RX2_TX0_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[14u].bsln[0u])
#define CapSense_TRACKPAD_RX2_TX0_BSLN0_OFFSET              (510u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN0_PARAM_ID            (0x820001FEu)

#define CapSense_TRACKPAD_RX2_TX0_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[14u].bsln[1u])
#define CapSense_TRACKPAD_RX2_TX0_BSLN1_OFFSET              (512u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN1_PARAM_ID            (0x88000200u)

#define CapSense_TRACKPAD_RX2_TX0_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[14u].bsln[2u])
#define CapSense_TRACKPAD_RX2_TX0_BSLN2_OFFSET              (514u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN2_PARAM_ID            (0x84000202u)

#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[14u].bslnExt[0u])
#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT0_OFFSET          (516u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT0_PARAM_ID        (0x41000204u)

#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[14u].bslnExt[1u])
#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT1_OFFSET          (517u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT1_PARAM_ID        (0x47000205u)

#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[14u].bslnExt[2u])
#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT2_OFFSET          (518u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX0_BSLN_EXT2_PARAM_ID        (0x4D000206u)

#define CapSense_TRACKPAD_RX2_TX0_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[14u].diff)
#define CapSense_TRACKPAD_RX2_TX0_DIFF_OFFSET               (520u)
#define CapSense_TRACKPAD_RX2_TX0_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX0_DIFF_PARAM_ID             (0x8A000208u)

#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[14u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT0_OFFSET  (522u)
#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT0_PARAM_ID (0x4E00020Au)

#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[14u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT1_OFFSET  (523u)
#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT1_PARAM_ID (0x4800020Bu)

#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[14u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT2_OFFSET  (524u)
#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX0_NEG_BSLN_RST_CNT2_PARAM_ID (0x4300020Cu)

#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[14u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT0_OFFSET  (526u)
#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT0_PARAM_ID (0x8700020Eu)

#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[14u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT1_OFFSET  (528u)
#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT1_PARAM_ID (0x8D000210u)

#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[14u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT2_OFFSET  (530u)
#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX0_POS_BLSN_RST_CNT2_PARAM_ID (0x81000212u)

#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[14u].idacComp[0u])
#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP0_OFFSET         (532u)
#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP0_PARAM_ID       (0x44000214u)

#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[14u].idacComp[1u])
#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP1_OFFSET         (533u)
#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP1_PARAM_ID       (0x42000215u)

#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[14u].idacComp[2u])
#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP2_OFFSET         (534u)
#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX0_IDAC_COMP2_PARAM_ID       (0x48000216u)

#define CapSense_TRACKPAD_RX2_TX1_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[15u].raw[0u])
#define CapSense_TRACKPAD_RX2_TX1_RAW0_OFFSET               (536u)
#define CapSense_TRACKPAD_RX2_TX1_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX1_RAW0_PARAM_ID             (0x8F000218u)

#define CapSense_TRACKPAD_RX2_TX1_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[15u].raw[1u])
#define CapSense_TRACKPAD_RX2_TX1_RAW1_OFFSET               (538u)
#define CapSense_TRACKPAD_RX2_TX1_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX1_RAW1_PARAM_ID             (0x8300021Au)

#define CapSense_TRACKPAD_RX2_TX1_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[15u].raw[2u])
#define CapSense_TRACKPAD_RX2_TX1_RAW2_OFFSET               (540u)
#define CapSense_TRACKPAD_RX2_TX1_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX1_RAW2_PARAM_ID             (0x8E00021Cu)

#define CapSense_TRACKPAD_RX2_TX1_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[15u].bsln[0u])
#define CapSense_TRACKPAD_RX2_TX1_BSLN0_OFFSET              (542u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN0_PARAM_ID            (0x8200021Eu)

#define CapSense_TRACKPAD_RX2_TX1_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[15u].bsln[1u])
#define CapSense_TRACKPAD_RX2_TX1_BSLN1_OFFSET              (544u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN1_PARAM_ID            (0x82000220u)

#define CapSense_TRACKPAD_RX2_TX1_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[15u].bsln[2u])
#define CapSense_TRACKPAD_RX2_TX1_BSLN2_OFFSET              (546u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN2_PARAM_ID            (0x8E000222u)

#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[15u].bslnExt[0u])
#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT0_OFFSET          (548u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT0_PARAM_ID        (0x4B000224u)

#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[15u].bslnExt[1u])
#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT1_OFFSET          (549u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT1_PARAM_ID        (0x4D000225u)

#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[15u].bslnExt[2u])
#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT2_OFFSET          (550u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX1_BSLN_EXT2_PARAM_ID        (0x47000226u)

#define CapSense_TRACKPAD_RX2_TX1_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[15u].diff)
#define CapSense_TRACKPAD_RX2_TX1_DIFF_OFFSET               (552u)
#define CapSense_TRACKPAD_RX2_TX1_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX1_DIFF_PARAM_ID             (0x80000228u)

#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[15u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT0_OFFSET  (554u)
#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT0_PARAM_ID (0x4400022Au)

#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[15u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT1_OFFSET  (555u)
#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT1_PARAM_ID (0x4200022Bu)

#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[15u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT2_OFFSET  (556u)
#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX1_NEG_BSLN_RST_CNT2_PARAM_ID (0x4900022Cu)

#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[15u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT0_OFFSET  (558u)
#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT0_PARAM_ID (0x8D00022Eu)

#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[15u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT1_OFFSET  (560u)
#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT1_PARAM_ID (0x87000230u)

#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[15u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT2_OFFSET  (562u)
#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX1_POS_BLSN_RST_CNT2_PARAM_ID (0x8B000232u)

#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[15u].idacComp[0u])
#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP0_OFFSET         (564u)
#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP0_PARAM_ID       (0x4E000234u)

#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[15u].idacComp[1u])
#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP1_OFFSET         (565u)
#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP1_PARAM_ID       (0x48000235u)

#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[15u].idacComp[2u])
#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP2_OFFSET         (566u)
#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX1_IDAC_COMP2_PARAM_ID       (0x42000236u)

#define CapSense_TRACKPAD_RX2_TX2_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[16u].raw[0u])
#define CapSense_TRACKPAD_RX2_TX2_RAW0_OFFSET               (568u)
#define CapSense_TRACKPAD_RX2_TX2_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX2_RAW0_PARAM_ID             (0x85000238u)

#define CapSense_TRACKPAD_RX2_TX2_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[16u].raw[1u])
#define CapSense_TRACKPAD_RX2_TX2_RAW1_OFFSET               (570u)
#define CapSense_TRACKPAD_RX2_TX2_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX2_RAW1_PARAM_ID             (0x8900023Au)

#define CapSense_TRACKPAD_RX2_TX2_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[16u].raw[2u])
#define CapSense_TRACKPAD_RX2_TX2_RAW2_OFFSET               (572u)
#define CapSense_TRACKPAD_RX2_TX2_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX2_RAW2_PARAM_ID             (0x8400023Cu)

#define CapSense_TRACKPAD_RX2_TX2_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[16u].bsln[0u])
#define CapSense_TRACKPAD_RX2_TX2_BSLN0_OFFSET              (574u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN0_PARAM_ID            (0x8800023Eu)

#define CapSense_TRACKPAD_RX2_TX2_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[16u].bsln[1u])
#define CapSense_TRACKPAD_RX2_TX2_BSLN1_OFFSET              (576u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN1_PARAM_ID            (0x85000240u)

#define CapSense_TRACKPAD_RX2_TX2_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[16u].bsln[2u])
#define CapSense_TRACKPAD_RX2_TX2_BSLN2_OFFSET              (578u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN2_PARAM_ID            (0x89000242u)

#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[16u].bslnExt[0u])
#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT0_OFFSET          (580u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT0_PARAM_ID        (0x4C000244u)

#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[16u].bslnExt[1u])
#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT1_OFFSET          (581u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT1_PARAM_ID        (0x4A000245u)

#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[16u].bslnExt[2u])
#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT2_OFFSET          (582u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX2_BSLN_EXT2_PARAM_ID        (0x40000246u)

#define CapSense_TRACKPAD_RX2_TX2_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[16u].diff)
#define CapSense_TRACKPAD_RX2_TX2_DIFF_OFFSET               (584u)
#define CapSense_TRACKPAD_RX2_TX2_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX2_DIFF_PARAM_ID             (0x87000248u)

#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[16u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT0_OFFSET  (586u)
#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT0_PARAM_ID (0x4300024Au)

#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[16u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT1_OFFSET  (587u)
#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT1_PARAM_ID (0x4500024Bu)

#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[16u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT2_OFFSET  (588u)
#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX2_NEG_BSLN_RST_CNT2_PARAM_ID (0x4E00024Cu)

#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[16u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT0_OFFSET  (590u)
#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT0_PARAM_ID (0x8A00024Eu)

#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[16u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT1_OFFSET  (592u)
#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT1_PARAM_ID (0x80000250u)

#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[16u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT2_OFFSET  (594u)
#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX2_POS_BLSN_RST_CNT2_PARAM_ID (0x8C000252u)

#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[16u].idacComp[0u])
#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP0_OFFSET         (596u)
#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP0_PARAM_ID       (0x49000254u)

#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[16u].idacComp[1u])
#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP1_OFFSET         (597u)
#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP1_PARAM_ID       (0x4F000255u)

#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[16u].idacComp[2u])
#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP2_OFFSET         (598u)
#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX2_IDAC_COMP2_PARAM_ID       (0x45000256u)

#define CapSense_TRACKPAD_RX2_TX3_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[17u].raw[0u])
#define CapSense_TRACKPAD_RX2_TX3_RAW0_OFFSET               (600u)
#define CapSense_TRACKPAD_RX2_TX3_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX3_RAW0_PARAM_ID             (0x82000258u)

#define CapSense_TRACKPAD_RX2_TX3_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[17u].raw[1u])
#define CapSense_TRACKPAD_RX2_TX3_RAW1_OFFSET               (602u)
#define CapSense_TRACKPAD_RX2_TX3_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX3_RAW1_PARAM_ID             (0x8E00025Au)

#define CapSense_TRACKPAD_RX2_TX3_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[17u].raw[2u])
#define CapSense_TRACKPAD_RX2_TX3_RAW2_OFFSET               (604u)
#define CapSense_TRACKPAD_RX2_TX3_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX3_RAW2_PARAM_ID             (0x8300025Cu)

#define CapSense_TRACKPAD_RX2_TX3_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[17u].bsln[0u])
#define CapSense_TRACKPAD_RX2_TX3_BSLN0_OFFSET              (606u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN0_PARAM_ID            (0x8F00025Eu)

#define CapSense_TRACKPAD_RX2_TX3_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[17u].bsln[1u])
#define CapSense_TRACKPAD_RX2_TX3_BSLN1_OFFSET              (608u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN1_PARAM_ID            (0x8F000260u)

#define CapSense_TRACKPAD_RX2_TX3_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[17u].bsln[2u])
#define CapSense_TRACKPAD_RX2_TX3_BSLN2_OFFSET              (610u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN2_PARAM_ID            (0x83000262u)

#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[17u].bslnExt[0u])
#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT0_OFFSET          (612u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT0_PARAM_ID        (0x46000264u)

#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[17u].bslnExt[1u])
#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT1_OFFSET          (613u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT1_PARAM_ID        (0x40000265u)

#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[17u].bslnExt[2u])
#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT2_OFFSET          (614u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX3_BSLN_EXT2_PARAM_ID        (0x4A000266u)

#define CapSense_TRACKPAD_RX2_TX3_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[17u].diff)
#define CapSense_TRACKPAD_RX2_TX3_DIFF_OFFSET               (616u)
#define CapSense_TRACKPAD_RX2_TX3_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX3_DIFF_PARAM_ID             (0x8D000268u)

#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[17u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT0_OFFSET  (618u)
#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT0_PARAM_ID (0x4900026Au)

#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[17u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT1_OFFSET  (619u)
#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT1_PARAM_ID (0x4F00026Bu)

#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[17u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT2_OFFSET  (620u)
#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX3_NEG_BSLN_RST_CNT2_PARAM_ID (0x4400026Cu)

#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[17u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT0_OFFSET  (622u)
#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT0_PARAM_ID (0x8000026Eu)

#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[17u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT1_OFFSET  (624u)
#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT1_PARAM_ID (0x8A000270u)

#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[17u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT2_OFFSET  (626u)
#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX3_POS_BLSN_RST_CNT2_PARAM_ID (0x86000272u)

#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[17u].idacComp[0u])
#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP0_OFFSET         (628u)
#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP0_PARAM_ID       (0x43000274u)

#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[17u].idacComp[1u])
#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP1_OFFSET         (629u)
#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP1_PARAM_ID       (0x45000275u)

#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[17u].idacComp[2u])
#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP2_OFFSET         (630u)
#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX3_IDAC_COMP2_PARAM_ID       (0x4F000276u)

#define CapSense_TRACKPAD_RX2_TX4_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[18u].raw[0u])
#define CapSense_TRACKPAD_RX2_TX4_RAW0_OFFSET               (632u)
#define CapSense_TRACKPAD_RX2_TX4_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX4_RAW0_PARAM_ID             (0x88000278u)

#define CapSense_TRACKPAD_RX2_TX4_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[18u].raw[1u])
#define CapSense_TRACKPAD_RX2_TX4_RAW1_OFFSET               (634u)
#define CapSense_TRACKPAD_RX2_TX4_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX4_RAW1_PARAM_ID             (0x8400027Au)

#define CapSense_TRACKPAD_RX2_TX4_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[18u].raw[2u])
#define CapSense_TRACKPAD_RX2_TX4_RAW2_OFFSET               (636u)
#define CapSense_TRACKPAD_RX2_TX4_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX4_RAW2_PARAM_ID             (0x8900027Cu)

#define CapSense_TRACKPAD_RX2_TX4_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[18u].bsln[0u])
#define CapSense_TRACKPAD_RX2_TX4_BSLN0_OFFSET              (638u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN0_PARAM_ID            (0x8500027Eu)

#define CapSense_TRACKPAD_RX2_TX4_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[18u].bsln[1u])
#define CapSense_TRACKPAD_RX2_TX4_BSLN1_OFFSET              (640u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN1_PARAM_ID            (0x8B000280u)

#define CapSense_TRACKPAD_RX2_TX4_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[18u].bsln[2u])
#define CapSense_TRACKPAD_RX2_TX4_BSLN2_OFFSET              (642u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN2_PARAM_ID            (0x87000282u)

#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[18u].bslnExt[0u])
#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT0_OFFSET          (644u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT0_PARAM_ID        (0x42000284u)

#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[18u].bslnExt[1u])
#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT1_OFFSET          (645u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT1_PARAM_ID        (0x44000285u)

#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[18u].bslnExt[2u])
#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT2_OFFSET          (646u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX4_BSLN_EXT2_PARAM_ID        (0x4E000286u)

#define CapSense_TRACKPAD_RX2_TX4_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[18u].diff)
#define CapSense_TRACKPAD_RX2_TX4_DIFF_OFFSET               (648u)
#define CapSense_TRACKPAD_RX2_TX4_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX4_DIFF_PARAM_ID             (0x89000288u)

#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[18u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT0_OFFSET  (650u)
#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT0_PARAM_ID (0x4D00028Au)

#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[18u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT1_OFFSET  (651u)
#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT1_PARAM_ID (0x4B00028Bu)

#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[18u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT2_OFFSET  (652u)
#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX4_NEG_BSLN_RST_CNT2_PARAM_ID (0x4000028Cu)

#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[18u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT0_OFFSET  (654u)
#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT0_PARAM_ID (0x8400028Eu)

#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[18u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT1_OFFSET  (656u)
#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT1_PARAM_ID (0x8E000290u)

#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[18u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT2_OFFSET  (658u)
#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX4_POS_BLSN_RST_CNT2_PARAM_ID (0x82000292u)

#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[18u].idacComp[0u])
#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP0_OFFSET         (660u)
#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP0_PARAM_ID       (0x47000294u)

#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[18u].idacComp[1u])
#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP1_OFFSET         (661u)
#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP1_PARAM_ID       (0x41000295u)

#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[18u].idacComp[2u])
#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP2_OFFSET         (662u)
#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX4_IDAC_COMP2_PARAM_ID       (0x4B000296u)

#define CapSense_TRACKPAD_RX2_TX5_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[19u].raw[0u])
#define CapSense_TRACKPAD_RX2_TX5_RAW0_OFFSET               (664u)
#define CapSense_TRACKPAD_RX2_TX5_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX5_RAW0_PARAM_ID             (0x8C000298u)

#define CapSense_TRACKPAD_RX2_TX5_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[19u].raw[1u])
#define CapSense_TRACKPAD_RX2_TX5_RAW1_OFFSET               (666u)
#define CapSense_TRACKPAD_RX2_TX5_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX5_RAW1_PARAM_ID             (0x8000029Au)

#define CapSense_TRACKPAD_RX2_TX5_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[19u].raw[2u])
#define CapSense_TRACKPAD_RX2_TX5_RAW2_OFFSET               (668u)
#define CapSense_TRACKPAD_RX2_TX5_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX5_RAW2_PARAM_ID             (0x8D00029Cu)

#define CapSense_TRACKPAD_RX2_TX5_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[19u].bsln[0u])
#define CapSense_TRACKPAD_RX2_TX5_BSLN0_OFFSET              (670u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN0_PARAM_ID            (0x8100029Eu)

#define CapSense_TRACKPAD_RX2_TX5_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[19u].bsln[1u])
#define CapSense_TRACKPAD_RX2_TX5_BSLN1_OFFSET              (672u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN1_PARAM_ID            (0x810002A0u)

#define CapSense_TRACKPAD_RX2_TX5_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[19u].bsln[2u])
#define CapSense_TRACKPAD_RX2_TX5_BSLN2_OFFSET              (674u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN2_PARAM_ID            (0x8D0002A2u)

#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[19u].bslnExt[0u])
#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT0_OFFSET          (676u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT0_PARAM_ID        (0x480002A4u)

#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[19u].bslnExt[1u])
#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT1_OFFSET          (677u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT1_PARAM_ID        (0x4E0002A5u)

#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[19u].bslnExt[2u])
#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT2_OFFSET          (678u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX5_BSLN_EXT2_PARAM_ID        (0x440002A6u)

#define CapSense_TRACKPAD_RX2_TX5_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[19u].diff)
#define CapSense_TRACKPAD_RX2_TX5_DIFF_OFFSET               (680u)
#define CapSense_TRACKPAD_RX2_TX5_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX5_DIFF_PARAM_ID             (0x830002A8u)

#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[19u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT0_OFFSET  (682u)
#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT0_PARAM_ID (0x470002AAu)

#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[19u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT1_OFFSET  (683u)
#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT1_PARAM_ID (0x410002ABu)

#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[19u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT2_OFFSET  (684u)
#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX5_NEG_BSLN_RST_CNT2_PARAM_ID (0x4A0002ACu)

#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[19u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT0_OFFSET  (686u)
#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT0_PARAM_ID (0x8E0002AEu)

#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[19u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT1_OFFSET  (688u)
#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT1_PARAM_ID (0x840002B0u)

#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[19u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT2_OFFSET  (690u)
#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX5_POS_BLSN_RST_CNT2_PARAM_ID (0x880002B2u)

#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[19u].idacComp[0u])
#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP0_OFFSET         (692u)
#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP0_PARAM_ID       (0x4D0002B4u)

#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[19u].idacComp[1u])
#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP1_OFFSET         (693u)
#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP1_PARAM_ID       (0x4B0002B5u)

#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[19u].idacComp[2u])
#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP2_OFFSET         (694u)
#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX5_IDAC_COMP2_PARAM_ID       (0x410002B6u)

#define CapSense_TRACKPAD_RX2_TX6_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[20u].raw[0u])
#define CapSense_TRACKPAD_RX2_TX6_RAW0_OFFSET               (696u)
#define CapSense_TRACKPAD_RX2_TX6_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX6_RAW0_PARAM_ID             (0x860002B8u)

#define CapSense_TRACKPAD_RX2_TX6_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[20u].raw[1u])
#define CapSense_TRACKPAD_RX2_TX6_RAW1_OFFSET               (698u)
#define CapSense_TRACKPAD_RX2_TX6_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX6_RAW1_PARAM_ID             (0x8A0002BAu)

#define CapSense_TRACKPAD_RX2_TX6_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[20u].raw[2u])
#define CapSense_TRACKPAD_RX2_TX6_RAW2_OFFSET               (700u)
#define CapSense_TRACKPAD_RX2_TX6_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX6_RAW2_PARAM_ID             (0x870002BCu)

#define CapSense_TRACKPAD_RX2_TX6_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[20u].bsln[0u])
#define CapSense_TRACKPAD_RX2_TX6_BSLN0_OFFSET              (702u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN0_PARAM_ID            (0x8B0002BEu)

#define CapSense_TRACKPAD_RX2_TX6_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[20u].bsln[1u])
#define CapSense_TRACKPAD_RX2_TX6_BSLN1_OFFSET              (704u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN1_PARAM_ID            (0x860002C0u)

#define CapSense_TRACKPAD_RX2_TX6_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[20u].bsln[2u])
#define CapSense_TRACKPAD_RX2_TX6_BSLN2_OFFSET              (706u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN2_PARAM_ID            (0x8A0002C2u)

#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[20u].bslnExt[0u])
#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT0_OFFSET          (708u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT0_PARAM_ID        (0x4F0002C4u)

#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[20u].bslnExt[1u])
#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT1_OFFSET          (709u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT1_PARAM_ID        (0x490002C5u)

#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[20u].bslnExt[2u])
#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT2_OFFSET          (710u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX2_TX6_BSLN_EXT2_PARAM_ID        (0x430002C6u)

#define CapSense_TRACKPAD_RX2_TX6_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[20u].diff)
#define CapSense_TRACKPAD_RX2_TX6_DIFF_OFFSET               (712u)
#define CapSense_TRACKPAD_RX2_TX6_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX2_TX6_DIFF_PARAM_ID             (0x840002C8u)

#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[20u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT0_OFFSET  (714u)
#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT0_PARAM_ID (0x400002CAu)

#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[20u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT1_OFFSET  (715u)
#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT1_PARAM_ID (0x460002CBu)

#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[20u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT2_OFFSET  (716u)
#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX2_TX6_NEG_BSLN_RST_CNT2_PARAM_ID (0x4D0002CCu)

#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[20u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT0_OFFSET  (718u)
#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT0_PARAM_ID (0x890002CEu)

#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[20u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT1_OFFSET  (720u)
#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT1_PARAM_ID (0x830002D0u)

#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[20u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT2_OFFSET  (722u)
#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX2_TX6_POS_BLSN_RST_CNT2_PARAM_ID (0x8F0002D2u)

#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[20u].idacComp[0u])
#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP0_OFFSET         (724u)
#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP0_PARAM_ID       (0x4A0002D4u)

#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[20u].idacComp[1u])
#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP1_OFFSET         (725u)
#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP1_PARAM_ID       (0x4C0002D5u)

#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[20u].idacComp[2u])
#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP2_OFFSET         (726u)
#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX2_TX6_IDAC_COMP2_PARAM_ID       (0x460002D6u)

#define CapSense_TRACKPAD_RX3_TX0_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[21u].raw[0u])
#define CapSense_TRACKPAD_RX3_TX0_RAW0_OFFSET               (728u)
#define CapSense_TRACKPAD_RX3_TX0_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX0_RAW0_PARAM_ID             (0x810002D8u)

#define CapSense_TRACKPAD_RX3_TX0_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[21u].raw[1u])
#define CapSense_TRACKPAD_RX3_TX0_RAW1_OFFSET               (730u)
#define CapSense_TRACKPAD_RX3_TX0_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX0_RAW1_PARAM_ID             (0x8D0002DAu)

#define CapSense_TRACKPAD_RX3_TX0_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[21u].raw[2u])
#define CapSense_TRACKPAD_RX3_TX0_RAW2_OFFSET               (732u)
#define CapSense_TRACKPAD_RX3_TX0_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX0_RAW2_PARAM_ID             (0x800002DCu)

#define CapSense_TRACKPAD_RX3_TX0_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[21u].bsln[0u])
#define CapSense_TRACKPAD_RX3_TX0_BSLN0_OFFSET              (734u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN0_PARAM_ID            (0x8C0002DEu)

#define CapSense_TRACKPAD_RX3_TX0_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[21u].bsln[1u])
#define CapSense_TRACKPAD_RX3_TX0_BSLN1_OFFSET              (736u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN1_PARAM_ID            (0x8C0002E0u)

#define CapSense_TRACKPAD_RX3_TX0_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[21u].bsln[2u])
#define CapSense_TRACKPAD_RX3_TX0_BSLN2_OFFSET              (738u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN2_PARAM_ID            (0x800002E2u)

#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[21u].bslnExt[0u])
#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT0_OFFSET          (740u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT0_PARAM_ID        (0x450002E4u)

#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[21u].bslnExt[1u])
#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT1_OFFSET          (741u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT1_PARAM_ID        (0x430002E5u)

#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[21u].bslnExt[2u])
#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT2_OFFSET          (742u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX0_BSLN_EXT2_PARAM_ID        (0x490002E6u)

#define CapSense_TRACKPAD_RX3_TX0_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[21u].diff)
#define CapSense_TRACKPAD_RX3_TX0_DIFF_OFFSET               (744u)
#define CapSense_TRACKPAD_RX3_TX0_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX0_DIFF_PARAM_ID             (0x8E0002E8u)

#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[21u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT0_OFFSET  (746u)
#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT0_PARAM_ID (0x4A0002EAu)

#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[21u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT1_OFFSET  (747u)
#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT1_PARAM_ID (0x4C0002EBu)

#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[21u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT2_OFFSET  (748u)
#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX0_NEG_BSLN_RST_CNT2_PARAM_ID (0x470002ECu)

#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[21u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT0_OFFSET  (750u)
#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT0_PARAM_ID (0x830002EEu)

#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[21u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT1_OFFSET  (752u)
#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT1_PARAM_ID (0x890002F0u)

#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[21u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT2_OFFSET  (754u)
#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX0_POS_BLSN_RST_CNT2_PARAM_ID (0x850002F2u)

#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[21u].idacComp[0u])
#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP0_OFFSET         (756u)
#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP0_PARAM_ID       (0x400002F4u)

#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[21u].idacComp[1u])
#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP1_OFFSET         (757u)
#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP1_PARAM_ID       (0x460002F5u)

#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[21u].idacComp[2u])
#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP2_OFFSET         (758u)
#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX0_IDAC_COMP2_PARAM_ID       (0x4C0002F6u)

#define CapSense_TRACKPAD_RX3_TX1_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[22u].raw[0u])
#define CapSense_TRACKPAD_RX3_TX1_RAW0_OFFSET               (760u)
#define CapSense_TRACKPAD_RX3_TX1_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX1_RAW0_PARAM_ID             (0x8B0002F8u)

#define CapSense_TRACKPAD_RX3_TX1_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[22u].raw[1u])
#define CapSense_TRACKPAD_RX3_TX1_RAW1_OFFSET               (762u)
#define CapSense_TRACKPAD_RX3_TX1_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX1_RAW1_PARAM_ID             (0x870002FAu)

#define CapSense_TRACKPAD_RX3_TX1_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[22u].raw[2u])
#define CapSense_TRACKPAD_RX3_TX1_RAW2_OFFSET               (764u)
#define CapSense_TRACKPAD_RX3_TX1_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX1_RAW2_PARAM_ID             (0x8A0002FCu)

#define CapSense_TRACKPAD_RX3_TX1_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[22u].bsln[0u])
#define CapSense_TRACKPAD_RX3_TX1_BSLN0_OFFSET              (766u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN0_PARAM_ID            (0x860002FEu)

#define CapSense_TRACKPAD_RX3_TX1_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[22u].bsln[1u])
#define CapSense_TRACKPAD_RX3_TX1_BSLN1_OFFSET              (768u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN1_PARAM_ID            (0x83000300u)

#define CapSense_TRACKPAD_RX3_TX1_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[22u].bsln[2u])
#define CapSense_TRACKPAD_RX3_TX1_BSLN2_OFFSET              (770u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN2_PARAM_ID            (0x8F000302u)

#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[22u].bslnExt[0u])
#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT0_OFFSET          (772u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT0_PARAM_ID        (0x4A000304u)

#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[22u].bslnExt[1u])
#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT1_OFFSET          (773u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT1_PARAM_ID        (0x4C000305u)

#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[22u].bslnExt[2u])
#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT2_OFFSET          (774u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX1_BSLN_EXT2_PARAM_ID        (0x46000306u)

#define CapSense_TRACKPAD_RX3_TX1_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[22u].diff)
#define CapSense_TRACKPAD_RX3_TX1_DIFF_OFFSET               (776u)
#define CapSense_TRACKPAD_RX3_TX1_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX1_DIFF_PARAM_ID             (0x81000308u)

#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[22u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT0_OFFSET  (778u)
#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT0_PARAM_ID (0x4500030Au)

#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[22u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT1_OFFSET  (779u)
#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT1_PARAM_ID (0x4300030Bu)

#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[22u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT2_OFFSET  (780u)
#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX1_NEG_BSLN_RST_CNT2_PARAM_ID (0x4800030Cu)

#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[22u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT0_OFFSET  (782u)
#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT0_PARAM_ID (0x8C00030Eu)

#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[22u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT1_OFFSET  (784u)
#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT1_PARAM_ID (0x86000310u)

#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[22u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT2_OFFSET  (786u)
#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX1_POS_BLSN_RST_CNT2_PARAM_ID (0x8A000312u)

#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[22u].idacComp[0u])
#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP0_OFFSET         (788u)
#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP0_PARAM_ID       (0x4F000314u)

#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[22u].idacComp[1u])
#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP1_OFFSET         (789u)
#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP1_PARAM_ID       (0x49000315u)

#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[22u].idacComp[2u])
#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP2_OFFSET         (790u)
#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX1_IDAC_COMP2_PARAM_ID       (0x43000316u)

#define CapSense_TRACKPAD_RX3_TX2_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[23u].raw[0u])
#define CapSense_TRACKPAD_RX3_TX2_RAW0_OFFSET               (792u)
#define CapSense_TRACKPAD_RX3_TX2_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX2_RAW0_PARAM_ID             (0x84000318u)

#define CapSense_TRACKPAD_RX3_TX2_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[23u].raw[1u])
#define CapSense_TRACKPAD_RX3_TX2_RAW1_OFFSET               (794u)
#define CapSense_TRACKPAD_RX3_TX2_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX2_RAW1_PARAM_ID             (0x8800031Au)

#define CapSense_TRACKPAD_RX3_TX2_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[23u].raw[2u])
#define CapSense_TRACKPAD_RX3_TX2_RAW2_OFFSET               (796u)
#define CapSense_TRACKPAD_RX3_TX2_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX2_RAW2_PARAM_ID             (0x8500031Cu)

#define CapSense_TRACKPAD_RX3_TX2_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[23u].bsln[0u])
#define CapSense_TRACKPAD_RX3_TX2_BSLN0_OFFSET              (798u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN0_PARAM_ID            (0x8900031Eu)

#define CapSense_TRACKPAD_RX3_TX2_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[23u].bsln[1u])
#define CapSense_TRACKPAD_RX3_TX2_BSLN1_OFFSET              (800u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN1_PARAM_ID            (0x89000320u)

#define CapSense_TRACKPAD_RX3_TX2_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[23u].bsln[2u])
#define CapSense_TRACKPAD_RX3_TX2_BSLN2_OFFSET              (802u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN2_PARAM_ID            (0x85000322u)

#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[23u].bslnExt[0u])
#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT0_OFFSET          (804u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT0_PARAM_ID        (0x40000324u)

#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[23u].bslnExt[1u])
#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT1_OFFSET          (805u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT1_PARAM_ID        (0x46000325u)

#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[23u].bslnExt[2u])
#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT2_OFFSET          (806u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX2_BSLN_EXT2_PARAM_ID        (0x4C000326u)

#define CapSense_TRACKPAD_RX3_TX2_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[23u].diff)
#define CapSense_TRACKPAD_RX3_TX2_DIFF_OFFSET               (808u)
#define CapSense_TRACKPAD_RX3_TX2_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX2_DIFF_PARAM_ID             (0x8B000328u)

#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[23u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT0_OFFSET  (810u)
#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT0_PARAM_ID (0x4F00032Au)

#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[23u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT1_OFFSET  (811u)
#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT1_PARAM_ID (0x4900032Bu)

#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[23u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT2_OFFSET  (812u)
#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX2_NEG_BSLN_RST_CNT2_PARAM_ID (0x4200032Cu)

#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[23u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT0_OFFSET  (814u)
#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT0_PARAM_ID (0x8600032Eu)

#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[23u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT1_OFFSET  (816u)
#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT1_PARAM_ID (0x8C000330u)

#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[23u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT2_OFFSET  (818u)
#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX2_POS_BLSN_RST_CNT2_PARAM_ID (0x80000332u)

#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[23u].idacComp[0u])
#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP0_OFFSET         (820u)
#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP0_PARAM_ID       (0x45000334u)

#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[23u].idacComp[1u])
#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP1_OFFSET         (821u)
#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP1_PARAM_ID       (0x43000335u)

#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[23u].idacComp[2u])
#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP2_OFFSET         (822u)
#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX2_IDAC_COMP2_PARAM_ID       (0x49000336u)

#define CapSense_TRACKPAD_RX3_TX3_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[24u].raw[0u])
#define CapSense_TRACKPAD_RX3_TX3_RAW0_OFFSET               (824u)
#define CapSense_TRACKPAD_RX3_TX3_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX3_RAW0_PARAM_ID             (0x8E000338u)

#define CapSense_TRACKPAD_RX3_TX3_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[24u].raw[1u])
#define CapSense_TRACKPAD_RX3_TX3_RAW1_OFFSET               (826u)
#define CapSense_TRACKPAD_RX3_TX3_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX3_RAW1_PARAM_ID             (0x8200033Au)

#define CapSense_TRACKPAD_RX3_TX3_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[24u].raw[2u])
#define CapSense_TRACKPAD_RX3_TX3_RAW2_OFFSET               (828u)
#define CapSense_TRACKPAD_RX3_TX3_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX3_RAW2_PARAM_ID             (0x8F00033Cu)

#define CapSense_TRACKPAD_RX3_TX3_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[24u].bsln[0u])
#define CapSense_TRACKPAD_RX3_TX3_BSLN0_OFFSET              (830u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN0_PARAM_ID            (0x8300033Eu)

#define CapSense_TRACKPAD_RX3_TX3_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[24u].bsln[1u])
#define CapSense_TRACKPAD_RX3_TX3_BSLN1_OFFSET              (832u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN1_PARAM_ID            (0x8E000340u)

#define CapSense_TRACKPAD_RX3_TX3_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[24u].bsln[2u])
#define CapSense_TRACKPAD_RX3_TX3_BSLN2_OFFSET              (834u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN2_PARAM_ID            (0x82000342u)

#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[24u].bslnExt[0u])
#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT0_OFFSET          (836u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT0_PARAM_ID        (0x47000344u)

#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[24u].bslnExt[1u])
#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT1_OFFSET          (837u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT1_PARAM_ID        (0x41000345u)

#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[24u].bslnExt[2u])
#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT2_OFFSET          (838u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX3_BSLN_EXT2_PARAM_ID        (0x4B000346u)

#define CapSense_TRACKPAD_RX3_TX3_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[24u].diff)
#define CapSense_TRACKPAD_RX3_TX3_DIFF_OFFSET               (840u)
#define CapSense_TRACKPAD_RX3_TX3_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX3_DIFF_PARAM_ID             (0x8C000348u)

#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[24u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT0_OFFSET  (842u)
#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT0_PARAM_ID (0x4800034Au)

#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[24u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT1_OFFSET  (843u)
#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT1_PARAM_ID (0x4E00034Bu)

#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[24u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT2_OFFSET  (844u)
#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX3_NEG_BSLN_RST_CNT2_PARAM_ID (0x4500034Cu)

#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[24u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT0_OFFSET  (846u)
#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT0_PARAM_ID (0x8100034Eu)

#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[24u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT1_OFFSET  (848u)
#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT1_PARAM_ID (0x8B000350u)

#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[24u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT2_OFFSET  (850u)
#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX3_POS_BLSN_RST_CNT2_PARAM_ID (0x87000352u)

#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[24u].idacComp[0u])
#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP0_OFFSET         (852u)
#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP0_PARAM_ID       (0x42000354u)

#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[24u].idacComp[1u])
#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP1_OFFSET         (853u)
#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP1_PARAM_ID       (0x44000355u)

#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[24u].idacComp[2u])
#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP2_OFFSET         (854u)
#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX3_IDAC_COMP2_PARAM_ID       (0x4E000356u)

#define CapSense_TRACKPAD_RX3_TX4_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[25u].raw[0u])
#define CapSense_TRACKPAD_RX3_TX4_RAW0_OFFSET               (856u)
#define CapSense_TRACKPAD_RX3_TX4_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX4_RAW0_PARAM_ID             (0x89000358u)

#define CapSense_TRACKPAD_RX3_TX4_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[25u].raw[1u])
#define CapSense_TRACKPAD_RX3_TX4_RAW1_OFFSET               (858u)
#define CapSense_TRACKPAD_RX3_TX4_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX4_RAW1_PARAM_ID             (0x8500035Au)

#define CapSense_TRACKPAD_RX3_TX4_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[25u].raw[2u])
#define CapSense_TRACKPAD_RX3_TX4_RAW2_OFFSET               (860u)
#define CapSense_TRACKPAD_RX3_TX4_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX4_RAW2_PARAM_ID             (0x8800035Cu)

#define CapSense_TRACKPAD_RX3_TX4_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[25u].bsln[0u])
#define CapSense_TRACKPAD_RX3_TX4_BSLN0_OFFSET              (862u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN0_PARAM_ID            (0x8400035Eu)

#define CapSense_TRACKPAD_RX3_TX4_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[25u].bsln[1u])
#define CapSense_TRACKPAD_RX3_TX4_BSLN1_OFFSET              (864u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN1_PARAM_ID            (0x84000360u)

#define CapSense_TRACKPAD_RX3_TX4_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[25u].bsln[2u])
#define CapSense_TRACKPAD_RX3_TX4_BSLN2_OFFSET              (866u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN2_PARAM_ID            (0x88000362u)

#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[25u].bslnExt[0u])
#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT0_OFFSET          (868u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT0_PARAM_ID        (0x4D000364u)

#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[25u].bslnExt[1u])
#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT1_OFFSET          (869u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT1_PARAM_ID        (0x4B000365u)

#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[25u].bslnExt[2u])
#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT2_OFFSET          (870u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX4_BSLN_EXT2_PARAM_ID        (0x41000366u)

#define CapSense_TRACKPAD_RX3_TX4_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[25u].diff)
#define CapSense_TRACKPAD_RX3_TX4_DIFF_OFFSET               (872u)
#define CapSense_TRACKPAD_RX3_TX4_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX4_DIFF_PARAM_ID             (0x86000368u)

#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[25u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT0_OFFSET  (874u)
#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT0_PARAM_ID (0x4200036Au)

#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[25u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT1_OFFSET  (875u)
#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT1_PARAM_ID (0x4400036Bu)

#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[25u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT2_OFFSET  (876u)
#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX4_NEG_BSLN_RST_CNT2_PARAM_ID (0x4F00036Cu)

#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[25u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT0_OFFSET  (878u)
#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT0_PARAM_ID (0x8B00036Eu)

#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[25u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT1_OFFSET  (880u)
#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT1_PARAM_ID (0x81000370u)

#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[25u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT2_OFFSET  (882u)
#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX4_POS_BLSN_RST_CNT2_PARAM_ID (0x8D000372u)

#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[25u].idacComp[0u])
#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP0_OFFSET         (884u)
#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP0_PARAM_ID       (0x48000374u)

#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[25u].idacComp[1u])
#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP1_OFFSET         (885u)
#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP1_PARAM_ID       (0x4E000375u)

#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[25u].idacComp[2u])
#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP2_OFFSET         (886u)
#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX4_IDAC_COMP2_PARAM_ID       (0x44000376u)

#define CapSense_TRACKPAD_RX3_TX5_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[26u].raw[0u])
#define CapSense_TRACKPAD_RX3_TX5_RAW0_OFFSET               (888u)
#define CapSense_TRACKPAD_RX3_TX5_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX5_RAW0_PARAM_ID             (0x83000378u)

#define CapSense_TRACKPAD_RX3_TX5_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[26u].raw[1u])
#define CapSense_TRACKPAD_RX3_TX5_RAW1_OFFSET               (890u)
#define CapSense_TRACKPAD_RX3_TX5_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX5_RAW1_PARAM_ID             (0x8F00037Au)

#define CapSense_TRACKPAD_RX3_TX5_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[26u].raw[2u])
#define CapSense_TRACKPAD_RX3_TX5_RAW2_OFFSET               (892u)
#define CapSense_TRACKPAD_RX3_TX5_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX5_RAW2_PARAM_ID             (0x8200037Cu)

#define CapSense_TRACKPAD_RX3_TX5_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[26u].bsln[0u])
#define CapSense_TRACKPAD_RX3_TX5_BSLN0_OFFSET              (894u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN0_PARAM_ID            (0x8E00037Eu)

#define CapSense_TRACKPAD_RX3_TX5_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[26u].bsln[1u])
#define CapSense_TRACKPAD_RX3_TX5_BSLN1_OFFSET              (896u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN1_PARAM_ID            (0x80000380u)

#define CapSense_TRACKPAD_RX3_TX5_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[26u].bsln[2u])
#define CapSense_TRACKPAD_RX3_TX5_BSLN2_OFFSET              (898u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN2_PARAM_ID            (0x8C000382u)

#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[26u].bslnExt[0u])
#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT0_OFFSET          (900u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT0_PARAM_ID        (0x49000384u)

#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[26u].bslnExt[1u])
#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT1_OFFSET          (901u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT1_PARAM_ID        (0x4F000385u)

#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[26u].bslnExt[2u])
#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT2_OFFSET          (902u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX5_BSLN_EXT2_PARAM_ID        (0x45000386u)

#define CapSense_TRACKPAD_RX3_TX5_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[26u].diff)
#define CapSense_TRACKPAD_RX3_TX5_DIFF_OFFSET               (904u)
#define CapSense_TRACKPAD_RX3_TX5_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX5_DIFF_PARAM_ID             (0x82000388u)

#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[26u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT0_OFFSET  (906u)
#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT0_PARAM_ID (0x4600038Au)

#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[26u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT1_OFFSET  (907u)
#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT1_PARAM_ID (0x4000038Bu)

#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[26u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT2_OFFSET  (908u)
#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX5_NEG_BSLN_RST_CNT2_PARAM_ID (0x4B00038Cu)

#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[26u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT0_OFFSET  (910u)
#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT0_PARAM_ID (0x8F00038Eu)

#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[26u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT1_OFFSET  (912u)
#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT1_PARAM_ID (0x85000390u)

#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[26u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT2_OFFSET  (914u)
#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX5_POS_BLSN_RST_CNT2_PARAM_ID (0x89000392u)

#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[26u].idacComp[0u])
#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP0_OFFSET         (916u)
#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP0_PARAM_ID       (0x4C000394u)

#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[26u].idacComp[1u])
#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP1_OFFSET         (917u)
#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP1_PARAM_ID       (0x4A000395u)

#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[26u].idacComp[2u])
#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP2_OFFSET         (918u)
#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX5_IDAC_COMP2_PARAM_ID       (0x40000396u)

#define CapSense_TRACKPAD_RX3_TX6_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[27u].raw[0u])
#define CapSense_TRACKPAD_RX3_TX6_RAW0_OFFSET               (920u)
#define CapSense_TRACKPAD_RX3_TX6_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX6_RAW0_PARAM_ID             (0x87000398u)

#define CapSense_TRACKPAD_RX3_TX6_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[27u].raw[1u])
#define CapSense_TRACKPAD_RX3_TX6_RAW1_OFFSET               (922u)
#define CapSense_TRACKPAD_RX3_TX6_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX6_RAW1_PARAM_ID             (0x8B00039Au)

#define CapSense_TRACKPAD_RX3_TX6_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[27u].raw[2u])
#define CapSense_TRACKPAD_RX3_TX6_RAW2_OFFSET               (924u)
#define CapSense_TRACKPAD_RX3_TX6_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX6_RAW2_PARAM_ID             (0x8600039Cu)

#define CapSense_TRACKPAD_RX3_TX6_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[27u].bsln[0u])
#define CapSense_TRACKPAD_RX3_TX6_BSLN0_OFFSET              (926u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN0_PARAM_ID            (0x8A00039Eu)

#define CapSense_TRACKPAD_RX3_TX6_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[27u].bsln[1u])
#define CapSense_TRACKPAD_RX3_TX6_BSLN1_OFFSET              (928u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN1_PARAM_ID            (0x8A0003A0u)

#define CapSense_TRACKPAD_RX3_TX6_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[27u].bsln[2u])
#define CapSense_TRACKPAD_RX3_TX6_BSLN2_OFFSET              (930u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN2_PARAM_ID            (0x860003A2u)

#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[27u].bslnExt[0u])
#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT0_OFFSET          (932u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT0_PARAM_ID        (0x430003A4u)

#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[27u].bslnExt[1u])
#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT1_OFFSET          (933u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT1_PARAM_ID        (0x450003A5u)

#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[27u].bslnExt[2u])
#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT2_OFFSET          (934u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX3_TX6_BSLN_EXT2_PARAM_ID        (0x4F0003A6u)

#define CapSense_TRACKPAD_RX3_TX6_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[27u].diff)
#define CapSense_TRACKPAD_RX3_TX6_DIFF_OFFSET               (936u)
#define CapSense_TRACKPAD_RX3_TX6_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX3_TX6_DIFF_PARAM_ID             (0x880003A8u)

#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[27u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT0_OFFSET  (938u)
#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT0_PARAM_ID (0x4C0003AAu)

#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[27u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT1_OFFSET  (939u)
#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT1_PARAM_ID (0x4A0003ABu)

#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[27u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT2_OFFSET  (940u)
#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX3_TX6_NEG_BSLN_RST_CNT2_PARAM_ID (0x410003ACu)

#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[27u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT0_OFFSET  (942u)
#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT0_PARAM_ID (0x850003AEu)

#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[27u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT1_OFFSET  (944u)
#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT1_PARAM_ID (0x8F0003B0u)

#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[27u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT2_OFFSET  (946u)
#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX3_TX6_POS_BLSN_RST_CNT2_PARAM_ID (0x830003B2u)

#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[27u].idacComp[0u])
#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP0_OFFSET         (948u)
#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP0_PARAM_ID       (0x460003B4u)

#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[27u].idacComp[1u])
#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP1_OFFSET         (949u)
#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP1_PARAM_ID       (0x400003B5u)

#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[27u].idacComp[2u])
#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP2_OFFSET         (950u)
#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX3_TX6_IDAC_COMP2_PARAM_ID       (0x4A0003B6u)

#define CapSense_TRACKPAD_RX4_TX0_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[28u].raw[0u])
#define CapSense_TRACKPAD_RX4_TX0_RAW0_OFFSET               (952u)
#define CapSense_TRACKPAD_RX4_TX0_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX0_RAW0_PARAM_ID             (0x8D0003B8u)

#define CapSense_TRACKPAD_RX4_TX0_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[28u].raw[1u])
#define CapSense_TRACKPAD_RX4_TX0_RAW1_OFFSET               (954u)
#define CapSense_TRACKPAD_RX4_TX0_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX0_RAW1_PARAM_ID             (0x810003BAu)

#define CapSense_TRACKPAD_RX4_TX0_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[28u].raw[2u])
#define CapSense_TRACKPAD_RX4_TX0_RAW2_OFFSET               (956u)
#define CapSense_TRACKPAD_RX4_TX0_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX0_RAW2_PARAM_ID             (0x8C0003BCu)

#define CapSense_TRACKPAD_RX4_TX0_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[28u].bsln[0u])
#define CapSense_TRACKPAD_RX4_TX0_BSLN0_OFFSET              (958u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN0_PARAM_ID            (0x800003BEu)

#define CapSense_TRACKPAD_RX4_TX0_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[28u].bsln[1u])
#define CapSense_TRACKPAD_RX4_TX0_BSLN1_OFFSET              (960u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN1_PARAM_ID            (0x8D0003C0u)

#define CapSense_TRACKPAD_RX4_TX0_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[28u].bsln[2u])
#define CapSense_TRACKPAD_RX4_TX0_BSLN2_OFFSET              (962u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN2_PARAM_ID            (0x810003C2u)

#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[28u].bslnExt[0u])
#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT0_OFFSET          (964u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT0_PARAM_ID        (0x440003C4u)

#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[28u].bslnExt[1u])
#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT1_OFFSET          (965u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT1_PARAM_ID        (0x420003C5u)

#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[28u].bslnExt[2u])
#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT2_OFFSET          (966u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX0_BSLN_EXT2_PARAM_ID        (0x480003C6u)

#define CapSense_TRACKPAD_RX4_TX0_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[28u].diff)
#define CapSense_TRACKPAD_RX4_TX0_DIFF_OFFSET               (968u)
#define CapSense_TRACKPAD_RX4_TX0_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX0_DIFF_PARAM_ID             (0x8F0003C8u)

#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[28u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT0_OFFSET  (970u)
#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT0_PARAM_ID (0x4B0003CAu)

#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[28u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT1_OFFSET  (971u)
#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT1_PARAM_ID (0x4D0003CBu)

#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[28u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT2_OFFSET  (972u)
#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX0_NEG_BSLN_RST_CNT2_PARAM_ID (0x460003CCu)

#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[28u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT0_OFFSET  (974u)
#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT0_PARAM_ID (0x820003CEu)

#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[28u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT1_OFFSET  (976u)
#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT1_PARAM_ID (0x880003D0u)

#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[28u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT2_OFFSET  (978u)
#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX0_POS_BLSN_RST_CNT2_PARAM_ID (0x840003D2u)

#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[28u].idacComp[0u])
#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP0_OFFSET         (980u)
#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP0_PARAM_ID       (0x410003D4u)

#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[28u].idacComp[1u])
#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP1_OFFSET         (981u)
#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP1_PARAM_ID       (0x470003D5u)

#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[28u].idacComp[2u])
#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP2_OFFSET         (982u)
#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX0_IDAC_COMP2_PARAM_ID       (0x4D0003D6u)

#define CapSense_TRACKPAD_RX4_TX1_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[29u].raw[0u])
#define CapSense_TRACKPAD_RX4_TX1_RAW0_OFFSET               (984u)
#define CapSense_TRACKPAD_RX4_TX1_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX1_RAW0_PARAM_ID             (0x8A0003D8u)

#define CapSense_TRACKPAD_RX4_TX1_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[29u].raw[1u])
#define CapSense_TRACKPAD_RX4_TX1_RAW1_OFFSET               (986u)
#define CapSense_TRACKPAD_RX4_TX1_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX1_RAW1_PARAM_ID             (0x860003DAu)

#define CapSense_TRACKPAD_RX4_TX1_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[29u].raw[2u])
#define CapSense_TRACKPAD_RX4_TX1_RAW2_OFFSET               (988u)
#define CapSense_TRACKPAD_RX4_TX1_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX1_RAW2_PARAM_ID             (0x8B0003DCu)

#define CapSense_TRACKPAD_RX4_TX1_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[29u].bsln[0u])
#define CapSense_TRACKPAD_RX4_TX1_BSLN0_OFFSET              (990u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN0_PARAM_ID            (0x870003DEu)

#define CapSense_TRACKPAD_RX4_TX1_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[29u].bsln[1u])
#define CapSense_TRACKPAD_RX4_TX1_BSLN1_OFFSET              (992u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN1_PARAM_ID            (0x870003E0u)

#define CapSense_TRACKPAD_RX4_TX1_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[29u].bsln[2u])
#define CapSense_TRACKPAD_RX4_TX1_BSLN2_OFFSET              (994u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN2_PARAM_ID            (0x8B0003E2u)

#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[29u].bslnExt[0u])
#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT0_OFFSET          (996u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT0_PARAM_ID        (0x4E0003E4u)

#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[29u].bslnExt[1u])
#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT1_OFFSET          (997u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT1_PARAM_ID        (0x480003E5u)

#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[29u].bslnExt[2u])
#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT2_OFFSET          (998u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX1_BSLN_EXT2_PARAM_ID        (0x420003E6u)

#define CapSense_TRACKPAD_RX4_TX1_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[29u].diff)
#define CapSense_TRACKPAD_RX4_TX1_DIFF_OFFSET               (1000u)
#define CapSense_TRACKPAD_RX4_TX1_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX1_DIFF_PARAM_ID             (0x850003E8u)

#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[29u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT0_OFFSET  (1002u)
#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT0_PARAM_ID (0x410003EAu)

#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[29u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT1_OFFSET  (1003u)
#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT1_PARAM_ID (0x470003EBu)

#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[29u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT2_OFFSET  (1004u)
#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX1_NEG_BSLN_RST_CNT2_PARAM_ID (0x4C0003ECu)

#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[29u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT0_OFFSET  (1006u)
#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT0_PARAM_ID (0x880003EEu)

#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[29u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT1_OFFSET  (1008u)
#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT1_PARAM_ID (0x820003F0u)

#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[29u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT2_OFFSET  (1010u)
#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX1_POS_BLSN_RST_CNT2_PARAM_ID (0x8E0003F2u)

#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[29u].idacComp[0u])
#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP0_OFFSET         (1012u)
#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP0_PARAM_ID       (0x4B0003F4u)

#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[29u].idacComp[1u])
#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP1_OFFSET         (1013u)
#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP1_PARAM_ID       (0x4D0003F5u)

#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[29u].idacComp[2u])
#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP2_OFFSET         (1014u)
#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX1_IDAC_COMP2_PARAM_ID       (0x470003F6u)

#define CapSense_TRACKPAD_RX4_TX2_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[30u].raw[0u])
#define CapSense_TRACKPAD_RX4_TX2_RAW0_OFFSET               (1016u)
#define CapSense_TRACKPAD_RX4_TX2_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX2_RAW0_PARAM_ID             (0x800003F8u)

#define CapSense_TRACKPAD_RX4_TX2_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[30u].raw[1u])
#define CapSense_TRACKPAD_RX4_TX2_RAW1_OFFSET               (1018u)
#define CapSense_TRACKPAD_RX4_TX2_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX2_RAW1_PARAM_ID             (0x8C0003FAu)

#define CapSense_TRACKPAD_RX4_TX2_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[30u].raw[2u])
#define CapSense_TRACKPAD_RX4_TX2_RAW2_OFFSET               (1020u)
#define CapSense_TRACKPAD_RX4_TX2_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX2_RAW2_PARAM_ID             (0x810003FCu)

#define CapSense_TRACKPAD_RX4_TX2_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[30u].bsln[0u])
#define CapSense_TRACKPAD_RX4_TX2_BSLN0_OFFSET              (1022u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN0_PARAM_ID            (0x8D0003FEu)

#define CapSense_TRACKPAD_RX4_TX2_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[30u].bsln[1u])
#define CapSense_TRACKPAD_RX4_TX2_BSLN1_OFFSET              (1024u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN1_PARAM_ID            (0x80000400u)

#define CapSense_TRACKPAD_RX4_TX2_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[30u].bsln[2u])
#define CapSense_TRACKPAD_RX4_TX2_BSLN2_OFFSET              (1026u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN2_PARAM_ID            (0x8C000402u)

#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[30u].bslnExt[0u])
#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT0_OFFSET          (1028u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT0_PARAM_ID        (0x49000404u)

#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[30u].bslnExt[1u])
#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT1_OFFSET          (1029u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT1_PARAM_ID        (0x4F000405u)

#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[30u].bslnExt[2u])
#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT2_OFFSET          (1030u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX2_BSLN_EXT2_PARAM_ID        (0x45000406u)

#define CapSense_TRACKPAD_RX4_TX2_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[30u].diff)
#define CapSense_TRACKPAD_RX4_TX2_DIFF_OFFSET               (1032u)
#define CapSense_TRACKPAD_RX4_TX2_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX2_DIFF_PARAM_ID             (0x82000408u)

#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[30u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT0_OFFSET  (1034u)
#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT0_PARAM_ID (0x4600040Au)

#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[30u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT1_OFFSET  (1035u)
#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT1_PARAM_ID (0x4000040Bu)

#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[30u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT2_OFFSET  (1036u)
#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX2_NEG_BSLN_RST_CNT2_PARAM_ID (0x4B00040Cu)

#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[30u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT0_OFFSET  (1038u)
#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT0_PARAM_ID (0x8F00040Eu)

#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[30u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT1_OFFSET  (1040u)
#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT1_PARAM_ID (0x85000410u)

#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[30u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT2_OFFSET  (1042u)
#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX2_POS_BLSN_RST_CNT2_PARAM_ID (0x89000412u)

#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[30u].idacComp[0u])
#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP0_OFFSET         (1044u)
#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP0_PARAM_ID       (0x4C000414u)

#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[30u].idacComp[1u])
#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP1_OFFSET         (1045u)
#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP1_PARAM_ID       (0x4A000415u)

#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[30u].idacComp[2u])
#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP2_OFFSET         (1046u)
#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX2_IDAC_COMP2_PARAM_ID       (0x40000416u)

#define CapSense_TRACKPAD_RX4_TX3_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[31u].raw[0u])
#define CapSense_TRACKPAD_RX4_TX3_RAW0_OFFSET               (1048u)
#define CapSense_TRACKPAD_RX4_TX3_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX3_RAW0_PARAM_ID             (0x87000418u)

#define CapSense_TRACKPAD_RX4_TX3_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[31u].raw[1u])
#define CapSense_TRACKPAD_RX4_TX3_RAW1_OFFSET               (1050u)
#define CapSense_TRACKPAD_RX4_TX3_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX3_RAW1_PARAM_ID             (0x8B00041Au)

#define CapSense_TRACKPAD_RX4_TX3_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[31u].raw[2u])
#define CapSense_TRACKPAD_RX4_TX3_RAW2_OFFSET               (1052u)
#define CapSense_TRACKPAD_RX4_TX3_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX3_RAW2_PARAM_ID             (0x8600041Cu)

#define CapSense_TRACKPAD_RX4_TX3_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[31u].bsln[0u])
#define CapSense_TRACKPAD_RX4_TX3_BSLN0_OFFSET              (1054u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN0_PARAM_ID            (0x8A00041Eu)

#define CapSense_TRACKPAD_RX4_TX3_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[31u].bsln[1u])
#define CapSense_TRACKPAD_RX4_TX3_BSLN1_OFFSET              (1056u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN1_PARAM_ID            (0x8A000420u)

#define CapSense_TRACKPAD_RX4_TX3_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[31u].bsln[2u])
#define CapSense_TRACKPAD_RX4_TX3_BSLN2_OFFSET              (1058u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN2_PARAM_ID            (0x86000422u)

#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[31u].bslnExt[0u])
#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT0_OFFSET          (1060u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT0_PARAM_ID        (0x43000424u)

#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[31u].bslnExt[1u])
#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT1_OFFSET          (1061u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT1_PARAM_ID        (0x45000425u)

#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[31u].bslnExt[2u])
#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT2_OFFSET          (1062u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX3_BSLN_EXT2_PARAM_ID        (0x4F000426u)

#define CapSense_TRACKPAD_RX4_TX3_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[31u].diff)
#define CapSense_TRACKPAD_RX4_TX3_DIFF_OFFSET               (1064u)
#define CapSense_TRACKPAD_RX4_TX3_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX3_DIFF_PARAM_ID             (0x88000428u)

#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[31u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT0_OFFSET  (1066u)
#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT0_PARAM_ID (0x4C00042Au)

#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[31u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT1_OFFSET  (1067u)
#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT1_PARAM_ID (0x4A00042Bu)

#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[31u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT2_OFFSET  (1068u)
#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX3_NEG_BSLN_RST_CNT2_PARAM_ID (0x4100042Cu)

#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[31u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT0_OFFSET  (1070u)
#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT0_PARAM_ID (0x8500042Eu)

#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[31u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT1_OFFSET  (1072u)
#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT1_PARAM_ID (0x8F000430u)

#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[31u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT2_OFFSET  (1074u)
#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX3_POS_BLSN_RST_CNT2_PARAM_ID (0x83000432u)

#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[31u].idacComp[0u])
#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP0_OFFSET         (1076u)
#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP0_PARAM_ID       (0x46000434u)

#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[31u].idacComp[1u])
#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP1_OFFSET         (1077u)
#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP1_PARAM_ID       (0x40000435u)

#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[31u].idacComp[2u])
#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP2_OFFSET         (1078u)
#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX3_IDAC_COMP2_PARAM_ID       (0x4A000436u)

#define CapSense_TRACKPAD_RX4_TX4_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[32u].raw[0u])
#define CapSense_TRACKPAD_RX4_TX4_RAW0_OFFSET               (1080u)
#define CapSense_TRACKPAD_RX4_TX4_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX4_RAW0_PARAM_ID             (0x8D000438u)

#define CapSense_TRACKPAD_RX4_TX4_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[32u].raw[1u])
#define CapSense_TRACKPAD_RX4_TX4_RAW1_OFFSET               (1082u)
#define CapSense_TRACKPAD_RX4_TX4_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX4_RAW1_PARAM_ID             (0x8100043Au)

#define CapSense_TRACKPAD_RX4_TX4_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[32u].raw[2u])
#define CapSense_TRACKPAD_RX4_TX4_RAW2_OFFSET               (1084u)
#define CapSense_TRACKPAD_RX4_TX4_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX4_RAW2_PARAM_ID             (0x8C00043Cu)

#define CapSense_TRACKPAD_RX4_TX4_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[32u].bsln[0u])
#define CapSense_TRACKPAD_RX4_TX4_BSLN0_OFFSET              (1086u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN0_PARAM_ID            (0x8000043Eu)

#define CapSense_TRACKPAD_RX4_TX4_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[32u].bsln[1u])
#define CapSense_TRACKPAD_RX4_TX4_BSLN1_OFFSET              (1088u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN1_PARAM_ID            (0x8D000440u)

#define CapSense_TRACKPAD_RX4_TX4_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[32u].bsln[2u])
#define CapSense_TRACKPAD_RX4_TX4_BSLN2_OFFSET              (1090u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN2_PARAM_ID            (0x81000442u)

#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[32u].bslnExt[0u])
#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT0_OFFSET          (1092u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT0_PARAM_ID        (0x44000444u)

#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[32u].bslnExt[1u])
#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT1_OFFSET          (1093u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT1_PARAM_ID        (0x42000445u)

#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[32u].bslnExt[2u])
#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT2_OFFSET          (1094u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX4_BSLN_EXT2_PARAM_ID        (0x48000446u)

#define CapSense_TRACKPAD_RX4_TX4_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[32u].diff)
#define CapSense_TRACKPAD_RX4_TX4_DIFF_OFFSET               (1096u)
#define CapSense_TRACKPAD_RX4_TX4_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX4_DIFF_PARAM_ID             (0x8F000448u)

#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[32u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT0_OFFSET  (1098u)
#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT0_PARAM_ID (0x4B00044Au)

#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[32u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT1_OFFSET  (1099u)
#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT1_PARAM_ID (0x4D00044Bu)

#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[32u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT2_OFFSET  (1100u)
#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX4_NEG_BSLN_RST_CNT2_PARAM_ID (0x4600044Cu)

#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[32u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT0_OFFSET  (1102u)
#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT0_PARAM_ID (0x8200044Eu)

#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[32u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT1_OFFSET  (1104u)
#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT1_PARAM_ID (0x88000450u)

#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[32u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT2_OFFSET  (1106u)
#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX4_POS_BLSN_RST_CNT2_PARAM_ID (0x84000452u)

#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[32u].idacComp[0u])
#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP0_OFFSET         (1108u)
#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP0_PARAM_ID       (0x41000454u)

#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[32u].idacComp[1u])
#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP1_OFFSET         (1109u)
#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP1_PARAM_ID       (0x47000455u)

#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[32u].idacComp[2u])
#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP2_OFFSET         (1110u)
#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX4_IDAC_COMP2_PARAM_ID       (0x4D000456u)

#define CapSense_TRACKPAD_RX4_TX5_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[33u].raw[0u])
#define CapSense_TRACKPAD_RX4_TX5_RAW0_OFFSET               (1112u)
#define CapSense_TRACKPAD_RX4_TX5_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX5_RAW0_PARAM_ID             (0x8A000458u)

#define CapSense_TRACKPAD_RX4_TX5_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[33u].raw[1u])
#define CapSense_TRACKPAD_RX4_TX5_RAW1_OFFSET               (1114u)
#define CapSense_TRACKPAD_RX4_TX5_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX5_RAW1_PARAM_ID             (0x8600045Au)

#define CapSense_TRACKPAD_RX4_TX5_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[33u].raw[2u])
#define CapSense_TRACKPAD_RX4_TX5_RAW2_OFFSET               (1116u)
#define CapSense_TRACKPAD_RX4_TX5_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX5_RAW2_PARAM_ID             (0x8B00045Cu)

#define CapSense_TRACKPAD_RX4_TX5_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[33u].bsln[0u])
#define CapSense_TRACKPAD_RX4_TX5_BSLN0_OFFSET              (1118u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN0_PARAM_ID            (0x8700045Eu)

#define CapSense_TRACKPAD_RX4_TX5_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[33u].bsln[1u])
#define CapSense_TRACKPAD_RX4_TX5_BSLN1_OFFSET              (1120u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN1_PARAM_ID            (0x87000460u)

#define CapSense_TRACKPAD_RX4_TX5_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[33u].bsln[2u])
#define CapSense_TRACKPAD_RX4_TX5_BSLN2_OFFSET              (1122u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN2_PARAM_ID            (0x8B000462u)

#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[33u].bslnExt[0u])
#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT0_OFFSET          (1124u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT0_PARAM_ID        (0x4E000464u)

#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[33u].bslnExt[1u])
#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT1_OFFSET          (1125u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT1_PARAM_ID        (0x48000465u)

#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[33u].bslnExt[2u])
#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT2_OFFSET          (1126u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX5_BSLN_EXT2_PARAM_ID        (0x42000466u)

#define CapSense_TRACKPAD_RX4_TX5_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[33u].diff)
#define CapSense_TRACKPAD_RX4_TX5_DIFF_OFFSET               (1128u)
#define CapSense_TRACKPAD_RX4_TX5_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX5_DIFF_PARAM_ID             (0x85000468u)

#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[33u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT0_OFFSET  (1130u)
#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT0_PARAM_ID (0x4100046Au)

#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[33u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT1_OFFSET  (1131u)
#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT1_PARAM_ID (0x4700046Bu)

#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[33u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT2_OFFSET  (1132u)
#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX5_NEG_BSLN_RST_CNT2_PARAM_ID (0x4C00046Cu)

#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[33u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT0_OFFSET  (1134u)
#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT0_PARAM_ID (0x8800046Eu)

#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[33u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT1_OFFSET  (1136u)
#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT1_PARAM_ID (0x82000470u)

#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[33u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT2_OFFSET  (1138u)
#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX5_POS_BLSN_RST_CNT2_PARAM_ID (0x8E000472u)

#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[33u].idacComp[0u])
#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP0_OFFSET         (1140u)
#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP0_PARAM_ID       (0x4B000474u)

#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[33u].idacComp[1u])
#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP1_OFFSET         (1141u)
#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP1_PARAM_ID       (0x4D000475u)

#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[33u].idacComp[2u])
#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP2_OFFSET         (1142u)
#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX5_IDAC_COMP2_PARAM_ID       (0x47000476u)

#define CapSense_TRACKPAD_RX4_TX6_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[34u].raw[0u])
#define CapSense_TRACKPAD_RX4_TX6_RAW0_OFFSET               (1144u)
#define CapSense_TRACKPAD_RX4_TX6_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX6_RAW0_PARAM_ID             (0x80000478u)

#define CapSense_TRACKPAD_RX4_TX6_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[34u].raw[1u])
#define CapSense_TRACKPAD_RX4_TX6_RAW1_OFFSET               (1146u)
#define CapSense_TRACKPAD_RX4_TX6_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX6_RAW1_PARAM_ID             (0x8C00047Au)

#define CapSense_TRACKPAD_RX4_TX6_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[34u].raw[2u])
#define CapSense_TRACKPAD_RX4_TX6_RAW2_OFFSET               (1148u)
#define CapSense_TRACKPAD_RX4_TX6_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX6_RAW2_PARAM_ID             (0x8100047Cu)

#define CapSense_TRACKPAD_RX4_TX6_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[34u].bsln[0u])
#define CapSense_TRACKPAD_RX4_TX6_BSLN0_OFFSET              (1150u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN0_PARAM_ID            (0x8D00047Eu)

#define CapSense_TRACKPAD_RX4_TX6_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[34u].bsln[1u])
#define CapSense_TRACKPAD_RX4_TX6_BSLN1_OFFSET              (1152u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN1_PARAM_ID            (0x83000480u)

#define CapSense_TRACKPAD_RX4_TX6_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[34u].bsln[2u])
#define CapSense_TRACKPAD_RX4_TX6_BSLN2_OFFSET              (1154u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN2_PARAM_ID            (0x8F000482u)

#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[34u].bslnExt[0u])
#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT0_OFFSET          (1156u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT0_PARAM_ID        (0x4A000484u)

#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[34u].bslnExt[1u])
#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT1_OFFSET          (1157u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT1_PARAM_ID        (0x4C000485u)

#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[34u].bslnExt[2u])
#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT2_OFFSET          (1158u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX4_TX6_BSLN_EXT2_PARAM_ID        (0x46000486u)

#define CapSense_TRACKPAD_RX4_TX6_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[34u].diff)
#define CapSense_TRACKPAD_RX4_TX6_DIFF_OFFSET               (1160u)
#define CapSense_TRACKPAD_RX4_TX6_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX4_TX6_DIFF_PARAM_ID             (0x81000488u)

#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[34u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT0_OFFSET  (1162u)
#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT0_PARAM_ID (0x4500048Au)

#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[34u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT1_OFFSET  (1163u)
#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT1_PARAM_ID (0x4300048Bu)

#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[34u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT2_OFFSET  (1164u)
#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX4_TX6_NEG_BSLN_RST_CNT2_PARAM_ID (0x4800048Cu)

#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[34u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT0_OFFSET  (1166u)
#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT0_PARAM_ID (0x8C00048Eu)

#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[34u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT1_OFFSET  (1168u)
#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT1_PARAM_ID (0x86000490u)

#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[34u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT2_OFFSET  (1170u)
#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX4_TX6_POS_BLSN_RST_CNT2_PARAM_ID (0x8A000492u)

#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[34u].idacComp[0u])
#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP0_OFFSET         (1172u)
#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP0_PARAM_ID       (0x4F000494u)

#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[34u].idacComp[1u])
#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP1_OFFSET         (1173u)
#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP1_PARAM_ID       (0x49000495u)

#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[34u].idacComp[2u])
#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP2_OFFSET         (1174u)
#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX4_TX6_IDAC_COMP2_PARAM_ID       (0x43000496u)

#define CapSense_TRACKPAD_RX5_TX0_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[35u].raw[0u])
#define CapSense_TRACKPAD_RX5_TX0_RAW0_OFFSET               (1176u)
#define CapSense_TRACKPAD_RX5_TX0_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX0_RAW0_PARAM_ID             (0x84000498u)

#define CapSense_TRACKPAD_RX5_TX0_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[35u].raw[1u])
#define CapSense_TRACKPAD_RX5_TX0_RAW1_OFFSET               (1178u)
#define CapSense_TRACKPAD_RX5_TX0_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX0_RAW1_PARAM_ID             (0x8800049Au)

#define CapSense_TRACKPAD_RX5_TX0_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[35u].raw[2u])
#define CapSense_TRACKPAD_RX5_TX0_RAW2_OFFSET               (1180u)
#define CapSense_TRACKPAD_RX5_TX0_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX0_RAW2_PARAM_ID             (0x8500049Cu)

#define CapSense_TRACKPAD_RX5_TX0_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[35u].bsln[0u])
#define CapSense_TRACKPAD_RX5_TX0_BSLN0_OFFSET              (1182u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN0_PARAM_ID            (0x8900049Eu)

#define CapSense_TRACKPAD_RX5_TX0_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[35u].bsln[1u])
#define CapSense_TRACKPAD_RX5_TX0_BSLN1_OFFSET              (1184u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN1_PARAM_ID            (0x890004A0u)

#define CapSense_TRACKPAD_RX5_TX0_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[35u].bsln[2u])
#define CapSense_TRACKPAD_RX5_TX0_BSLN2_OFFSET              (1186u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN2_PARAM_ID            (0x850004A2u)

#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[35u].bslnExt[0u])
#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT0_OFFSET          (1188u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT0_PARAM_ID        (0x400004A4u)

#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[35u].bslnExt[1u])
#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT1_OFFSET          (1189u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT1_PARAM_ID        (0x460004A5u)

#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[35u].bslnExt[2u])
#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT2_OFFSET          (1190u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX0_BSLN_EXT2_PARAM_ID        (0x4C0004A6u)

#define CapSense_TRACKPAD_RX5_TX0_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[35u].diff)
#define CapSense_TRACKPAD_RX5_TX0_DIFF_OFFSET               (1192u)
#define CapSense_TRACKPAD_RX5_TX0_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX0_DIFF_PARAM_ID             (0x8B0004A8u)

#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[35u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT0_OFFSET  (1194u)
#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT0_PARAM_ID (0x4F0004AAu)

#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[35u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT1_OFFSET  (1195u)
#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT1_PARAM_ID (0x490004ABu)

#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[35u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT2_OFFSET  (1196u)
#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX0_NEG_BSLN_RST_CNT2_PARAM_ID (0x420004ACu)

#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[35u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT0_OFFSET  (1198u)
#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT0_PARAM_ID (0x860004AEu)

#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[35u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT1_OFFSET  (1200u)
#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT1_PARAM_ID (0x8C0004B0u)

#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[35u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT2_OFFSET  (1202u)
#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX0_POS_BLSN_RST_CNT2_PARAM_ID (0x800004B2u)

#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[35u].idacComp[0u])
#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP0_OFFSET         (1204u)
#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP0_PARAM_ID       (0x450004B4u)

#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[35u].idacComp[1u])
#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP1_OFFSET         (1205u)
#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP1_PARAM_ID       (0x430004B5u)

#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[35u].idacComp[2u])
#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP2_OFFSET         (1206u)
#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX0_IDAC_COMP2_PARAM_ID       (0x490004B6u)

#define CapSense_TRACKPAD_RX5_TX1_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[36u].raw[0u])
#define CapSense_TRACKPAD_RX5_TX1_RAW0_OFFSET               (1208u)
#define CapSense_TRACKPAD_RX5_TX1_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX1_RAW0_PARAM_ID             (0x8E0004B8u)

#define CapSense_TRACKPAD_RX5_TX1_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[36u].raw[1u])
#define CapSense_TRACKPAD_RX5_TX1_RAW1_OFFSET               (1210u)
#define CapSense_TRACKPAD_RX5_TX1_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX1_RAW1_PARAM_ID             (0x820004BAu)

#define CapSense_TRACKPAD_RX5_TX1_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[36u].raw[2u])
#define CapSense_TRACKPAD_RX5_TX1_RAW2_OFFSET               (1212u)
#define CapSense_TRACKPAD_RX5_TX1_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX1_RAW2_PARAM_ID             (0x8F0004BCu)

#define CapSense_TRACKPAD_RX5_TX1_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[36u].bsln[0u])
#define CapSense_TRACKPAD_RX5_TX1_BSLN0_OFFSET              (1214u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN0_PARAM_ID            (0x830004BEu)

#define CapSense_TRACKPAD_RX5_TX1_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[36u].bsln[1u])
#define CapSense_TRACKPAD_RX5_TX1_BSLN1_OFFSET              (1216u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN1_PARAM_ID            (0x8E0004C0u)

#define CapSense_TRACKPAD_RX5_TX1_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[36u].bsln[2u])
#define CapSense_TRACKPAD_RX5_TX1_BSLN2_OFFSET              (1218u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN2_PARAM_ID            (0x820004C2u)

#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[36u].bslnExt[0u])
#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT0_OFFSET          (1220u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT0_PARAM_ID        (0x470004C4u)

#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[36u].bslnExt[1u])
#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT1_OFFSET          (1221u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT1_PARAM_ID        (0x410004C5u)

#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[36u].bslnExt[2u])
#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT2_OFFSET          (1222u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX1_BSLN_EXT2_PARAM_ID        (0x4B0004C6u)

#define CapSense_TRACKPAD_RX5_TX1_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[36u].diff)
#define CapSense_TRACKPAD_RX5_TX1_DIFF_OFFSET               (1224u)
#define CapSense_TRACKPAD_RX5_TX1_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX1_DIFF_PARAM_ID             (0x8C0004C8u)

#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[36u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT0_OFFSET  (1226u)
#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT0_PARAM_ID (0x480004CAu)

#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[36u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT1_OFFSET  (1227u)
#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT1_PARAM_ID (0x4E0004CBu)

#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[36u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT2_OFFSET  (1228u)
#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX1_NEG_BSLN_RST_CNT2_PARAM_ID (0x450004CCu)

#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[36u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT0_OFFSET  (1230u)
#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT0_PARAM_ID (0x810004CEu)

#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[36u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT1_OFFSET  (1232u)
#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT1_PARAM_ID (0x8B0004D0u)

#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[36u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT2_OFFSET  (1234u)
#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX1_POS_BLSN_RST_CNT2_PARAM_ID (0x870004D2u)

#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[36u].idacComp[0u])
#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP0_OFFSET         (1236u)
#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP0_PARAM_ID       (0x420004D4u)

#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[36u].idacComp[1u])
#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP1_OFFSET         (1237u)
#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP1_PARAM_ID       (0x440004D5u)

#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[36u].idacComp[2u])
#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP2_OFFSET         (1238u)
#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX1_IDAC_COMP2_PARAM_ID       (0x4E0004D6u)

#define CapSense_TRACKPAD_RX5_TX2_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[37u].raw[0u])
#define CapSense_TRACKPAD_RX5_TX2_RAW0_OFFSET               (1240u)
#define CapSense_TRACKPAD_RX5_TX2_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX2_RAW0_PARAM_ID             (0x890004D8u)

#define CapSense_TRACKPAD_RX5_TX2_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[37u].raw[1u])
#define CapSense_TRACKPAD_RX5_TX2_RAW1_OFFSET               (1242u)
#define CapSense_TRACKPAD_RX5_TX2_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX2_RAW1_PARAM_ID             (0x850004DAu)

#define CapSense_TRACKPAD_RX5_TX2_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[37u].raw[2u])
#define CapSense_TRACKPAD_RX5_TX2_RAW2_OFFSET               (1244u)
#define CapSense_TRACKPAD_RX5_TX2_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX2_RAW2_PARAM_ID             (0x880004DCu)

#define CapSense_TRACKPAD_RX5_TX2_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[37u].bsln[0u])
#define CapSense_TRACKPAD_RX5_TX2_BSLN0_OFFSET              (1246u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN0_PARAM_ID            (0x840004DEu)

#define CapSense_TRACKPAD_RX5_TX2_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[37u].bsln[1u])
#define CapSense_TRACKPAD_RX5_TX2_BSLN1_OFFSET              (1248u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN1_PARAM_ID            (0x840004E0u)

#define CapSense_TRACKPAD_RX5_TX2_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[37u].bsln[2u])
#define CapSense_TRACKPAD_RX5_TX2_BSLN2_OFFSET              (1250u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN2_PARAM_ID            (0x880004E2u)

#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[37u].bslnExt[0u])
#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT0_OFFSET          (1252u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT0_PARAM_ID        (0x4D0004E4u)

#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[37u].bslnExt[1u])
#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT1_OFFSET          (1253u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT1_PARAM_ID        (0x4B0004E5u)

#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[37u].bslnExt[2u])
#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT2_OFFSET          (1254u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX2_BSLN_EXT2_PARAM_ID        (0x410004E6u)

#define CapSense_TRACKPAD_RX5_TX2_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[37u].diff)
#define CapSense_TRACKPAD_RX5_TX2_DIFF_OFFSET               (1256u)
#define CapSense_TRACKPAD_RX5_TX2_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX2_DIFF_PARAM_ID             (0x860004E8u)

#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[37u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT0_OFFSET  (1258u)
#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT0_PARAM_ID (0x420004EAu)

#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[37u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT1_OFFSET  (1259u)
#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT1_PARAM_ID (0x440004EBu)

#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[37u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT2_OFFSET  (1260u)
#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX2_NEG_BSLN_RST_CNT2_PARAM_ID (0x4F0004ECu)

#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[37u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT0_OFFSET  (1262u)
#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT0_PARAM_ID (0x8B0004EEu)

#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[37u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT1_OFFSET  (1264u)
#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT1_PARAM_ID (0x810004F0u)

#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[37u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT2_OFFSET  (1266u)
#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX2_POS_BLSN_RST_CNT2_PARAM_ID (0x8D0004F2u)

#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[37u].idacComp[0u])
#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP0_OFFSET         (1268u)
#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP0_PARAM_ID       (0x480004F4u)

#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[37u].idacComp[1u])
#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP1_OFFSET         (1269u)
#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP1_PARAM_ID       (0x4E0004F5u)

#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[37u].idacComp[2u])
#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP2_OFFSET         (1270u)
#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX2_IDAC_COMP2_PARAM_ID       (0x440004F6u)

#define CapSense_TRACKPAD_RX5_TX3_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[38u].raw[0u])
#define CapSense_TRACKPAD_RX5_TX3_RAW0_OFFSET               (1272u)
#define CapSense_TRACKPAD_RX5_TX3_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX3_RAW0_PARAM_ID             (0x830004F8u)

#define CapSense_TRACKPAD_RX5_TX3_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[38u].raw[1u])
#define CapSense_TRACKPAD_RX5_TX3_RAW1_OFFSET               (1274u)
#define CapSense_TRACKPAD_RX5_TX3_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX3_RAW1_PARAM_ID             (0x8F0004FAu)

#define CapSense_TRACKPAD_RX5_TX3_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[38u].raw[2u])
#define CapSense_TRACKPAD_RX5_TX3_RAW2_OFFSET               (1276u)
#define CapSense_TRACKPAD_RX5_TX3_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX3_RAW2_PARAM_ID             (0x820004FCu)

#define CapSense_TRACKPAD_RX5_TX3_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[38u].bsln[0u])
#define CapSense_TRACKPAD_RX5_TX3_BSLN0_OFFSET              (1278u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN0_PARAM_ID            (0x8E0004FEu)

#define CapSense_TRACKPAD_RX5_TX3_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[38u].bsln[1u])
#define CapSense_TRACKPAD_RX5_TX3_BSLN1_OFFSET              (1280u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN1_PARAM_ID            (0x8B000500u)

#define CapSense_TRACKPAD_RX5_TX3_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[38u].bsln[2u])
#define CapSense_TRACKPAD_RX5_TX3_BSLN2_OFFSET              (1282u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN2_PARAM_ID            (0x87000502u)

#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[38u].bslnExt[0u])
#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT0_OFFSET          (1284u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT0_PARAM_ID        (0x42000504u)

#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[38u].bslnExt[1u])
#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT1_OFFSET          (1285u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT1_PARAM_ID        (0x44000505u)

#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[38u].bslnExt[2u])
#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT2_OFFSET          (1286u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX3_BSLN_EXT2_PARAM_ID        (0x4E000506u)

#define CapSense_TRACKPAD_RX5_TX3_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[38u].diff)
#define CapSense_TRACKPAD_RX5_TX3_DIFF_OFFSET               (1288u)
#define CapSense_TRACKPAD_RX5_TX3_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX3_DIFF_PARAM_ID             (0x89000508u)

#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[38u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT0_OFFSET  (1290u)
#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT0_PARAM_ID (0x4D00050Au)

#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[38u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT1_OFFSET  (1291u)
#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT1_PARAM_ID (0x4B00050Bu)

#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[38u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT2_OFFSET  (1292u)
#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX3_NEG_BSLN_RST_CNT2_PARAM_ID (0x4000050Cu)

#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[38u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT0_OFFSET  (1294u)
#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT0_PARAM_ID (0x8400050Eu)

#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[38u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT1_OFFSET  (1296u)
#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT1_PARAM_ID (0x8E000510u)

#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[38u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT2_OFFSET  (1298u)
#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX3_POS_BLSN_RST_CNT2_PARAM_ID (0x82000512u)

#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[38u].idacComp[0u])
#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP0_OFFSET         (1300u)
#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP0_PARAM_ID       (0x47000514u)

#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[38u].idacComp[1u])
#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP1_OFFSET         (1301u)
#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP1_PARAM_ID       (0x41000515u)

#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[38u].idacComp[2u])
#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP2_OFFSET         (1302u)
#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX3_IDAC_COMP2_PARAM_ID       (0x4B000516u)

#define CapSense_TRACKPAD_RX5_TX4_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[39u].raw[0u])
#define CapSense_TRACKPAD_RX5_TX4_RAW0_OFFSET               (1304u)
#define CapSense_TRACKPAD_RX5_TX4_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX4_RAW0_PARAM_ID             (0x8C000518u)

#define CapSense_TRACKPAD_RX5_TX4_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[39u].raw[1u])
#define CapSense_TRACKPAD_RX5_TX4_RAW1_OFFSET               (1306u)
#define CapSense_TRACKPAD_RX5_TX4_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX4_RAW1_PARAM_ID             (0x8000051Au)

#define CapSense_TRACKPAD_RX5_TX4_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[39u].raw[2u])
#define CapSense_TRACKPAD_RX5_TX4_RAW2_OFFSET               (1308u)
#define CapSense_TRACKPAD_RX5_TX4_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX4_RAW2_PARAM_ID             (0x8D00051Cu)

#define CapSense_TRACKPAD_RX5_TX4_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[39u].bsln[0u])
#define CapSense_TRACKPAD_RX5_TX4_BSLN0_OFFSET              (1310u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN0_PARAM_ID            (0x8100051Eu)

#define CapSense_TRACKPAD_RX5_TX4_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[39u].bsln[1u])
#define CapSense_TRACKPAD_RX5_TX4_BSLN1_OFFSET              (1312u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN1_PARAM_ID            (0x81000520u)

#define CapSense_TRACKPAD_RX5_TX4_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[39u].bsln[2u])
#define CapSense_TRACKPAD_RX5_TX4_BSLN2_OFFSET              (1314u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN2_PARAM_ID            (0x8D000522u)

#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[39u].bslnExt[0u])
#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT0_OFFSET          (1316u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT0_PARAM_ID        (0x48000524u)

#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[39u].bslnExt[1u])
#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT1_OFFSET          (1317u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT1_PARAM_ID        (0x4E000525u)

#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[39u].bslnExt[2u])
#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT2_OFFSET          (1318u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX4_BSLN_EXT2_PARAM_ID        (0x44000526u)

#define CapSense_TRACKPAD_RX5_TX4_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[39u].diff)
#define CapSense_TRACKPAD_RX5_TX4_DIFF_OFFSET               (1320u)
#define CapSense_TRACKPAD_RX5_TX4_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX4_DIFF_PARAM_ID             (0x83000528u)

#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[39u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT0_OFFSET  (1322u)
#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT0_PARAM_ID (0x4700052Au)

#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[39u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT1_OFFSET  (1323u)
#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT1_PARAM_ID (0x4100052Bu)

#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[39u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT2_OFFSET  (1324u)
#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX4_NEG_BSLN_RST_CNT2_PARAM_ID (0x4A00052Cu)

#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[39u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT0_OFFSET  (1326u)
#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT0_PARAM_ID (0x8E00052Eu)

#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[39u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT1_OFFSET  (1328u)
#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT1_PARAM_ID (0x84000530u)

#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[39u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT2_OFFSET  (1330u)
#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX4_POS_BLSN_RST_CNT2_PARAM_ID (0x88000532u)

#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[39u].idacComp[0u])
#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP0_OFFSET         (1332u)
#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP0_PARAM_ID       (0x4D000534u)

#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[39u].idacComp[1u])
#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP1_OFFSET         (1333u)
#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP1_PARAM_ID       (0x4B000535u)

#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[39u].idacComp[2u])
#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP2_OFFSET         (1334u)
#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX4_IDAC_COMP2_PARAM_ID       (0x41000536u)

#define CapSense_TRACKPAD_RX5_TX5_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[40u].raw[0u])
#define CapSense_TRACKPAD_RX5_TX5_RAW0_OFFSET               (1336u)
#define CapSense_TRACKPAD_RX5_TX5_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX5_RAW0_PARAM_ID             (0x86000538u)

#define CapSense_TRACKPAD_RX5_TX5_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[40u].raw[1u])
#define CapSense_TRACKPAD_RX5_TX5_RAW1_OFFSET               (1338u)
#define CapSense_TRACKPAD_RX5_TX5_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX5_RAW1_PARAM_ID             (0x8A00053Au)

#define CapSense_TRACKPAD_RX5_TX5_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[40u].raw[2u])
#define CapSense_TRACKPAD_RX5_TX5_RAW2_OFFSET               (1340u)
#define CapSense_TRACKPAD_RX5_TX5_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX5_RAW2_PARAM_ID             (0x8700053Cu)

#define CapSense_TRACKPAD_RX5_TX5_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[40u].bsln[0u])
#define CapSense_TRACKPAD_RX5_TX5_BSLN0_OFFSET              (1342u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN0_PARAM_ID            (0x8B00053Eu)

#define CapSense_TRACKPAD_RX5_TX5_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[40u].bsln[1u])
#define CapSense_TRACKPAD_RX5_TX5_BSLN1_OFFSET              (1344u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN1_PARAM_ID            (0x86000540u)

#define CapSense_TRACKPAD_RX5_TX5_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[40u].bsln[2u])
#define CapSense_TRACKPAD_RX5_TX5_BSLN2_OFFSET              (1346u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN2_PARAM_ID            (0x8A000542u)

#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[40u].bslnExt[0u])
#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT0_OFFSET          (1348u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT0_PARAM_ID        (0x4F000544u)

#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[40u].bslnExt[1u])
#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT1_OFFSET          (1349u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT1_PARAM_ID        (0x49000545u)

#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[40u].bslnExt[2u])
#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT2_OFFSET          (1350u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX5_BSLN_EXT2_PARAM_ID        (0x43000546u)

#define CapSense_TRACKPAD_RX5_TX5_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[40u].diff)
#define CapSense_TRACKPAD_RX5_TX5_DIFF_OFFSET               (1352u)
#define CapSense_TRACKPAD_RX5_TX5_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX5_DIFF_PARAM_ID             (0x84000548u)

#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[40u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT0_OFFSET  (1354u)
#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT0_PARAM_ID (0x4000054Au)

#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[40u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT1_OFFSET  (1355u)
#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT1_PARAM_ID (0x4600054Bu)

#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[40u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT2_OFFSET  (1356u)
#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX5_NEG_BSLN_RST_CNT2_PARAM_ID (0x4D00054Cu)

#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[40u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT0_OFFSET  (1358u)
#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT0_PARAM_ID (0x8900054Eu)

#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[40u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT1_OFFSET  (1360u)
#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT1_PARAM_ID (0x83000550u)

#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[40u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT2_OFFSET  (1362u)
#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX5_POS_BLSN_RST_CNT2_PARAM_ID (0x8F000552u)

#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[40u].idacComp[0u])
#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP0_OFFSET         (1364u)
#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP0_PARAM_ID       (0x4A000554u)

#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[40u].idacComp[1u])
#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP1_OFFSET         (1365u)
#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP1_PARAM_ID       (0x4C000555u)

#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[40u].idacComp[2u])
#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP2_OFFSET         (1366u)
#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX5_IDAC_COMP2_PARAM_ID       (0x46000556u)

#define CapSense_TRACKPAD_RX5_TX6_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[41u].raw[0u])
#define CapSense_TRACKPAD_RX5_TX6_RAW0_OFFSET               (1368u)
#define CapSense_TRACKPAD_RX5_TX6_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX6_RAW0_PARAM_ID             (0x81000558u)

#define CapSense_TRACKPAD_RX5_TX6_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[41u].raw[1u])
#define CapSense_TRACKPAD_RX5_TX6_RAW1_OFFSET               (1370u)
#define CapSense_TRACKPAD_RX5_TX6_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX6_RAW1_PARAM_ID             (0x8D00055Au)

#define CapSense_TRACKPAD_RX5_TX6_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[41u].raw[2u])
#define CapSense_TRACKPAD_RX5_TX6_RAW2_OFFSET               (1372u)
#define CapSense_TRACKPAD_RX5_TX6_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX6_RAW2_PARAM_ID             (0x8000055Cu)

#define CapSense_TRACKPAD_RX5_TX6_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[41u].bsln[0u])
#define CapSense_TRACKPAD_RX5_TX6_BSLN0_OFFSET              (1374u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN0_PARAM_ID            (0x8C00055Eu)

#define CapSense_TRACKPAD_RX5_TX6_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[41u].bsln[1u])
#define CapSense_TRACKPAD_RX5_TX6_BSLN1_OFFSET              (1376u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN1_PARAM_ID            (0x8C000560u)

#define CapSense_TRACKPAD_RX5_TX6_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[41u].bsln[2u])
#define CapSense_TRACKPAD_RX5_TX6_BSLN2_OFFSET              (1378u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN2_PARAM_ID            (0x80000562u)

#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[41u].bslnExt[0u])
#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT0_OFFSET          (1380u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT0_PARAM_ID        (0x45000564u)

#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[41u].bslnExt[1u])
#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT1_OFFSET          (1381u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT1_PARAM_ID        (0x43000565u)

#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[41u].bslnExt[2u])
#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT2_OFFSET          (1382u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX5_TX6_BSLN_EXT2_PARAM_ID        (0x49000566u)

#define CapSense_TRACKPAD_RX5_TX6_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[41u].diff)
#define CapSense_TRACKPAD_RX5_TX6_DIFF_OFFSET               (1384u)
#define CapSense_TRACKPAD_RX5_TX6_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX5_TX6_DIFF_PARAM_ID             (0x8E000568u)

#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[41u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT0_OFFSET  (1386u)
#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT0_PARAM_ID (0x4A00056Au)

#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[41u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT1_OFFSET  (1387u)
#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT1_PARAM_ID (0x4C00056Bu)

#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[41u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT2_OFFSET  (1388u)
#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX5_TX6_NEG_BSLN_RST_CNT2_PARAM_ID (0x4700056Cu)

#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[41u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT0_OFFSET  (1390u)
#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT0_PARAM_ID (0x8300056Eu)

#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[41u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT1_OFFSET  (1392u)
#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT1_PARAM_ID (0x89000570u)

#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[41u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT2_OFFSET  (1394u)
#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX5_TX6_POS_BLSN_RST_CNT2_PARAM_ID (0x85000572u)

#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[41u].idacComp[0u])
#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP0_OFFSET         (1396u)
#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP0_PARAM_ID       (0x40000574u)

#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[41u].idacComp[1u])
#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP1_OFFSET         (1397u)
#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP1_PARAM_ID       (0x46000575u)

#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[41u].idacComp[2u])
#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP2_OFFSET         (1398u)
#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX5_TX6_IDAC_COMP2_PARAM_ID       (0x4C000576u)

#define CapSense_TRACKPAD_RX6_TX0_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[42u].raw[0u])
#define CapSense_TRACKPAD_RX6_TX0_RAW0_OFFSET               (1400u)
#define CapSense_TRACKPAD_RX6_TX0_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX0_RAW0_PARAM_ID             (0x8B000578u)

#define CapSense_TRACKPAD_RX6_TX0_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[42u].raw[1u])
#define CapSense_TRACKPAD_RX6_TX0_RAW1_OFFSET               (1402u)
#define CapSense_TRACKPAD_RX6_TX0_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX0_RAW1_PARAM_ID             (0x8700057Au)

#define CapSense_TRACKPAD_RX6_TX0_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[42u].raw[2u])
#define CapSense_TRACKPAD_RX6_TX0_RAW2_OFFSET               (1404u)
#define CapSense_TRACKPAD_RX6_TX0_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX0_RAW2_PARAM_ID             (0x8A00057Cu)

#define CapSense_TRACKPAD_RX6_TX0_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[42u].bsln[0u])
#define CapSense_TRACKPAD_RX6_TX0_BSLN0_OFFSET              (1406u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN0_PARAM_ID            (0x8600057Eu)

#define CapSense_TRACKPAD_RX6_TX0_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[42u].bsln[1u])
#define CapSense_TRACKPAD_RX6_TX0_BSLN1_OFFSET              (1408u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN1_PARAM_ID            (0x88000580u)

#define CapSense_TRACKPAD_RX6_TX0_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[42u].bsln[2u])
#define CapSense_TRACKPAD_RX6_TX0_BSLN2_OFFSET              (1410u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN2_PARAM_ID            (0x84000582u)

#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[42u].bslnExt[0u])
#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT0_OFFSET          (1412u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT0_PARAM_ID        (0x41000584u)

#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[42u].bslnExt[1u])
#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT1_OFFSET          (1413u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT1_PARAM_ID        (0x47000585u)

#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[42u].bslnExt[2u])
#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT2_OFFSET          (1414u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX0_BSLN_EXT2_PARAM_ID        (0x4D000586u)

#define CapSense_TRACKPAD_RX6_TX0_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[42u].diff)
#define CapSense_TRACKPAD_RX6_TX0_DIFF_OFFSET               (1416u)
#define CapSense_TRACKPAD_RX6_TX0_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX0_DIFF_PARAM_ID             (0x8A000588u)

#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[42u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT0_OFFSET  (1418u)
#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT0_PARAM_ID (0x4E00058Au)

#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[42u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT1_OFFSET  (1419u)
#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT1_PARAM_ID (0x4800058Bu)

#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[42u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT2_OFFSET  (1420u)
#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX0_NEG_BSLN_RST_CNT2_PARAM_ID (0x4300058Cu)

#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[42u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT0_OFFSET  (1422u)
#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT0_PARAM_ID (0x8700058Eu)

#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[42u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT1_OFFSET  (1424u)
#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT1_PARAM_ID (0x8D000590u)

#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[42u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT2_OFFSET  (1426u)
#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX0_POS_BLSN_RST_CNT2_PARAM_ID (0x81000592u)

#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[42u].idacComp[0u])
#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP0_OFFSET         (1428u)
#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP0_PARAM_ID       (0x44000594u)

#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[42u].idacComp[1u])
#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP1_OFFSET         (1429u)
#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP1_PARAM_ID       (0x42000595u)

#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[42u].idacComp[2u])
#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP2_OFFSET         (1430u)
#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX0_IDAC_COMP2_PARAM_ID       (0x48000596u)

#define CapSense_TRACKPAD_RX6_TX1_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[43u].raw[0u])
#define CapSense_TRACKPAD_RX6_TX1_RAW0_OFFSET               (1432u)
#define CapSense_TRACKPAD_RX6_TX1_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX1_RAW0_PARAM_ID             (0x8F000598u)

#define CapSense_TRACKPAD_RX6_TX1_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[43u].raw[1u])
#define CapSense_TRACKPAD_RX6_TX1_RAW1_OFFSET               (1434u)
#define CapSense_TRACKPAD_RX6_TX1_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX1_RAW1_PARAM_ID             (0x8300059Au)

#define CapSense_TRACKPAD_RX6_TX1_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[43u].raw[2u])
#define CapSense_TRACKPAD_RX6_TX1_RAW2_OFFSET               (1436u)
#define CapSense_TRACKPAD_RX6_TX1_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX1_RAW2_PARAM_ID             (0x8E00059Cu)

#define CapSense_TRACKPAD_RX6_TX1_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[43u].bsln[0u])
#define CapSense_TRACKPAD_RX6_TX1_BSLN0_OFFSET              (1438u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN0_PARAM_ID            (0x8200059Eu)

#define CapSense_TRACKPAD_RX6_TX1_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[43u].bsln[1u])
#define CapSense_TRACKPAD_RX6_TX1_BSLN1_OFFSET              (1440u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN1_PARAM_ID            (0x820005A0u)

#define CapSense_TRACKPAD_RX6_TX1_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[43u].bsln[2u])
#define CapSense_TRACKPAD_RX6_TX1_BSLN2_OFFSET              (1442u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN2_PARAM_ID            (0x8E0005A2u)

#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[43u].bslnExt[0u])
#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT0_OFFSET          (1444u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT0_PARAM_ID        (0x4B0005A4u)

#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[43u].bslnExt[1u])
#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT1_OFFSET          (1445u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT1_PARAM_ID        (0x4D0005A5u)

#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[43u].bslnExt[2u])
#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT2_OFFSET          (1446u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX1_BSLN_EXT2_PARAM_ID        (0x470005A6u)

#define CapSense_TRACKPAD_RX6_TX1_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[43u].diff)
#define CapSense_TRACKPAD_RX6_TX1_DIFF_OFFSET               (1448u)
#define CapSense_TRACKPAD_RX6_TX1_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX1_DIFF_PARAM_ID             (0x800005A8u)

#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[43u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT0_OFFSET  (1450u)
#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT0_PARAM_ID (0x440005AAu)

#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[43u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT1_OFFSET  (1451u)
#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT1_PARAM_ID (0x420005ABu)

#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[43u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT2_OFFSET  (1452u)
#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX1_NEG_BSLN_RST_CNT2_PARAM_ID (0x490005ACu)

#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[43u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT0_OFFSET  (1454u)
#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT0_PARAM_ID (0x8D0005AEu)

#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[43u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT1_OFFSET  (1456u)
#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT1_PARAM_ID (0x870005B0u)

#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[43u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT2_OFFSET  (1458u)
#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX1_POS_BLSN_RST_CNT2_PARAM_ID (0x8B0005B2u)

#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[43u].idacComp[0u])
#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP0_OFFSET         (1460u)
#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP0_PARAM_ID       (0x4E0005B4u)

#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[43u].idacComp[1u])
#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP1_OFFSET         (1461u)
#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP1_PARAM_ID       (0x480005B5u)

#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[43u].idacComp[2u])
#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP2_OFFSET         (1462u)
#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX1_IDAC_COMP2_PARAM_ID       (0x420005B6u)

#define CapSense_TRACKPAD_RX6_TX2_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[44u].raw[0u])
#define CapSense_TRACKPAD_RX6_TX2_RAW0_OFFSET               (1464u)
#define CapSense_TRACKPAD_RX6_TX2_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX2_RAW0_PARAM_ID             (0x850005B8u)

#define CapSense_TRACKPAD_RX6_TX2_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[44u].raw[1u])
#define CapSense_TRACKPAD_RX6_TX2_RAW1_OFFSET               (1466u)
#define CapSense_TRACKPAD_RX6_TX2_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX2_RAW1_PARAM_ID             (0x890005BAu)

#define CapSense_TRACKPAD_RX6_TX2_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[44u].raw[2u])
#define CapSense_TRACKPAD_RX6_TX2_RAW2_OFFSET               (1468u)
#define CapSense_TRACKPAD_RX6_TX2_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX2_RAW2_PARAM_ID             (0x840005BCu)

#define CapSense_TRACKPAD_RX6_TX2_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[44u].bsln[0u])
#define CapSense_TRACKPAD_RX6_TX2_BSLN0_OFFSET              (1470u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN0_PARAM_ID            (0x880005BEu)

#define CapSense_TRACKPAD_RX6_TX2_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[44u].bsln[1u])
#define CapSense_TRACKPAD_RX6_TX2_BSLN1_OFFSET              (1472u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN1_PARAM_ID            (0x850005C0u)

#define CapSense_TRACKPAD_RX6_TX2_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[44u].bsln[2u])
#define CapSense_TRACKPAD_RX6_TX2_BSLN2_OFFSET              (1474u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN2_PARAM_ID            (0x890005C2u)

#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[44u].bslnExt[0u])
#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT0_OFFSET          (1476u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT0_PARAM_ID        (0x4C0005C4u)

#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[44u].bslnExt[1u])
#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT1_OFFSET          (1477u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT1_PARAM_ID        (0x4A0005C5u)

#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[44u].bslnExt[2u])
#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT2_OFFSET          (1478u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX2_BSLN_EXT2_PARAM_ID        (0x400005C6u)

#define CapSense_TRACKPAD_RX6_TX2_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[44u].diff)
#define CapSense_TRACKPAD_RX6_TX2_DIFF_OFFSET               (1480u)
#define CapSense_TRACKPAD_RX6_TX2_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX2_DIFF_PARAM_ID             (0x870005C8u)

#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[44u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT0_OFFSET  (1482u)
#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT0_PARAM_ID (0x430005CAu)

#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[44u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT1_OFFSET  (1483u)
#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT1_PARAM_ID (0x450005CBu)

#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[44u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT2_OFFSET  (1484u)
#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX2_NEG_BSLN_RST_CNT2_PARAM_ID (0x4E0005CCu)

#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[44u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT0_OFFSET  (1486u)
#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT0_PARAM_ID (0x8A0005CEu)

#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[44u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT1_OFFSET  (1488u)
#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT1_PARAM_ID (0x800005D0u)

#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[44u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT2_OFFSET  (1490u)
#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX2_POS_BLSN_RST_CNT2_PARAM_ID (0x8C0005D2u)

#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[44u].idacComp[0u])
#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP0_OFFSET         (1492u)
#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP0_PARAM_ID       (0x490005D4u)

#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[44u].idacComp[1u])
#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP1_OFFSET         (1493u)
#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP1_PARAM_ID       (0x4F0005D5u)

#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[44u].idacComp[2u])
#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP2_OFFSET         (1494u)
#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX2_IDAC_COMP2_PARAM_ID       (0x450005D6u)

#define CapSense_TRACKPAD_RX6_TX3_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[45u].raw[0u])
#define CapSense_TRACKPAD_RX6_TX3_RAW0_OFFSET               (1496u)
#define CapSense_TRACKPAD_RX6_TX3_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX3_RAW0_PARAM_ID             (0x820005D8u)

#define CapSense_TRACKPAD_RX6_TX3_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[45u].raw[1u])
#define CapSense_TRACKPAD_RX6_TX3_RAW1_OFFSET               (1498u)
#define CapSense_TRACKPAD_RX6_TX3_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX3_RAW1_PARAM_ID             (0x8E0005DAu)

#define CapSense_TRACKPAD_RX6_TX3_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[45u].raw[2u])
#define CapSense_TRACKPAD_RX6_TX3_RAW2_OFFSET               (1500u)
#define CapSense_TRACKPAD_RX6_TX3_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX3_RAW2_PARAM_ID             (0x830005DCu)

#define CapSense_TRACKPAD_RX6_TX3_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[45u].bsln[0u])
#define CapSense_TRACKPAD_RX6_TX3_BSLN0_OFFSET              (1502u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN0_PARAM_ID            (0x8F0005DEu)

#define CapSense_TRACKPAD_RX6_TX3_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[45u].bsln[1u])
#define CapSense_TRACKPAD_RX6_TX3_BSLN1_OFFSET              (1504u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN1_PARAM_ID            (0x8F0005E0u)

#define CapSense_TRACKPAD_RX6_TX3_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[45u].bsln[2u])
#define CapSense_TRACKPAD_RX6_TX3_BSLN2_OFFSET              (1506u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN2_PARAM_ID            (0x830005E2u)

#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[45u].bslnExt[0u])
#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT0_OFFSET          (1508u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT0_PARAM_ID        (0x460005E4u)

#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[45u].bslnExt[1u])
#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT1_OFFSET          (1509u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT1_PARAM_ID        (0x400005E5u)

#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[45u].bslnExt[2u])
#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT2_OFFSET          (1510u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX3_BSLN_EXT2_PARAM_ID        (0x4A0005E6u)

#define CapSense_TRACKPAD_RX6_TX3_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[45u].diff)
#define CapSense_TRACKPAD_RX6_TX3_DIFF_OFFSET               (1512u)
#define CapSense_TRACKPAD_RX6_TX3_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX3_DIFF_PARAM_ID             (0x8D0005E8u)

#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[45u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT0_OFFSET  (1514u)
#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT0_PARAM_ID (0x490005EAu)

#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[45u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT1_OFFSET  (1515u)
#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT1_PARAM_ID (0x4F0005EBu)

#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[45u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT2_OFFSET  (1516u)
#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX3_NEG_BSLN_RST_CNT2_PARAM_ID (0x440005ECu)

#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[45u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT0_OFFSET  (1518u)
#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT0_PARAM_ID (0x800005EEu)

#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[45u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT1_OFFSET  (1520u)
#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT1_PARAM_ID (0x8A0005F0u)

#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[45u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT2_OFFSET  (1522u)
#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX3_POS_BLSN_RST_CNT2_PARAM_ID (0x860005F2u)

#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[45u].idacComp[0u])
#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP0_OFFSET         (1524u)
#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP0_PARAM_ID       (0x430005F4u)

#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[45u].idacComp[1u])
#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP1_OFFSET         (1525u)
#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP1_PARAM_ID       (0x450005F5u)

#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[45u].idacComp[2u])
#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP2_OFFSET         (1526u)
#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX3_IDAC_COMP2_PARAM_ID       (0x4F0005F6u)

#define CapSense_TRACKPAD_RX6_TX4_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[46u].raw[0u])
#define CapSense_TRACKPAD_RX6_TX4_RAW0_OFFSET               (1528u)
#define CapSense_TRACKPAD_RX6_TX4_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX4_RAW0_PARAM_ID             (0x880005F8u)

#define CapSense_TRACKPAD_RX6_TX4_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[46u].raw[1u])
#define CapSense_TRACKPAD_RX6_TX4_RAW1_OFFSET               (1530u)
#define CapSense_TRACKPAD_RX6_TX4_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX4_RAW1_PARAM_ID             (0x840005FAu)

#define CapSense_TRACKPAD_RX6_TX4_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[46u].raw[2u])
#define CapSense_TRACKPAD_RX6_TX4_RAW2_OFFSET               (1532u)
#define CapSense_TRACKPAD_RX6_TX4_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX4_RAW2_PARAM_ID             (0x890005FCu)

#define CapSense_TRACKPAD_RX6_TX4_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[46u].bsln[0u])
#define CapSense_TRACKPAD_RX6_TX4_BSLN0_OFFSET              (1534u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN0_PARAM_ID            (0x850005FEu)

#define CapSense_TRACKPAD_RX6_TX4_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[46u].bsln[1u])
#define CapSense_TRACKPAD_RX6_TX4_BSLN1_OFFSET              (1536u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN1_PARAM_ID            (0x8F000600u)

#define CapSense_TRACKPAD_RX6_TX4_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[46u].bsln[2u])
#define CapSense_TRACKPAD_RX6_TX4_BSLN2_OFFSET              (1538u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN2_PARAM_ID            (0x83000602u)

#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[46u].bslnExt[0u])
#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT0_OFFSET          (1540u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT0_PARAM_ID        (0x46000604u)

#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[46u].bslnExt[1u])
#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT1_OFFSET          (1541u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT1_PARAM_ID        (0x40000605u)

#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[46u].bslnExt[2u])
#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT2_OFFSET          (1542u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX4_BSLN_EXT2_PARAM_ID        (0x4A000606u)

#define CapSense_TRACKPAD_RX6_TX4_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[46u].diff)
#define CapSense_TRACKPAD_RX6_TX4_DIFF_OFFSET               (1544u)
#define CapSense_TRACKPAD_RX6_TX4_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX4_DIFF_PARAM_ID             (0x8D000608u)

#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[46u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT0_OFFSET  (1546u)
#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT0_PARAM_ID (0x4900060Au)

#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[46u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT1_OFFSET  (1547u)
#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT1_PARAM_ID (0x4F00060Bu)

#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[46u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT2_OFFSET  (1548u)
#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX4_NEG_BSLN_RST_CNT2_PARAM_ID (0x4400060Cu)

#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[46u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT0_OFFSET  (1550u)
#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT0_PARAM_ID (0x8000060Eu)

#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[46u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT1_OFFSET  (1552u)
#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT1_PARAM_ID (0x8A000610u)

#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[46u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT2_OFFSET  (1554u)
#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX4_POS_BLSN_RST_CNT2_PARAM_ID (0x86000612u)

#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[46u].idacComp[0u])
#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP0_OFFSET         (1556u)
#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP0_PARAM_ID       (0x43000614u)

#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[46u].idacComp[1u])
#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP1_OFFSET         (1557u)
#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP1_PARAM_ID       (0x45000615u)

#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[46u].idacComp[2u])
#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP2_OFFSET         (1558u)
#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX4_IDAC_COMP2_PARAM_ID       (0x4F000616u)

#define CapSense_TRACKPAD_RX6_TX5_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[47u].raw[0u])
#define CapSense_TRACKPAD_RX6_TX5_RAW0_OFFSET               (1560u)
#define CapSense_TRACKPAD_RX6_TX5_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX5_RAW0_PARAM_ID             (0x88000618u)

#define CapSense_TRACKPAD_RX6_TX5_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[47u].raw[1u])
#define CapSense_TRACKPAD_RX6_TX5_RAW1_OFFSET               (1562u)
#define CapSense_TRACKPAD_RX6_TX5_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX5_RAW1_PARAM_ID             (0x8400061Au)

#define CapSense_TRACKPAD_RX6_TX5_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[47u].raw[2u])
#define CapSense_TRACKPAD_RX6_TX5_RAW2_OFFSET               (1564u)
#define CapSense_TRACKPAD_RX6_TX5_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX5_RAW2_PARAM_ID             (0x8900061Cu)

#define CapSense_TRACKPAD_RX6_TX5_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[47u].bsln[0u])
#define CapSense_TRACKPAD_RX6_TX5_BSLN0_OFFSET              (1566u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN0_PARAM_ID            (0x8500061Eu)

#define CapSense_TRACKPAD_RX6_TX5_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[47u].bsln[1u])
#define CapSense_TRACKPAD_RX6_TX5_BSLN1_OFFSET              (1568u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN1_PARAM_ID            (0x85000620u)

#define CapSense_TRACKPAD_RX6_TX5_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[47u].bsln[2u])
#define CapSense_TRACKPAD_RX6_TX5_BSLN2_OFFSET              (1570u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN2_PARAM_ID            (0x89000622u)

#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[47u].bslnExt[0u])
#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT0_OFFSET          (1572u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT0_PARAM_ID        (0x4C000624u)

#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[47u].bslnExt[1u])
#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT1_OFFSET          (1573u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT1_PARAM_ID        (0x4A000625u)

#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[47u].bslnExt[2u])
#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT2_OFFSET          (1574u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX5_BSLN_EXT2_PARAM_ID        (0x40000626u)

#define CapSense_TRACKPAD_RX6_TX5_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[47u].diff)
#define CapSense_TRACKPAD_RX6_TX5_DIFF_OFFSET               (1576u)
#define CapSense_TRACKPAD_RX6_TX5_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX5_DIFF_PARAM_ID             (0x87000628u)

#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[47u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT0_OFFSET  (1578u)
#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT0_PARAM_ID (0x4300062Au)

#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[47u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT1_OFFSET  (1579u)
#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT1_PARAM_ID (0x4500062Bu)

#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[47u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT2_OFFSET  (1580u)
#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX5_NEG_BSLN_RST_CNT2_PARAM_ID (0x4E00062Cu)

#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[47u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT0_OFFSET  (1582u)
#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT0_PARAM_ID (0x8A00062Eu)

#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[47u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT1_OFFSET  (1584u)
#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT1_PARAM_ID (0x80000630u)

#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[47u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT2_OFFSET  (1586u)
#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX5_POS_BLSN_RST_CNT2_PARAM_ID (0x8C000632u)

#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[47u].idacComp[0u])
#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP0_OFFSET         (1588u)
#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP0_PARAM_ID       (0x49000634u)

#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[47u].idacComp[1u])
#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP1_OFFSET         (1589u)
#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP1_PARAM_ID       (0x4F000635u)

#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[47u].idacComp[2u])
#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP2_OFFSET         (1590u)
#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX5_IDAC_COMP2_PARAM_ID       (0x45000636u)

#define CapSense_TRACKPAD_RX6_TX6_RAW0_VALUE                (CapSense_dsRam.snsList.trackpad[48u].raw[0u])
#define CapSense_TRACKPAD_RX6_TX6_RAW0_OFFSET               (1592u)
#define CapSense_TRACKPAD_RX6_TX6_RAW0_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX6_RAW0_PARAM_ID             (0x82000638u)

#define CapSense_TRACKPAD_RX6_TX6_RAW1_VALUE                (CapSense_dsRam.snsList.trackpad[48u].raw[1u])
#define CapSense_TRACKPAD_RX6_TX6_RAW1_OFFSET               (1594u)
#define CapSense_TRACKPAD_RX6_TX6_RAW1_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX6_RAW1_PARAM_ID             (0x8E00063Au)

#define CapSense_TRACKPAD_RX6_TX6_RAW2_VALUE                (CapSense_dsRam.snsList.trackpad[48u].raw[2u])
#define CapSense_TRACKPAD_RX6_TX6_RAW2_OFFSET               (1596u)
#define CapSense_TRACKPAD_RX6_TX6_RAW2_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX6_RAW2_PARAM_ID             (0x8300063Cu)

#define CapSense_TRACKPAD_RX6_TX6_BSLN0_VALUE               (CapSense_dsRam.snsList.trackpad[48u].bsln[0u])
#define CapSense_TRACKPAD_RX6_TX6_BSLN0_OFFSET              (1598u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN0_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN0_PARAM_ID            (0x8F00063Eu)

#define CapSense_TRACKPAD_RX6_TX6_BSLN1_VALUE               (CapSense_dsRam.snsList.trackpad[48u].bsln[1u])
#define CapSense_TRACKPAD_RX6_TX6_BSLN1_OFFSET              (1600u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN1_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN1_PARAM_ID            (0x82000640u)

#define CapSense_TRACKPAD_RX6_TX6_BSLN2_VALUE               (CapSense_dsRam.snsList.trackpad[48u].bsln[2u])
#define CapSense_TRACKPAD_RX6_TX6_BSLN2_OFFSET              (1602u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN2_SIZE                (2u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN2_PARAM_ID            (0x8E000642u)

#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT0_VALUE           (CapSense_dsRam.snsList.trackpad[48u].bslnExt[0u])
#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT0_OFFSET          (1604u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT0_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT0_PARAM_ID        (0x4B000644u)

#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT1_VALUE           (CapSense_dsRam.snsList.trackpad[48u].bslnExt[1u])
#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT1_OFFSET          (1605u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT1_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT1_PARAM_ID        (0x4D000645u)

#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT2_VALUE           (CapSense_dsRam.snsList.trackpad[48u].bslnExt[2u])
#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT2_OFFSET          (1606u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT2_SIZE            (1u)
#define CapSense_TRACKPAD_RX6_TX6_BSLN_EXT2_PARAM_ID        (0x47000646u)

#define CapSense_TRACKPAD_RX6_TX6_DIFF_VALUE                (CapSense_dsRam.snsList.trackpad[48u].diff)
#define CapSense_TRACKPAD_RX6_TX6_DIFF_OFFSET               (1608u)
#define CapSense_TRACKPAD_RX6_TX6_DIFF_SIZE                 (2u)
#define CapSense_TRACKPAD_RX6_TX6_DIFF_PARAM_ID             (0x80000648u)

#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[48u].negBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT0_OFFSET  (1610u)
#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT0_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT0_PARAM_ID (0x4400064Au)

#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[48u].negBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT1_OFFSET  (1611u)
#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT1_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT1_PARAM_ID (0x4200064Bu)

#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[48u].negBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT2_OFFSET  (1612u)
#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT2_SIZE    (1u)
#define CapSense_TRACKPAD_RX6_TX6_NEG_BSLN_RST_CNT2_PARAM_ID (0x4900064Cu)

#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT0_VALUE   (CapSense_dsRam.snsList.trackpad[48u].posBslnRstCnt[0u])
#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT0_OFFSET  (1614u)
#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT0_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT0_PARAM_ID (0x8D00064Eu)

#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT1_VALUE   (CapSense_dsRam.snsList.trackpad[48u].posBslnRstCnt[1u])
#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT1_OFFSET  (1616u)
#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT1_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT1_PARAM_ID (0x87000650u)

#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT2_VALUE   (CapSense_dsRam.snsList.trackpad[48u].posBslnRstCnt[2u])
#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT2_OFFSET  (1618u)
#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT2_SIZE    (2u)
#define CapSense_TRACKPAD_RX6_TX6_POS_BLSN_RST_CNT2_PARAM_ID (0x8B000652u)

#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP0_VALUE          (CapSense_dsRam.snsList.trackpad[48u].idacComp[0u])
#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP0_OFFSET         (1620u)
#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP0_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP0_PARAM_ID       (0x4E000654u)

#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP1_VALUE          (CapSense_dsRam.snsList.trackpad[48u].idacComp[1u])
#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP1_OFFSET         (1621u)
#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP1_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP1_PARAM_ID       (0x48000655u)

#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP2_VALUE          (CapSense_dsRam.snsList.trackpad[48u].idacComp[2u])
#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP2_OFFSET         (1622u)
#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP2_SIZE           (1u)
#define CapSense_TRACKPAD_RX6_TX6_IDAC_COMP2_PARAM_ID       (0x42000656u)

#define CapSense_SNR_TEST_WIDGET_ID_VALUE                   (CapSense_dsRam.snrTestWidgetId)
#define CapSense_SNR_TEST_WIDGET_ID_OFFSET                  (1624u)
#define CapSense_SNR_TEST_WIDGET_ID_SIZE                    (1u)
#define CapSense_SNR_TEST_WIDGET_ID_PARAM_ID                (0x66000658u)

#define CapSense_SNR_TEST_SENSOR_ID_VALUE                   (CapSense_dsRam.snrTestSensorId)
#define CapSense_SNR_TEST_SENSOR_ID_OFFSET                  (1625u)
#define CapSense_SNR_TEST_SENSOR_ID_SIZE                    (1u)
#define CapSense_SNR_TEST_SENSOR_ID_PARAM_ID                (0x60000659u)

#define CapSense_SNR_TEST_SCAN_COUNTER_VALUE                (CapSense_dsRam.snrTestScanCounter)
#define CapSense_SNR_TEST_SCAN_COUNTER_OFFSET               (1626u)
#define CapSense_SNR_TEST_SCAN_COUNTER_SIZE                 (2u)
#define CapSense_SNR_TEST_SCAN_COUNTER_PARAM_ID             (0x8900065Au)

#define CapSense_SNR_TEST_RAW_COUNT0_VALUE                  (CapSense_dsRam.snrTestRawCount[0u])
#define CapSense_SNR_TEST_RAW_COUNT0_OFFSET                 (1628u)
#define CapSense_SNR_TEST_RAW_COUNT0_SIZE                   (2u)
#define CapSense_SNR_TEST_RAW_COUNT0_PARAM_ID               (0x8400065Cu)

#define CapSense_SNR_TEST_RAW_COUNT1_VALUE                  (CapSense_dsRam.snrTestRawCount[1u])
#define CapSense_SNR_TEST_RAW_COUNT1_OFFSET                 (1630u)
#define CapSense_SNR_TEST_RAW_COUNT1_SIZE                   (2u)
#define CapSense_SNR_TEST_RAW_COUNT1_PARAM_ID               (0x8800065Eu)

#define CapSense_SNR_TEST_RAW_COUNT2_VALUE                  (CapSense_dsRam.snrTestRawCount[2u])
#define CapSense_SNR_TEST_RAW_COUNT2_OFFSET                 (1632u)
#define CapSense_SNR_TEST_RAW_COUNT2_SIZE                   (2u)
#define CapSense_SNR_TEST_RAW_COUNT2_PARAM_ID               (0x88000660u)


/*****************************************************************************/
/* Flash Data structure register definitions                                 */
/*****************************************************************************/
#define CapSense_TRACKPAD_PTR2SNS_FLASH_VALUE               (CapSense_dsFlash.wdgtArray[0].ptr2SnsFlash)
#define CapSense_TRACKPAD_PTR2SNS_FLASH_OFFSET              (0u)
#define CapSense_TRACKPAD_PTR2SNS_FLASH_SIZE                (4u)
#define CapSense_TRACKPAD_PTR2SNS_FLASH_PARAM_ID            (0xD1000000u)

#define CapSense_TRACKPAD_PTR2WD_RAM_VALUE                  (CapSense_dsFlash.wdgtArray[0].ptr2WdgtRam)
#define CapSense_TRACKPAD_PTR2WD_RAM_OFFSET                 (4u)
#define CapSense_TRACKPAD_PTR2WD_RAM_SIZE                   (4u)
#define CapSense_TRACKPAD_PTR2WD_RAM_PARAM_ID               (0xD0000004u)

#define CapSense_TRACKPAD_PTR2SNS_RAM_VALUE                 (CapSense_dsFlash.wdgtArray[0].ptr2SnsRam)
#define CapSense_TRACKPAD_PTR2SNS_RAM_OFFSET                (8u)
#define CapSense_TRACKPAD_PTR2SNS_RAM_SIZE                  (4u)
#define CapSense_TRACKPAD_PTR2SNS_RAM_PARAM_ID              (0xD3000008u)

#define CapSense_TRACKPAD_PTR2FLTR_HISTORY_VALUE            (CapSense_dsFlash.wdgtArray[0].ptr2FltrHistory)
#define CapSense_TRACKPAD_PTR2FLTR_HISTORY_OFFSET           (12u)
#define CapSense_TRACKPAD_PTR2FLTR_HISTORY_SIZE             (4u)
#define CapSense_TRACKPAD_PTR2FLTR_HISTORY_PARAM_ID         (0xD200000Cu)

#define CapSense_TRACKPAD_PTR2DEBOUNCE_VALUE                (CapSense_dsFlash.wdgtArray[0].ptr2DebounceArr)
#define CapSense_TRACKPAD_PTR2DEBOUNCE_OFFSET               (16u)
#define CapSense_TRACKPAD_PTR2DEBOUNCE_SIZE                 (4u)
#define CapSense_TRACKPAD_PTR2DEBOUNCE_PARAM_ID             (0xD4000010u)

#define CapSense_TRACKPAD_STATIC_CONFIG_VALUE               (CapSense_dsFlash.wdgtArray[0].staticConfig)
#define CapSense_TRACKPAD_STATIC_CONFIG_OFFSET              (20u)
#define CapSense_TRACKPAD_STATIC_CONFIG_SIZE                (2u)
#define CapSense_TRACKPAD_STATIC_CONFIG_PARAM_ID            (0x9A000014u)

#define CapSense_TRACKPAD_TOTAL_NUM_SNS_VALUE               (CapSense_dsFlash.wdgtArray[0].totalNumSns)
#define CapSense_TRACKPAD_TOTAL_NUM_SNS_OFFSET              (22u)
#define CapSense_TRACKPAD_TOTAL_NUM_SNS_SIZE                (2u)
#define CapSense_TRACKPAD_TOTAL_NUM_SNS_PARAM_ID            (0x96000016u)

#define CapSense_TRACKPAD_TYPE_VALUE                        (CapSense_dsFlash.wdgtArray[0].wdgtType)
#define CapSense_TRACKPAD_TYPE_OFFSET                       (24u)
#define CapSense_TRACKPAD_TYPE_SIZE                         (1u)
#define CapSense_TRACKPAD_TYPE_PARAM_ID                     (0x51000018u)

#define CapSense_TRACKPAD_NUM_COLS_VALUE                    (CapSense_dsFlash.wdgtArray[0].numCols)
#define CapSense_TRACKPAD_NUM_COLS_OFFSET                   (25u)
#define CapSense_TRACKPAD_NUM_COLS_SIZE                     (1u)
#define CapSense_TRACKPAD_NUM_COLS_PARAM_ID                 (0x57000019u)

#define CapSense_TRACKPAD_NUM_ROWS_VALUE                    (CapSense_dsFlash.wdgtArray[0].numRows)
#define CapSense_TRACKPAD_NUM_ROWS_OFFSET                   (26u)
#define CapSense_TRACKPAD_NUM_ROWS_SIZE                     (1u)
#define CapSense_TRACKPAD_NUM_ROWS_PARAM_ID                 (0x5D00001Au)

#define CapSense_TRACKPAD_X_RESOLUTION_VALUE                (CapSense_dsFlash.wdgtArray[0].xResolution)
#define CapSense_TRACKPAD_X_RESOLUTION_OFFSET               (28u)
#define CapSense_TRACKPAD_X_RESOLUTION_SIZE                 (2u)
#define CapSense_TRACKPAD_X_RESOLUTION_PARAM_ID             (0x9800001Cu)

#define CapSense_TRACKPAD_Y_RESOLUTION_VALUE                (CapSense_dsFlash.wdgtArray[0].yResolution)
#define CapSense_TRACKPAD_Y_RESOLUTION_OFFSET               (30u)
#define CapSense_TRACKPAD_Y_RESOLUTION_SIZE                 (2u)
#define CapSense_TRACKPAD_Y_RESOLUTION_PARAM_ID             (0x9400001Eu)

#define CapSense_TRACKPAD_X_CENT_MULT_VALUE                 (CapSense_dsFlash.wdgtArray[0].xCentroidMultiplier)
#define CapSense_TRACKPAD_X_CENT_MULT_OFFSET                (32u)
#define CapSense_TRACKPAD_X_CENT_MULT_SIZE                  (4u)
#define CapSense_TRACKPAD_X_CENT_MULT_PARAM_ID              (0xDB000020u)

#define CapSense_TRACKPAD_Y_CENT_MULT_VALUE                 (CapSense_dsFlash.wdgtArray[0].yCentroidMultiplier)
#define CapSense_TRACKPAD_Y_CENT_MULT_OFFSET                (36u)
#define CapSense_TRACKPAD_Y_CENT_MULT_SIZE                  (4u)
#define CapSense_TRACKPAD_Y_CENT_MULT_PARAM_ID              (0xDA000024u)

#define CapSense_TRACKPAD_PTR2CSX_TOUCHPAD_VALUE            (CapSense_dsFlash.wdgtArray[0].ptr2CsxTouchpad)
#define CapSense_TRACKPAD_PTR2CSX_TOUCHPAD_OFFSET           (40u)
#define CapSense_TRACKPAD_PTR2CSX_TOUCHPAD_SIZE             (4u)
#define CapSense_TRACKPAD_PTR2CSX_TOUCHPAD_PARAM_ID         (0xD9000028u)

#define CapSense_TRACKPAD_PTR2POS_HISTORY_VALUE             (CapSense_dsFlash.wdgtArray[0].ptr2PosHistory)
#define CapSense_TRACKPAD_PTR2POS_HISTORY_OFFSET            (44u)
#define CapSense_TRACKPAD_PTR2POS_HISTORY_SIZE              (4u)
#define CapSense_TRACKPAD_PTR2POS_HISTORY_PARAM_ID          (0xD800002Cu)


#endif /* End CY_CAPSENSE_CapSense_REGISTER_MAP_H */

/* [] END OF FILE */
