/*******************************************************************************
* File Name: SHIELD_GND.c  
* Version 2.20
*
* Description:
*  This file contains APIs to set up the Pins component for low power modes.
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "SHIELD_GND.h"

static SHIELD_GND_BACKUP_STRUCT  SHIELD_GND_backup = {0u, 0u, 0u};


/*******************************************************************************
* Function Name: SHIELD_GND_Sleep
****************************************************************************//**
*
* \brief Stores the pin configuration and prepares the pin for entering chip 
*  deep-sleep/hibernate modes. This function must be called for SIO and USBIO
*  pins. It is not essential if using GPIO or GPIO_OVT pins.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None 
*  
* \sideeffect
*  For SIO pins, this function configures the pin input threshold to CMOS and
*  drive level to Vddio. This is needed for SIO pins when in device 
*  deep-sleep/hibernate modes.
*
* \funcusage
*  \snippet SHIELD_GND_SUT.c usage_SHIELD_GND_Sleep_Wakeup
*******************************************************************************/
void SHIELD_GND_Sleep(void)
{
    #if defined(SHIELD_GND__PC)
        SHIELD_GND_backup.pcState = SHIELD_GND_PC;
    #else
        #if (CY_PSOC4_4200L)
            /* Save the regulator state and put the PHY into suspend mode */
            SHIELD_GND_backup.usbState = SHIELD_GND_CR1_REG;
            SHIELD_GND_USB_POWER_REG |= SHIELD_GND_USBIO_ENTER_SLEEP;
            SHIELD_GND_CR1_REG &= SHIELD_GND_USBIO_CR1_OFF;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(SHIELD_GND__SIO)
        SHIELD_GND_backup.sioState = SHIELD_GND_SIO_REG;
        /* SIO requires unregulated output buffer and single ended input buffer */
        SHIELD_GND_SIO_REG &= (uint32)(~SHIELD_GND_SIO_LPM_MASK);
    #endif  
}


/*******************************************************************************
* Function Name: SHIELD_GND_Wakeup
****************************************************************************//**
*
* \brief Restores the pin configuration that was saved during Pin_Sleep().
*
* For USBIO pins, the wakeup is only triggered for falling edge interrupts.
*
* <b>Note</b> This function is available in PSoC 4 only.
*
* \return 
*  None
*  
* \funcusage
*  Refer to SHIELD_GND_Sleep() for an example usage.
*******************************************************************************/
void SHIELD_GND_Wakeup(void)
{
    #if defined(SHIELD_GND__PC)
        SHIELD_GND_PC = SHIELD_GND_backup.pcState;
    #else
        #if (CY_PSOC4_4200L)
            /* Restore the regulator state and come out of suspend mode */
            SHIELD_GND_USB_POWER_REG &= SHIELD_GND_USBIO_EXIT_SLEEP_PH1;
            SHIELD_GND_CR1_REG = SHIELD_GND_backup.usbState;
            SHIELD_GND_USB_POWER_REG &= SHIELD_GND_USBIO_EXIT_SLEEP_PH2;
        #endif
    #endif
    #if defined(CYIPBLOCK_m0s8ioss_VERSION) && defined(SHIELD_GND__SIO)
        SHIELD_GND_SIO_REG = SHIELD_GND_backup.sioState;
    #endif
}


/* [] END OF FILE */
