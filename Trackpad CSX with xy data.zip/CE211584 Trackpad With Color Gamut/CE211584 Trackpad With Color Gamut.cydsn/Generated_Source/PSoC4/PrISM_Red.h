/*******************************************************************************
* File Name: PrISM_Red.h
* Version 2.10
*
* Description:
*  This file provides constants and parameter values for the PrISM_Red
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_TCPWM_PrISM_Red_H)
#define CY_TCPWM_PrISM_Red_H


#include "CyLib.h"
#include "cytypes.h"
#include "cyfitter.h"


/*******************************************************************************
* Internal Type defines
*******************************************************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} PrISM_Red_BACKUP_STRUCT;


/*******************************************************************************
* Variables
*******************************************************************************/
extern uint8  PrISM_Red_initVar;


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define PrISM_Red_CY_TCPWM_V2                    (CYIPBLOCK_m0s8tcpwm_VERSION == 2u)
#define PrISM_Red_CY_TCPWM_4000                  (CY_PSOC4_4000)

/* TCPWM Configuration */
#define PrISM_Red_CONFIG                         (7lu)

/* Quad Mode */
/* Parameters */
#define PrISM_Red_QUAD_ENCODING_MODES            (0lu)
#define PrISM_Red_QUAD_AUTO_START                (1lu)

/* Signal modes */
#define PrISM_Red_QUAD_INDEX_SIGNAL_MODE         (0lu)
#define PrISM_Red_QUAD_PHIA_SIGNAL_MODE          (3lu)
#define PrISM_Red_QUAD_PHIB_SIGNAL_MODE          (3lu)
#define PrISM_Red_QUAD_STOP_SIGNAL_MODE          (0lu)

/* Signal present */
#define PrISM_Red_QUAD_INDEX_SIGNAL_PRESENT      (0lu)
#define PrISM_Red_QUAD_STOP_SIGNAL_PRESENT       (0lu)

/* Interrupt Mask */
#define PrISM_Red_QUAD_INTERRUPT_MASK            (1lu)

/* Timer/Counter Mode */
/* Parameters */
#define PrISM_Red_TC_RUN_MODE                    (0lu)
#define PrISM_Red_TC_COUNTER_MODE                (0lu)
#define PrISM_Red_TC_COMP_CAP_MODE               (2lu)
#define PrISM_Red_TC_PRESCALER                   (0lu)

/* Signal modes */
#define PrISM_Red_TC_RELOAD_SIGNAL_MODE          (0lu)
#define PrISM_Red_TC_COUNT_SIGNAL_MODE           (3lu)
#define PrISM_Red_TC_START_SIGNAL_MODE           (0lu)
#define PrISM_Red_TC_STOP_SIGNAL_MODE            (0lu)
#define PrISM_Red_TC_CAPTURE_SIGNAL_MODE         (0lu)

/* Signal present */
#define PrISM_Red_TC_RELOAD_SIGNAL_PRESENT       (0lu)
#define PrISM_Red_TC_COUNT_SIGNAL_PRESENT        (0lu)
#define PrISM_Red_TC_START_SIGNAL_PRESENT        (0lu)
#define PrISM_Red_TC_STOP_SIGNAL_PRESENT         (0lu)
#define PrISM_Red_TC_CAPTURE_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define PrISM_Red_TC_INTERRUPT_MASK              (1lu)

/* PWM Mode */
/* Parameters */
#define PrISM_Red_PWM_KILL_EVENT                 (0lu)
#define PrISM_Red_PWM_STOP_EVENT                 (0lu)
#define PrISM_Red_PWM_MODE                       (6lu)
#define PrISM_Red_PWM_OUT_N_INVERT               (0lu)
#define PrISM_Red_PWM_OUT_INVERT                 (1lu)
#define PrISM_Red_PWM_ALIGN                      (1lu)
#define PrISM_Red_PWM_RUN_MODE                   (0lu)
#define PrISM_Red_PWM_DEAD_TIME_CYCLE            (0lu)
#define PrISM_Red_PWM_PRESCALER                  (0lu)

/* Signal modes */
#define PrISM_Red_PWM_RELOAD_SIGNAL_MODE         (0lu)
#define PrISM_Red_PWM_COUNT_SIGNAL_MODE          (3lu)
#define PrISM_Red_PWM_START_SIGNAL_MODE          (0lu)
#define PrISM_Red_PWM_STOP_SIGNAL_MODE           (0lu)
#define PrISM_Red_PWM_SWITCH_SIGNAL_MODE         (0lu)

/* Signal present */
#define PrISM_Red_PWM_RELOAD_SIGNAL_PRESENT      (0lu)
#define PrISM_Red_PWM_COUNT_SIGNAL_PRESENT       (0lu)
#define PrISM_Red_PWM_START_SIGNAL_PRESENT       (0lu)
#define PrISM_Red_PWM_STOP_SIGNAL_PRESENT        (0lu)
#define PrISM_Red_PWM_SWITCH_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define PrISM_Red_PWM_INTERRUPT_MASK             (0lu)


/***************************************
*    Initial Parameter Constants
***************************************/

/* Timer/Counter Mode */
#define PrISM_Red_TC_PERIOD_VALUE                (65535lu)
#define PrISM_Red_TC_COMPARE_VALUE               (65535lu)
#define PrISM_Red_TC_COMPARE_BUF_VALUE           (65535lu)
#define PrISM_Red_TC_COMPARE_SWAP                (0lu)

/* PWM Mode */
#define PrISM_Red_PWM_PERIOD_VALUE               (65535lu)
#define PrISM_Red_PWM_PERIOD_BUF_VALUE           (65535lu)
#define PrISM_Red_PWM_PERIOD_SWAP                (0lu)
#define PrISM_Red_PWM_COMPARE_VALUE              (255lu)
#define PrISM_Red_PWM_COMPARE_BUF_VALUE          (65535lu)
#define PrISM_Red_PWM_COMPARE_SWAP               (0lu)


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define PrISM_Red__LEFT 0
#define PrISM_Red__RIGHT 1
#define PrISM_Red__CENTER 2
#define PrISM_Red__ASYMMETRIC 3

#define PrISM_Red__X1 0
#define PrISM_Red__X2 1
#define PrISM_Red__X4 2

#define PrISM_Red__PWM 4
#define PrISM_Red__PWM_DT 5
#define PrISM_Red__PWM_PR 6

#define PrISM_Red__INVERSE 1
#define PrISM_Red__DIRECT 0

#define PrISM_Red__CAPTURE 2
#define PrISM_Red__COMPARE 0

#define PrISM_Red__TRIG_LEVEL 3
#define PrISM_Red__TRIG_RISING 0
#define PrISM_Red__TRIG_FALLING 1
#define PrISM_Red__TRIG_BOTH 2

#define PrISM_Red__INTR_MASK_TC 1
#define PrISM_Red__INTR_MASK_CC_MATCH 2
#define PrISM_Red__INTR_MASK_NONE 0
#define PrISM_Red__INTR_MASK_TC_CC 3

#define PrISM_Red__UNCONFIG 8
#define PrISM_Red__TIMER 1
#define PrISM_Red__QUAD 3
#define PrISM_Red__PWM_SEL 7

#define PrISM_Red__COUNT_UP 0
#define PrISM_Red__COUNT_DOWN 1
#define PrISM_Red__COUNT_UPDOWN0 2
#define PrISM_Red__COUNT_UPDOWN1 3


/* Prescaler */
#define PrISM_Red_PRESCALE_DIVBY1                ((uint32)(0u << PrISM_Red_PRESCALER_SHIFT))
#define PrISM_Red_PRESCALE_DIVBY2                ((uint32)(1u << PrISM_Red_PRESCALER_SHIFT))
#define PrISM_Red_PRESCALE_DIVBY4                ((uint32)(2u << PrISM_Red_PRESCALER_SHIFT))
#define PrISM_Red_PRESCALE_DIVBY8                ((uint32)(3u << PrISM_Red_PRESCALER_SHIFT))
#define PrISM_Red_PRESCALE_DIVBY16               ((uint32)(4u << PrISM_Red_PRESCALER_SHIFT))
#define PrISM_Red_PRESCALE_DIVBY32               ((uint32)(5u << PrISM_Red_PRESCALER_SHIFT))
#define PrISM_Red_PRESCALE_DIVBY64               ((uint32)(6u << PrISM_Red_PRESCALER_SHIFT))
#define PrISM_Red_PRESCALE_DIVBY128              ((uint32)(7u << PrISM_Red_PRESCALER_SHIFT))

/* TCPWM set modes */
#define PrISM_Red_MODE_TIMER_COMPARE             ((uint32)(PrISM_Red__COMPARE         <<  \
                                                                  PrISM_Red_MODE_SHIFT))
#define PrISM_Red_MODE_TIMER_CAPTURE             ((uint32)(PrISM_Red__CAPTURE         <<  \
                                                                  PrISM_Red_MODE_SHIFT))
#define PrISM_Red_MODE_QUAD                      ((uint32)(PrISM_Red__QUAD            <<  \
                                                                  PrISM_Red_MODE_SHIFT))
#define PrISM_Red_MODE_PWM                       ((uint32)(PrISM_Red__PWM             <<  \
                                                                  PrISM_Red_MODE_SHIFT))
#define PrISM_Red_MODE_PWM_DT                    ((uint32)(PrISM_Red__PWM_DT          <<  \
                                                                  PrISM_Red_MODE_SHIFT))
#define PrISM_Red_MODE_PWM_PR                    ((uint32)(PrISM_Red__PWM_PR          <<  \
                                                                  PrISM_Red_MODE_SHIFT))

/* Quad Modes */
#define PrISM_Red_MODE_X1                        ((uint32)(PrISM_Red__X1              <<  \
                                                                  PrISM_Red_QUAD_MODE_SHIFT))
#define PrISM_Red_MODE_X2                        ((uint32)(PrISM_Red__X2              <<  \
                                                                  PrISM_Red_QUAD_MODE_SHIFT))
#define PrISM_Red_MODE_X4                        ((uint32)(PrISM_Red__X4              <<  \
                                                                  PrISM_Red_QUAD_MODE_SHIFT))

/* Counter modes */
#define PrISM_Red_COUNT_UP                       ((uint32)(PrISM_Red__COUNT_UP        <<  \
                                                                  PrISM_Red_UPDOWN_SHIFT))
#define PrISM_Red_COUNT_DOWN                     ((uint32)(PrISM_Red__COUNT_DOWN      <<  \
                                                                  PrISM_Red_UPDOWN_SHIFT))
#define PrISM_Red_COUNT_UPDOWN0                  ((uint32)(PrISM_Red__COUNT_UPDOWN0   <<  \
                                                                  PrISM_Red_UPDOWN_SHIFT))
#define PrISM_Red_COUNT_UPDOWN1                  ((uint32)(PrISM_Red__COUNT_UPDOWN1   <<  \
                                                                  PrISM_Red_UPDOWN_SHIFT))

/* PWM output invert */
#define PrISM_Red_INVERT_LINE                    ((uint32)(PrISM_Red__INVERSE         <<  \
                                                                  PrISM_Red_INV_OUT_SHIFT))
#define PrISM_Red_INVERT_LINE_N                  ((uint32)(PrISM_Red__INVERSE         <<  \
                                                                  PrISM_Red_INV_COMPL_OUT_SHIFT))

/* Trigger modes */
#define PrISM_Red_TRIG_RISING                    ((uint32)PrISM_Red__TRIG_RISING)
#define PrISM_Red_TRIG_FALLING                   ((uint32)PrISM_Red__TRIG_FALLING)
#define PrISM_Red_TRIG_BOTH                      ((uint32)PrISM_Red__TRIG_BOTH)
#define PrISM_Red_TRIG_LEVEL                     ((uint32)PrISM_Red__TRIG_LEVEL)

/* Interrupt mask */
#define PrISM_Red_INTR_MASK_TC                   ((uint32)PrISM_Red__INTR_MASK_TC)
#define PrISM_Red_INTR_MASK_CC_MATCH             ((uint32)PrISM_Red__INTR_MASK_CC_MATCH)

/* PWM Output Controls */
#define PrISM_Red_CC_MATCH_SET                   (0x00u)
#define PrISM_Red_CC_MATCH_CLEAR                 (0x01u)
#define PrISM_Red_CC_MATCH_INVERT                (0x02u)
#define PrISM_Red_CC_MATCH_NO_CHANGE             (0x03u)
#define PrISM_Red_OVERLOW_SET                    (0x00u)
#define PrISM_Red_OVERLOW_CLEAR                  (0x04u)
#define PrISM_Red_OVERLOW_INVERT                 (0x08u)
#define PrISM_Red_OVERLOW_NO_CHANGE              (0x0Cu)
#define PrISM_Red_UNDERFLOW_SET                  (0x00u)
#define PrISM_Red_UNDERFLOW_CLEAR                (0x10u)
#define PrISM_Red_UNDERFLOW_INVERT               (0x20u)
#define PrISM_Red_UNDERFLOW_NO_CHANGE            (0x30u)

/* PWM Align */
#define PrISM_Red_PWM_MODE_LEFT                  (PrISM_Red_CC_MATCH_CLEAR        |   \
                                                         PrISM_Red_OVERLOW_SET           |   \
                                                         PrISM_Red_UNDERFLOW_NO_CHANGE)
#define PrISM_Red_PWM_MODE_RIGHT                 (PrISM_Red_CC_MATCH_SET          |   \
                                                         PrISM_Red_OVERLOW_NO_CHANGE     |   \
                                                         PrISM_Red_UNDERFLOW_CLEAR)
#define PrISM_Red_PWM_MODE_ASYM                  (PrISM_Red_CC_MATCH_INVERT       |   \
                                                         PrISM_Red_OVERLOW_SET           |   \
                                                         PrISM_Red_UNDERFLOW_CLEAR)

#if (PrISM_Red_CY_TCPWM_V2)
    #if(PrISM_Red_CY_TCPWM_4000)
        #define PrISM_Red_PWM_MODE_CENTER                (PrISM_Red_CC_MATCH_INVERT       |   \
                                                                 PrISM_Red_OVERLOW_NO_CHANGE     |   \
                                                                 PrISM_Red_UNDERFLOW_CLEAR)
    #else
        #define PrISM_Red_PWM_MODE_CENTER                (PrISM_Red_CC_MATCH_INVERT       |   \
                                                                 PrISM_Red_OVERLOW_SET           |   \
                                                                 PrISM_Red_UNDERFLOW_CLEAR)
    #endif /* (PrISM_Red_CY_TCPWM_4000) */
#else
    #define PrISM_Red_PWM_MODE_CENTER                (PrISM_Red_CC_MATCH_INVERT       |   \
                                                             PrISM_Red_OVERLOW_NO_CHANGE     |   \
                                                             PrISM_Red_UNDERFLOW_CLEAR)
#endif /* (PrISM_Red_CY_TCPWM_NEW) */

/* Command operations without condition */
#define PrISM_Red_CMD_CAPTURE                    (0u)
#define PrISM_Red_CMD_RELOAD                     (8u)
#define PrISM_Red_CMD_STOP                       (16u)
#define PrISM_Red_CMD_START                      (24u)

/* Status */
#define PrISM_Red_STATUS_DOWN                    (1u)
#define PrISM_Red_STATUS_RUNNING                 (2u)


/***************************************
*        Function Prototypes
****************************************/

void   PrISM_Red_Init(void);
void   PrISM_Red_Enable(void);
void   PrISM_Red_Start(void);
void   PrISM_Red_Stop(void);

void   PrISM_Red_SetMode(uint32 mode);
void   PrISM_Red_SetCounterMode(uint32 counterMode);
void   PrISM_Red_SetPWMMode(uint32 modeMask);
void   PrISM_Red_SetQDMode(uint32 qdMode);

void   PrISM_Red_SetPrescaler(uint32 prescaler);
void   PrISM_Red_TriggerCommand(uint32 mask, uint32 command);
void   PrISM_Red_SetOneShot(uint32 oneShotEnable);
uint32 PrISM_Red_ReadStatus(void);

void   PrISM_Red_SetPWMSyncKill(uint32 syncKillEnable);
void   PrISM_Red_SetPWMStopOnKill(uint32 stopOnKillEnable);
void   PrISM_Red_SetPWMDeadTime(uint32 deadTime);
void   PrISM_Red_SetPWMInvert(uint32 mask);

void   PrISM_Red_SetInterruptMode(uint32 interruptMask);
uint32 PrISM_Red_GetInterruptSourceMasked(void);
uint32 PrISM_Red_GetInterruptSource(void);
void   PrISM_Red_ClearInterrupt(uint32 interruptMask);
void   PrISM_Red_SetInterrupt(uint32 interruptMask);

void   PrISM_Red_WriteCounter(uint32 count);
uint32 PrISM_Red_ReadCounter(void);

uint32 PrISM_Red_ReadCapture(void);
uint32 PrISM_Red_ReadCaptureBuf(void);

void   PrISM_Red_WritePeriod(uint32 period);
uint32 PrISM_Red_ReadPeriod(void);
void   PrISM_Red_WritePeriodBuf(uint32 periodBuf);
uint32 PrISM_Red_ReadPeriodBuf(void);

void   PrISM_Red_WriteCompare(uint32 compare);
uint32 PrISM_Red_ReadCompare(void);
void   PrISM_Red_WriteCompareBuf(uint32 compareBuf);
uint32 PrISM_Red_ReadCompareBuf(void);

void   PrISM_Red_SetPeriodSwap(uint32 swapEnable);
void   PrISM_Red_SetCompareSwap(uint32 swapEnable);

void   PrISM_Red_SetCaptureMode(uint32 triggerMode);
void   PrISM_Red_SetReloadMode(uint32 triggerMode);
void   PrISM_Red_SetStartMode(uint32 triggerMode);
void   PrISM_Red_SetStopMode(uint32 triggerMode);
void   PrISM_Red_SetCountMode(uint32 triggerMode);

void   PrISM_Red_SaveConfig(void);
void   PrISM_Red_RestoreConfig(void);
void   PrISM_Red_Sleep(void);
void   PrISM_Red_Wakeup(void);


/***************************************
*             Registers
***************************************/

#define PrISM_Red_BLOCK_CONTROL_REG              (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define PrISM_Red_BLOCK_CONTROL_PTR              ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define PrISM_Red_COMMAND_REG                    (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define PrISM_Red_COMMAND_PTR                    ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define PrISM_Red_INTRRUPT_CAUSE_REG             (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define PrISM_Red_INTRRUPT_CAUSE_PTR             ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define PrISM_Red_CONTROL_REG                    (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__CTRL )
#define PrISM_Red_CONTROL_PTR                    ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__CTRL )
#define PrISM_Red_STATUS_REG                     (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__STATUS )
#define PrISM_Red_STATUS_PTR                     ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__STATUS )
#define PrISM_Red_COUNTER_REG                    (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__COUNTER )
#define PrISM_Red_COUNTER_PTR                    ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__COUNTER )
#define PrISM_Red_COMP_CAP_REG                   (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__CC )
#define PrISM_Red_COMP_CAP_PTR                   ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__CC )
#define PrISM_Red_COMP_CAP_BUF_REG               (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__CC_BUFF )
#define PrISM_Red_COMP_CAP_BUF_PTR               ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__CC_BUFF )
#define PrISM_Red_PERIOD_REG                     (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__PERIOD )
#define PrISM_Red_PERIOD_PTR                     ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__PERIOD )
#define PrISM_Red_PERIOD_BUF_REG                 (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define PrISM_Red_PERIOD_BUF_PTR                 ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define PrISM_Red_TRIG_CONTROL0_REG              (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define PrISM_Red_TRIG_CONTROL0_PTR              ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define PrISM_Red_TRIG_CONTROL1_REG              (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define PrISM_Red_TRIG_CONTROL1_PTR              ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define PrISM_Red_TRIG_CONTROL2_REG              (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define PrISM_Red_TRIG_CONTROL2_PTR              ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define PrISM_Red_INTERRUPT_REQ_REG              (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__INTR )
#define PrISM_Red_INTERRUPT_REQ_PTR              ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__INTR )
#define PrISM_Red_INTERRUPT_SET_REG              (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__INTR_SET )
#define PrISM_Red_INTERRUPT_SET_PTR              ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__INTR_SET )
#define PrISM_Red_INTERRUPT_MASK_REG             (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__INTR_MASK )
#define PrISM_Red_INTERRUPT_MASK_PTR             ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__INTR_MASK )
#define PrISM_Red_INTERRUPT_MASKED_REG           (*(reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__INTR_MASKED )
#define PrISM_Red_INTERRUPT_MASKED_PTR           ( (reg32 *) PrISM_Red_cy_m0s8_tcpwm_1__INTR_MASKED )


/***************************************
*       Registers Constants
***************************************/

/* Mask */
#define PrISM_Red_MASK                           ((uint32)PrISM_Red_cy_m0s8_tcpwm_1__TCPWM_CTRL_MASK)

/* Shift constants for control register */
#define PrISM_Red_RELOAD_CC_SHIFT                (0u)
#define PrISM_Red_RELOAD_PERIOD_SHIFT            (1u)
#define PrISM_Red_PWM_SYNC_KILL_SHIFT            (2u)
#define PrISM_Red_PWM_STOP_KILL_SHIFT            (3u)
#define PrISM_Red_PRESCALER_SHIFT                (8u)
#define PrISM_Red_UPDOWN_SHIFT                   (16u)
#define PrISM_Red_ONESHOT_SHIFT                  (18u)
#define PrISM_Red_QUAD_MODE_SHIFT                (20u)
#define PrISM_Red_INV_OUT_SHIFT                  (20u)
#define PrISM_Red_INV_COMPL_OUT_SHIFT            (21u)
#define PrISM_Red_MODE_SHIFT                     (24u)

/* Mask constants for control register */
#define PrISM_Red_RELOAD_CC_MASK                 ((uint32)(PrISM_Red_1BIT_MASK        <<  \
                                                                            PrISM_Red_RELOAD_CC_SHIFT))
#define PrISM_Red_RELOAD_PERIOD_MASK             ((uint32)(PrISM_Red_1BIT_MASK        <<  \
                                                                            PrISM_Red_RELOAD_PERIOD_SHIFT))
#define PrISM_Red_PWM_SYNC_KILL_MASK             ((uint32)(PrISM_Red_1BIT_MASK        <<  \
                                                                            PrISM_Red_PWM_SYNC_KILL_SHIFT))
#define PrISM_Red_PWM_STOP_KILL_MASK             ((uint32)(PrISM_Red_1BIT_MASK        <<  \
                                                                            PrISM_Red_PWM_STOP_KILL_SHIFT))
#define PrISM_Red_PRESCALER_MASK                 ((uint32)(PrISM_Red_8BIT_MASK        <<  \
                                                                            PrISM_Red_PRESCALER_SHIFT))
#define PrISM_Red_UPDOWN_MASK                    ((uint32)(PrISM_Red_2BIT_MASK        <<  \
                                                                            PrISM_Red_UPDOWN_SHIFT))
#define PrISM_Red_ONESHOT_MASK                   ((uint32)(PrISM_Red_1BIT_MASK        <<  \
                                                                            PrISM_Red_ONESHOT_SHIFT))
#define PrISM_Red_QUAD_MODE_MASK                 ((uint32)(PrISM_Red_3BIT_MASK        <<  \
                                                                            PrISM_Red_QUAD_MODE_SHIFT))
#define PrISM_Red_INV_OUT_MASK                   ((uint32)(PrISM_Red_2BIT_MASK        <<  \
                                                                            PrISM_Red_INV_OUT_SHIFT))
#define PrISM_Red_MODE_MASK                      ((uint32)(PrISM_Red_3BIT_MASK        <<  \
                                                                            PrISM_Red_MODE_SHIFT))

/* Shift constants for trigger control register 1 */
#define PrISM_Red_CAPTURE_SHIFT                  (0u)
#define PrISM_Red_COUNT_SHIFT                    (2u)
#define PrISM_Red_RELOAD_SHIFT                   (4u)
#define PrISM_Red_STOP_SHIFT                     (6u)
#define PrISM_Red_START_SHIFT                    (8u)

/* Mask constants for trigger control register 1 */
#define PrISM_Red_CAPTURE_MASK                   ((uint32)(PrISM_Red_2BIT_MASK        <<  \
                                                                  PrISM_Red_CAPTURE_SHIFT))
#define PrISM_Red_COUNT_MASK                     ((uint32)(PrISM_Red_2BIT_MASK        <<  \
                                                                  PrISM_Red_COUNT_SHIFT))
#define PrISM_Red_RELOAD_MASK                    ((uint32)(PrISM_Red_2BIT_MASK        <<  \
                                                                  PrISM_Red_RELOAD_SHIFT))
#define PrISM_Red_STOP_MASK                      ((uint32)(PrISM_Red_2BIT_MASK        <<  \
                                                                  PrISM_Red_STOP_SHIFT))
#define PrISM_Red_START_MASK                     ((uint32)(PrISM_Red_2BIT_MASK        <<  \
                                                                  PrISM_Red_START_SHIFT))

/* MASK */
#define PrISM_Red_1BIT_MASK                      ((uint32)0x01u)
#define PrISM_Red_2BIT_MASK                      ((uint32)0x03u)
#define PrISM_Red_3BIT_MASK                      ((uint32)0x07u)
#define PrISM_Red_6BIT_MASK                      ((uint32)0x3Fu)
#define PrISM_Red_8BIT_MASK                      ((uint32)0xFFu)
#define PrISM_Red_16BIT_MASK                     ((uint32)0xFFFFu)

/* Shift constant for status register */
#define PrISM_Red_RUNNING_STATUS_SHIFT           (30u)


/***************************************
*    Initial Constants
***************************************/

#define PrISM_Red_CTRL_QUAD_BASE_CONFIG                                                          \
        (((uint32)(PrISM_Red_QUAD_ENCODING_MODES     << PrISM_Red_QUAD_MODE_SHIFT))       |\
         ((uint32)(PrISM_Red_CONFIG                  << PrISM_Red_MODE_SHIFT)))

#define PrISM_Red_CTRL_PWM_BASE_CONFIG                                                           \
        (((uint32)(PrISM_Red_PWM_STOP_EVENT          << PrISM_Red_PWM_STOP_KILL_SHIFT))   |\
         ((uint32)(PrISM_Red_PWM_OUT_INVERT          << PrISM_Red_INV_OUT_SHIFT))         |\
         ((uint32)(PrISM_Red_PWM_OUT_N_INVERT        << PrISM_Red_INV_COMPL_OUT_SHIFT))   |\
         ((uint32)(PrISM_Red_PWM_MODE                << PrISM_Red_MODE_SHIFT)))

#define PrISM_Red_CTRL_PWM_RUN_MODE                                                              \
            ((uint32)(PrISM_Red_PWM_RUN_MODE         << PrISM_Red_ONESHOT_SHIFT))
            
#define PrISM_Red_CTRL_PWM_ALIGN                                                                 \
            ((uint32)(PrISM_Red_PWM_ALIGN            << PrISM_Red_UPDOWN_SHIFT))

#define PrISM_Red_CTRL_PWM_KILL_EVENT                                                            \
             ((uint32)(PrISM_Red_PWM_KILL_EVENT      << PrISM_Red_PWM_SYNC_KILL_SHIFT))

#define PrISM_Red_CTRL_PWM_DEAD_TIME_CYCLE                                                       \
            ((uint32)(PrISM_Red_PWM_DEAD_TIME_CYCLE  << PrISM_Red_PRESCALER_SHIFT))

#define PrISM_Red_CTRL_PWM_PRESCALER                                                             \
            ((uint32)(PrISM_Red_PWM_PRESCALER        << PrISM_Red_PRESCALER_SHIFT))

#define PrISM_Red_CTRL_TIMER_BASE_CONFIG                                                         \
        (((uint32)(PrISM_Red_TC_PRESCALER            << PrISM_Red_PRESCALER_SHIFT))       |\
         ((uint32)(PrISM_Red_TC_COUNTER_MODE         << PrISM_Red_UPDOWN_SHIFT))          |\
         ((uint32)(PrISM_Red_TC_RUN_MODE             << PrISM_Red_ONESHOT_SHIFT))         |\
         ((uint32)(PrISM_Red_TC_COMP_CAP_MODE        << PrISM_Red_MODE_SHIFT)))
        
#define PrISM_Red_QUAD_SIGNALS_MODES                                                             \
        (((uint32)(PrISM_Red_QUAD_PHIA_SIGNAL_MODE   << PrISM_Red_COUNT_SHIFT))           |\
         ((uint32)(PrISM_Red_QUAD_INDEX_SIGNAL_MODE  << PrISM_Red_RELOAD_SHIFT))          |\
         ((uint32)(PrISM_Red_QUAD_STOP_SIGNAL_MODE   << PrISM_Red_STOP_SHIFT))            |\
         ((uint32)(PrISM_Red_QUAD_PHIB_SIGNAL_MODE   << PrISM_Red_START_SHIFT)))

#define PrISM_Red_PWM_SIGNALS_MODES                                                              \
        (((uint32)(PrISM_Red_PWM_SWITCH_SIGNAL_MODE  << PrISM_Red_CAPTURE_SHIFT))         |\
         ((uint32)(PrISM_Red_PWM_COUNT_SIGNAL_MODE   << PrISM_Red_COUNT_SHIFT))           |\
         ((uint32)(PrISM_Red_PWM_RELOAD_SIGNAL_MODE  << PrISM_Red_RELOAD_SHIFT))          |\
         ((uint32)(PrISM_Red_PWM_STOP_SIGNAL_MODE    << PrISM_Red_STOP_SHIFT))            |\
         ((uint32)(PrISM_Red_PWM_START_SIGNAL_MODE   << PrISM_Red_START_SHIFT)))

#define PrISM_Red_TIMER_SIGNALS_MODES                                                            \
        (((uint32)(PrISM_Red_TC_CAPTURE_SIGNAL_MODE  << PrISM_Red_CAPTURE_SHIFT))         |\
         ((uint32)(PrISM_Red_TC_COUNT_SIGNAL_MODE    << PrISM_Red_COUNT_SHIFT))           |\
         ((uint32)(PrISM_Red_TC_RELOAD_SIGNAL_MODE   << PrISM_Red_RELOAD_SHIFT))          |\
         ((uint32)(PrISM_Red_TC_STOP_SIGNAL_MODE     << PrISM_Red_STOP_SHIFT))            |\
         ((uint32)(PrISM_Red_TC_START_SIGNAL_MODE    << PrISM_Red_START_SHIFT)))
        
#define PrISM_Red_TIMER_UPDOWN_CNT_USED                                                          \
                ((PrISM_Red__COUNT_UPDOWN0 == PrISM_Red_TC_COUNTER_MODE)                  ||\
                 (PrISM_Red__COUNT_UPDOWN1 == PrISM_Red_TC_COUNTER_MODE))

#define PrISM_Red_PWM_UPDOWN_CNT_USED                                                            \
                ((PrISM_Red__CENTER == PrISM_Red_PWM_ALIGN)                               ||\
                 (PrISM_Red__ASYMMETRIC == PrISM_Red_PWM_ALIGN))               
        
#define PrISM_Red_PWM_PR_INIT_VALUE              (1u)
#define PrISM_Red_QUAD_PERIOD_INIT_VALUE         (0x8000u)



#endif /* End CY_TCPWM_PrISM_Red_H */

/* [] END OF FILE */
