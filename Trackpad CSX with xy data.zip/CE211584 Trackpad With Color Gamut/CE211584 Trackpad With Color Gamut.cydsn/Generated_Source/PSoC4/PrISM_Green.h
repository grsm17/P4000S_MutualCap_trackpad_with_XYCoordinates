/*******************************************************************************
* File Name: PrISM_Green.h
* Version 2.10
*
* Description:
*  This file provides constants and parameter values for the PrISM_Green
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_TCPWM_PrISM_Green_H)
#define CY_TCPWM_PrISM_Green_H


#include "CyLib.h"
#include "cytypes.h"
#include "cyfitter.h"


/*******************************************************************************
* Internal Type defines
*******************************************************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} PrISM_Green_BACKUP_STRUCT;


/*******************************************************************************
* Variables
*******************************************************************************/
extern uint8  PrISM_Green_initVar;


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define PrISM_Green_CY_TCPWM_V2                    (CYIPBLOCK_m0s8tcpwm_VERSION == 2u)
#define PrISM_Green_CY_TCPWM_4000                  (CY_PSOC4_4000)

/* TCPWM Configuration */
#define PrISM_Green_CONFIG                         (7lu)

/* Quad Mode */
/* Parameters */
#define PrISM_Green_QUAD_ENCODING_MODES            (0lu)
#define PrISM_Green_QUAD_AUTO_START                (1lu)

/* Signal modes */
#define PrISM_Green_QUAD_INDEX_SIGNAL_MODE         (0lu)
#define PrISM_Green_QUAD_PHIA_SIGNAL_MODE          (3lu)
#define PrISM_Green_QUAD_PHIB_SIGNAL_MODE          (3lu)
#define PrISM_Green_QUAD_STOP_SIGNAL_MODE          (0lu)

/* Signal present */
#define PrISM_Green_QUAD_INDEX_SIGNAL_PRESENT      (0lu)
#define PrISM_Green_QUAD_STOP_SIGNAL_PRESENT       (0lu)

/* Interrupt Mask */
#define PrISM_Green_QUAD_INTERRUPT_MASK            (1lu)

/* Timer/Counter Mode */
/* Parameters */
#define PrISM_Green_TC_RUN_MODE                    (0lu)
#define PrISM_Green_TC_COUNTER_MODE                (0lu)
#define PrISM_Green_TC_COMP_CAP_MODE               (2lu)
#define PrISM_Green_TC_PRESCALER                   (0lu)

/* Signal modes */
#define PrISM_Green_TC_RELOAD_SIGNAL_MODE          (0lu)
#define PrISM_Green_TC_COUNT_SIGNAL_MODE           (3lu)
#define PrISM_Green_TC_START_SIGNAL_MODE           (0lu)
#define PrISM_Green_TC_STOP_SIGNAL_MODE            (0lu)
#define PrISM_Green_TC_CAPTURE_SIGNAL_MODE         (0lu)

/* Signal present */
#define PrISM_Green_TC_RELOAD_SIGNAL_PRESENT       (0lu)
#define PrISM_Green_TC_COUNT_SIGNAL_PRESENT        (0lu)
#define PrISM_Green_TC_START_SIGNAL_PRESENT        (0lu)
#define PrISM_Green_TC_STOP_SIGNAL_PRESENT         (0lu)
#define PrISM_Green_TC_CAPTURE_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define PrISM_Green_TC_INTERRUPT_MASK              (1lu)

/* PWM Mode */
/* Parameters */
#define PrISM_Green_PWM_KILL_EVENT                 (0lu)
#define PrISM_Green_PWM_STOP_EVENT                 (0lu)
#define PrISM_Green_PWM_MODE                       (6lu)
#define PrISM_Green_PWM_OUT_N_INVERT               (0lu)
#define PrISM_Green_PWM_OUT_INVERT                 (1lu)
#define PrISM_Green_PWM_ALIGN                      (0lu)
#define PrISM_Green_PWM_RUN_MODE                   (0lu)
#define PrISM_Green_PWM_DEAD_TIME_CYCLE            (0lu)
#define PrISM_Green_PWM_PRESCALER                  (0lu)

/* Signal modes */
#define PrISM_Green_PWM_RELOAD_SIGNAL_MODE         (0lu)
#define PrISM_Green_PWM_COUNT_SIGNAL_MODE          (3lu)
#define PrISM_Green_PWM_START_SIGNAL_MODE          (0lu)
#define PrISM_Green_PWM_STOP_SIGNAL_MODE           (0lu)
#define PrISM_Green_PWM_SWITCH_SIGNAL_MODE         (0lu)

/* Signal present */
#define PrISM_Green_PWM_RELOAD_SIGNAL_PRESENT      (0lu)
#define PrISM_Green_PWM_COUNT_SIGNAL_PRESENT       (0lu)
#define PrISM_Green_PWM_START_SIGNAL_PRESENT       (0lu)
#define PrISM_Green_PWM_STOP_SIGNAL_PRESENT        (0lu)
#define PrISM_Green_PWM_SWITCH_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define PrISM_Green_PWM_INTERRUPT_MASK             (0lu)


/***************************************
*    Initial Parameter Constants
***************************************/

/* Timer/Counter Mode */
#define PrISM_Green_TC_PERIOD_VALUE                (65535lu)
#define PrISM_Green_TC_COMPARE_VALUE               (65535lu)
#define PrISM_Green_TC_COMPARE_BUF_VALUE           (65535lu)
#define PrISM_Green_TC_COMPARE_SWAP                (0lu)

/* PWM Mode */
#define PrISM_Green_PWM_PERIOD_VALUE               (65535lu)
#define PrISM_Green_PWM_PERIOD_BUF_VALUE           (65535lu)
#define PrISM_Green_PWM_PERIOD_SWAP                (0lu)
#define PrISM_Green_PWM_COMPARE_VALUE              (255lu)
#define PrISM_Green_PWM_COMPARE_BUF_VALUE          (65535lu)
#define PrISM_Green_PWM_COMPARE_SWAP               (0lu)


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define PrISM_Green__LEFT 0
#define PrISM_Green__RIGHT 1
#define PrISM_Green__CENTER 2
#define PrISM_Green__ASYMMETRIC 3

#define PrISM_Green__X1 0
#define PrISM_Green__X2 1
#define PrISM_Green__X4 2

#define PrISM_Green__PWM 4
#define PrISM_Green__PWM_DT 5
#define PrISM_Green__PWM_PR 6

#define PrISM_Green__INVERSE 1
#define PrISM_Green__DIRECT 0

#define PrISM_Green__CAPTURE 2
#define PrISM_Green__COMPARE 0

#define PrISM_Green__TRIG_LEVEL 3
#define PrISM_Green__TRIG_RISING 0
#define PrISM_Green__TRIG_FALLING 1
#define PrISM_Green__TRIG_BOTH 2

#define PrISM_Green__INTR_MASK_TC 1
#define PrISM_Green__INTR_MASK_CC_MATCH 2
#define PrISM_Green__INTR_MASK_NONE 0
#define PrISM_Green__INTR_MASK_TC_CC 3

#define PrISM_Green__UNCONFIG 8
#define PrISM_Green__TIMER 1
#define PrISM_Green__QUAD 3
#define PrISM_Green__PWM_SEL 7

#define PrISM_Green__COUNT_UP 0
#define PrISM_Green__COUNT_DOWN 1
#define PrISM_Green__COUNT_UPDOWN0 2
#define PrISM_Green__COUNT_UPDOWN1 3


/* Prescaler */
#define PrISM_Green_PRESCALE_DIVBY1                ((uint32)(0u << PrISM_Green_PRESCALER_SHIFT))
#define PrISM_Green_PRESCALE_DIVBY2                ((uint32)(1u << PrISM_Green_PRESCALER_SHIFT))
#define PrISM_Green_PRESCALE_DIVBY4                ((uint32)(2u << PrISM_Green_PRESCALER_SHIFT))
#define PrISM_Green_PRESCALE_DIVBY8                ((uint32)(3u << PrISM_Green_PRESCALER_SHIFT))
#define PrISM_Green_PRESCALE_DIVBY16               ((uint32)(4u << PrISM_Green_PRESCALER_SHIFT))
#define PrISM_Green_PRESCALE_DIVBY32               ((uint32)(5u << PrISM_Green_PRESCALER_SHIFT))
#define PrISM_Green_PRESCALE_DIVBY64               ((uint32)(6u << PrISM_Green_PRESCALER_SHIFT))
#define PrISM_Green_PRESCALE_DIVBY128              ((uint32)(7u << PrISM_Green_PRESCALER_SHIFT))

/* TCPWM set modes */
#define PrISM_Green_MODE_TIMER_COMPARE             ((uint32)(PrISM_Green__COMPARE         <<  \
                                                                  PrISM_Green_MODE_SHIFT))
#define PrISM_Green_MODE_TIMER_CAPTURE             ((uint32)(PrISM_Green__CAPTURE         <<  \
                                                                  PrISM_Green_MODE_SHIFT))
#define PrISM_Green_MODE_QUAD                      ((uint32)(PrISM_Green__QUAD            <<  \
                                                                  PrISM_Green_MODE_SHIFT))
#define PrISM_Green_MODE_PWM                       ((uint32)(PrISM_Green__PWM             <<  \
                                                                  PrISM_Green_MODE_SHIFT))
#define PrISM_Green_MODE_PWM_DT                    ((uint32)(PrISM_Green__PWM_DT          <<  \
                                                                  PrISM_Green_MODE_SHIFT))
#define PrISM_Green_MODE_PWM_PR                    ((uint32)(PrISM_Green__PWM_PR          <<  \
                                                                  PrISM_Green_MODE_SHIFT))

/* Quad Modes */
#define PrISM_Green_MODE_X1                        ((uint32)(PrISM_Green__X1              <<  \
                                                                  PrISM_Green_QUAD_MODE_SHIFT))
#define PrISM_Green_MODE_X2                        ((uint32)(PrISM_Green__X2              <<  \
                                                                  PrISM_Green_QUAD_MODE_SHIFT))
#define PrISM_Green_MODE_X4                        ((uint32)(PrISM_Green__X4              <<  \
                                                                  PrISM_Green_QUAD_MODE_SHIFT))

/* Counter modes */
#define PrISM_Green_COUNT_UP                       ((uint32)(PrISM_Green__COUNT_UP        <<  \
                                                                  PrISM_Green_UPDOWN_SHIFT))
#define PrISM_Green_COUNT_DOWN                     ((uint32)(PrISM_Green__COUNT_DOWN      <<  \
                                                                  PrISM_Green_UPDOWN_SHIFT))
#define PrISM_Green_COUNT_UPDOWN0                  ((uint32)(PrISM_Green__COUNT_UPDOWN0   <<  \
                                                                  PrISM_Green_UPDOWN_SHIFT))
#define PrISM_Green_COUNT_UPDOWN1                  ((uint32)(PrISM_Green__COUNT_UPDOWN1   <<  \
                                                                  PrISM_Green_UPDOWN_SHIFT))

/* PWM output invert */
#define PrISM_Green_INVERT_LINE                    ((uint32)(PrISM_Green__INVERSE         <<  \
                                                                  PrISM_Green_INV_OUT_SHIFT))
#define PrISM_Green_INVERT_LINE_N                  ((uint32)(PrISM_Green__INVERSE         <<  \
                                                                  PrISM_Green_INV_COMPL_OUT_SHIFT))

/* Trigger modes */
#define PrISM_Green_TRIG_RISING                    ((uint32)PrISM_Green__TRIG_RISING)
#define PrISM_Green_TRIG_FALLING                   ((uint32)PrISM_Green__TRIG_FALLING)
#define PrISM_Green_TRIG_BOTH                      ((uint32)PrISM_Green__TRIG_BOTH)
#define PrISM_Green_TRIG_LEVEL                     ((uint32)PrISM_Green__TRIG_LEVEL)

/* Interrupt mask */
#define PrISM_Green_INTR_MASK_TC                   ((uint32)PrISM_Green__INTR_MASK_TC)
#define PrISM_Green_INTR_MASK_CC_MATCH             ((uint32)PrISM_Green__INTR_MASK_CC_MATCH)

/* PWM Output Controls */
#define PrISM_Green_CC_MATCH_SET                   (0x00u)
#define PrISM_Green_CC_MATCH_CLEAR                 (0x01u)
#define PrISM_Green_CC_MATCH_INVERT                (0x02u)
#define PrISM_Green_CC_MATCH_NO_CHANGE             (0x03u)
#define PrISM_Green_OVERLOW_SET                    (0x00u)
#define PrISM_Green_OVERLOW_CLEAR                  (0x04u)
#define PrISM_Green_OVERLOW_INVERT                 (0x08u)
#define PrISM_Green_OVERLOW_NO_CHANGE              (0x0Cu)
#define PrISM_Green_UNDERFLOW_SET                  (0x00u)
#define PrISM_Green_UNDERFLOW_CLEAR                (0x10u)
#define PrISM_Green_UNDERFLOW_INVERT               (0x20u)
#define PrISM_Green_UNDERFLOW_NO_CHANGE            (0x30u)

/* PWM Align */
#define PrISM_Green_PWM_MODE_LEFT                  (PrISM_Green_CC_MATCH_CLEAR        |   \
                                                         PrISM_Green_OVERLOW_SET           |   \
                                                         PrISM_Green_UNDERFLOW_NO_CHANGE)
#define PrISM_Green_PWM_MODE_RIGHT                 (PrISM_Green_CC_MATCH_SET          |   \
                                                         PrISM_Green_OVERLOW_NO_CHANGE     |   \
                                                         PrISM_Green_UNDERFLOW_CLEAR)
#define PrISM_Green_PWM_MODE_ASYM                  (PrISM_Green_CC_MATCH_INVERT       |   \
                                                         PrISM_Green_OVERLOW_SET           |   \
                                                         PrISM_Green_UNDERFLOW_CLEAR)

#if (PrISM_Green_CY_TCPWM_V2)
    #if(PrISM_Green_CY_TCPWM_4000)
        #define PrISM_Green_PWM_MODE_CENTER                (PrISM_Green_CC_MATCH_INVERT       |   \
                                                                 PrISM_Green_OVERLOW_NO_CHANGE     |   \
                                                                 PrISM_Green_UNDERFLOW_CLEAR)
    #else
        #define PrISM_Green_PWM_MODE_CENTER                (PrISM_Green_CC_MATCH_INVERT       |   \
                                                                 PrISM_Green_OVERLOW_SET           |   \
                                                                 PrISM_Green_UNDERFLOW_CLEAR)
    #endif /* (PrISM_Green_CY_TCPWM_4000) */
#else
    #define PrISM_Green_PWM_MODE_CENTER                (PrISM_Green_CC_MATCH_INVERT       |   \
                                                             PrISM_Green_OVERLOW_NO_CHANGE     |   \
                                                             PrISM_Green_UNDERFLOW_CLEAR)
#endif /* (PrISM_Green_CY_TCPWM_NEW) */

/* Command operations without condition */
#define PrISM_Green_CMD_CAPTURE                    (0u)
#define PrISM_Green_CMD_RELOAD                     (8u)
#define PrISM_Green_CMD_STOP                       (16u)
#define PrISM_Green_CMD_START                      (24u)

/* Status */
#define PrISM_Green_STATUS_DOWN                    (1u)
#define PrISM_Green_STATUS_RUNNING                 (2u)


/***************************************
*        Function Prototypes
****************************************/

void   PrISM_Green_Init(void);
void   PrISM_Green_Enable(void);
void   PrISM_Green_Start(void);
void   PrISM_Green_Stop(void);

void   PrISM_Green_SetMode(uint32 mode);
void   PrISM_Green_SetCounterMode(uint32 counterMode);
void   PrISM_Green_SetPWMMode(uint32 modeMask);
void   PrISM_Green_SetQDMode(uint32 qdMode);

void   PrISM_Green_SetPrescaler(uint32 prescaler);
void   PrISM_Green_TriggerCommand(uint32 mask, uint32 command);
void   PrISM_Green_SetOneShot(uint32 oneShotEnable);
uint32 PrISM_Green_ReadStatus(void);

void   PrISM_Green_SetPWMSyncKill(uint32 syncKillEnable);
void   PrISM_Green_SetPWMStopOnKill(uint32 stopOnKillEnable);
void   PrISM_Green_SetPWMDeadTime(uint32 deadTime);
void   PrISM_Green_SetPWMInvert(uint32 mask);

void   PrISM_Green_SetInterruptMode(uint32 interruptMask);
uint32 PrISM_Green_GetInterruptSourceMasked(void);
uint32 PrISM_Green_GetInterruptSource(void);
void   PrISM_Green_ClearInterrupt(uint32 interruptMask);
void   PrISM_Green_SetInterrupt(uint32 interruptMask);

void   PrISM_Green_WriteCounter(uint32 count);
uint32 PrISM_Green_ReadCounter(void);

uint32 PrISM_Green_ReadCapture(void);
uint32 PrISM_Green_ReadCaptureBuf(void);

void   PrISM_Green_WritePeriod(uint32 period);
uint32 PrISM_Green_ReadPeriod(void);
void   PrISM_Green_WritePeriodBuf(uint32 periodBuf);
uint32 PrISM_Green_ReadPeriodBuf(void);

void   PrISM_Green_WriteCompare(uint32 compare);
uint32 PrISM_Green_ReadCompare(void);
void   PrISM_Green_WriteCompareBuf(uint32 compareBuf);
uint32 PrISM_Green_ReadCompareBuf(void);

void   PrISM_Green_SetPeriodSwap(uint32 swapEnable);
void   PrISM_Green_SetCompareSwap(uint32 swapEnable);

void   PrISM_Green_SetCaptureMode(uint32 triggerMode);
void   PrISM_Green_SetReloadMode(uint32 triggerMode);
void   PrISM_Green_SetStartMode(uint32 triggerMode);
void   PrISM_Green_SetStopMode(uint32 triggerMode);
void   PrISM_Green_SetCountMode(uint32 triggerMode);

void   PrISM_Green_SaveConfig(void);
void   PrISM_Green_RestoreConfig(void);
void   PrISM_Green_Sleep(void);
void   PrISM_Green_Wakeup(void);


/***************************************
*             Registers
***************************************/

#define PrISM_Green_BLOCK_CONTROL_REG              (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define PrISM_Green_BLOCK_CONTROL_PTR              ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define PrISM_Green_COMMAND_REG                    (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define PrISM_Green_COMMAND_PTR                    ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define PrISM_Green_INTRRUPT_CAUSE_REG             (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define PrISM_Green_INTRRUPT_CAUSE_PTR             ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define PrISM_Green_CONTROL_REG                    (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__CTRL )
#define PrISM_Green_CONTROL_PTR                    ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__CTRL )
#define PrISM_Green_STATUS_REG                     (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__STATUS )
#define PrISM_Green_STATUS_PTR                     ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__STATUS )
#define PrISM_Green_COUNTER_REG                    (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__COUNTER )
#define PrISM_Green_COUNTER_PTR                    ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__COUNTER )
#define PrISM_Green_COMP_CAP_REG                   (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__CC )
#define PrISM_Green_COMP_CAP_PTR                   ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__CC )
#define PrISM_Green_COMP_CAP_BUF_REG               (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__CC_BUFF )
#define PrISM_Green_COMP_CAP_BUF_PTR               ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__CC_BUFF )
#define PrISM_Green_PERIOD_REG                     (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__PERIOD )
#define PrISM_Green_PERIOD_PTR                     ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__PERIOD )
#define PrISM_Green_PERIOD_BUF_REG                 (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define PrISM_Green_PERIOD_BUF_PTR                 ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define PrISM_Green_TRIG_CONTROL0_REG              (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define PrISM_Green_TRIG_CONTROL0_PTR              ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define PrISM_Green_TRIG_CONTROL1_REG              (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define PrISM_Green_TRIG_CONTROL1_PTR              ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define PrISM_Green_TRIG_CONTROL2_REG              (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define PrISM_Green_TRIG_CONTROL2_PTR              ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define PrISM_Green_INTERRUPT_REQ_REG              (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__INTR )
#define PrISM_Green_INTERRUPT_REQ_PTR              ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__INTR )
#define PrISM_Green_INTERRUPT_SET_REG              (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__INTR_SET )
#define PrISM_Green_INTERRUPT_SET_PTR              ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__INTR_SET )
#define PrISM_Green_INTERRUPT_MASK_REG             (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__INTR_MASK )
#define PrISM_Green_INTERRUPT_MASK_PTR             ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__INTR_MASK )
#define PrISM_Green_INTERRUPT_MASKED_REG           (*(reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__INTR_MASKED )
#define PrISM_Green_INTERRUPT_MASKED_PTR           ( (reg32 *) PrISM_Green_cy_m0s8_tcpwm_1__INTR_MASKED )


/***************************************
*       Registers Constants
***************************************/

/* Mask */
#define PrISM_Green_MASK                           ((uint32)PrISM_Green_cy_m0s8_tcpwm_1__TCPWM_CTRL_MASK)

/* Shift constants for control register */
#define PrISM_Green_RELOAD_CC_SHIFT                (0u)
#define PrISM_Green_RELOAD_PERIOD_SHIFT            (1u)
#define PrISM_Green_PWM_SYNC_KILL_SHIFT            (2u)
#define PrISM_Green_PWM_STOP_KILL_SHIFT            (3u)
#define PrISM_Green_PRESCALER_SHIFT                (8u)
#define PrISM_Green_UPDOWN_SHIFT                   (16u)
#define PrISM_Green_ONESHOT_SHIFT                  (18u)
#define PrISM_Green_QUAD_MODE_SHIFT                (20u)
#define PrISM_Green_INV_OUT_SHIFT                  (20u)
#define PrISM_Green_INV_COMPL_OUT_SHIFT            (21u)
#define PrISM_Green_MODE_SHIFT                     (24u)

/* Mask constants for control register */
#define PrISM_Green_RELOAD_CC_MASK                 ((uint32)(PrISM_Green_1BIT_MASK        <<  \
                                                                            PrISM_Green_RELOAD_CC_SHIFT))
#define PrISM_Green_RELOAD_PERIOD_MASK             ((uint32)(PrISM_Green_1BIT_MASK        <<  \
                                                                            PrISM_Green_RELOAD_PERIOD_SHIFT))
#define PrISM_Green_PWM_SYNC_KILL_MASK             ((uint32)(PrISM_Green_1BIT_MASK        <<  \
                                                                            PrISM_Green_PWM_SYNC_KILL_SHIFT))
#define PrISM_Green_PWM_STOP_KILL_MASK             ((uint32)(PrISM_Green_1BIT_MASK        <<  \
                                                                            PrISM_Green_PWM_STOP_KILL_SHIFT))
#define PrISM_Green_PRESCALER_MASK                 ((uint32)(PrISM_Green_8BIT_MASK        <<  \
                                                                            PrISM_Green_PRESCALER_SHIFT))
#define PrISM_Green_UPDOWN_MASK                    ((uint32)(PrISM_Green_2BIT_MASK        <<  \
                                                                            PrISM_Green_UPDOWN_SHIFT))
#define PrISM_Green_ONESHOT_MASK                   ((uint32)(PrISM_Green_1BIT_MASK        <<  \
                                                                            PrISM_Green_ONESHOT_SHIFT))
#define PrISM_Green_QUAD_MODE_MASK                 ((uint32)(PrISM_Green_3BIT_MASK        <<  \
                                                                            PrISM_Green_QUAD_MODE_SHIFT))
#define PrISM_Green_INV_OUT_MASK                   ((uint32)(PrISM_Green_2BIT_MASK        <<  \
                                                                            PrISM_Green_INV_OUT_SHIFT))
#define PrISM_Green_MODE_MASK                      ((uint32)(PrISM_Green_3BIT_MASK        <<  \
                                                                            PrISM_Green_MODE_SHIFT))

/* Shift constants for trigger control register 1 */
#define PrISM_Green_CAPTURE_SHIFT                  (0u)
#define PrISM_Green_COUNT_SHIFT                    (2u)
#define PrISM_Green_RELOAD_SHIFT                   (4u)
#define PrISM_Green_STOP_SHIFT                     (6u)
#define PrISM_Green_START_SHIFT                    (8u)

/* Mask constants for trigger control register 1 */
#define PrISM_Green_CAPTURE_MASK                   ((uint32)(PrISM_Green_2BIT_MASK        <<  \
                                                                  PrISM_Green_CAPTURE_SHIFT))
#define PrISM_Green_COUNT_MASK                     ((uint32)(PrISM_Green_2BIT_MASK        <<  \
                                                                  PrISM_Green_COUNT_SHIFT))
#define PrISM_Green_RELOAD_MASK                    ((uint32)(PrISM_Green_2BIT_MASK        <<  \
                                                                  PrISM_Green_RELOAD_SHIFT))
#define PrISM_Green_STOP_MASK                      ((uint32)(PrISM_Green_2BIT_MASK        <<  \
                                                                  PrISM_Green_STOP_SHIFT))
#define PrISM_Green_START_MASK                     ((uint32)(PrISM_Green_2BIT_MASK        <<  \
                                                                  PrISM_Green_START_SHIFT))

/* MASK */
#define PrISM_Green_1BIT_MASK                      ((uint32)0x01u)
#define PrISM_Green_2BIT_MASK                      ((uint32)0x03u)
#define PrISM_Green_3BIT_MASK                      ((uint32)0x07u)
#define PrISM_Green_6BIT_MASK                      ((uint32)0x3Fu)
#define PrISM_Green_8BIT_MASK                      ((uint32)0xFFu)
#define PrISM_Green_16BIT_MASK                     ((uint32)0xFFFFu)

/* Shift constant for status register */
#define PrISM_Green_RUNNING_STATUS_SHIFT           (30u)


/***************************************
*    Initial Constants
***************************************/

#define PrISM_Green_CTRL_QUAD_BASE_CONFIG                                                          \
        (((uint32)(PrISM_Green_QUAD_ENCODING_MODES     << PrISM_Green_QUAD_MODE_SHIFT))       |\
         ((uint32)(PrISM_Green_CONFIG                  << PrISM_Green_MODE_SHIFT)))

#define PrISM_Green_CTRL_PWM_BASE_CONFIG                                                           \
        (((uint32)(PrISM_Green_PWM_STOP_EVENT          << PrISM_Green_PWM_STOP_KILL_SHIFT))   |\
         ((uint32)(PrISM_Green_PWM_OUT_INVERT          << PrISM_Green_INV_OUT_SHIFT))         |\
         ((uint32)(PrISM_Green_PWM_OUT_N_INVERT        << PrISM_Green_INV_COMPL_OUT_SHIFT))   |\
         ((uint32)(PrISM_Green_PWM_MODE                << PrISM_Green_MODE_SHIFT)))

#define PrISM_Green_CTRL_PWM_RUN_MODE                                                              \
            ((uint32)(PrISM_Green_PWM_RUN_MODE         << PrISM_Green_ONESHOT_SHIFT))
            
#define PrISM_Green_CTRL_PWM_ALIGN                                                                 \
            ((uint32)(PrISM_Green_PWM_ALIGN            << PrISM_Green_UPDOWN_SHIFT))

#define PrISM_Green_CTRL_PWM_KILL_EVENT                                                            \
             ((uint32)(PrISM_Green_PWM_KILL_EVENT      << PrISM_Green_PWM_SYNC_KILL_SHIFT))

#define PrISM_Green_CTRL_PWM_DEAD_TIME_CYCLE                                                       \
            ((uint32)(PrISM_Green_PWM_DEAD_TIME_CYCLE  << PrISM_Green_PRESCALER_SHIFT))

#define PrISM_Green_CTRL_PWM_PRESCALER                                                             \
            ((uint32)(PrISM_Green_PWM_PRESCALER        << PrISM_Green_PRESCALER_SHIFT))

#define PrISM_Green_CTRL_TIMER_BASE_CONFIG                                                         \
        (((uint32)(PrISM_Green_TC_PRESCALER            << PrISM_Green_PRESCALER_SHIFT))       |\
         ((uint32)(PrISM_Green_TC_COUNTER_MODE         << PrISM_Green_UPDOWN_SHIFT))          |\
         ((uint32)(PrISM_Green_TC_RUN_MODE             << PrISM_Green_ONESHOT_SHIFT))         |\
         ((uint32)(PrISM_Green_TC_COMP_CAP_MODE        << PrISM_Green_MODE_SHIFT)))
        
#define PrISM_Green_QUAD_SIGNALS_MODES                                                             \
        (((uint32)(PrISM_Green_QUAD_PHIA_SIGNAL_MODE   << PrISM_Green_COUNT_SHIFT))           |\
         ((uint32)(PrISM_Green_QUAD_INDEX_SIGNAL_MODE  << PrISM_Green_RELOAD_SHIFT))          |\
         ((uint32)(PrISM_Green_QUAD_STOP_SIGNAL_MODE   << PrISM_Green_STOP_SHIFT))            |\
         ((uint32)(PrISM_Green_QUAD_PHIB_SIGNAL_MODE   << PrISM_Green_START_SHIFT)))

#define PrISM_Green_PWM_SIGNALS_MODES                                                              \
        (((uint32)(PrISM_Green_PWM_SWITCH_SIGNAL_MODE  << PrISM_Green_CAPTURE_SHIFT))         |\
         ((uint32)(PrISM_Green_PWM_COUNT_SIGNAL_MODE   << PrISM_Green_COUNT_SHIFT))           |\
         ((uint32)(PrISM_Green_PWM_RELOAD_SIGNAL_MODE  << PrISM_Green_RELOAD_SHIFT))          |\
         ((uint32)(PrISM_Green_PWM_STOP_SIGNAL_MODE    << PrISM_Green_STOP_SHIFT))            |\
         ((uint32)(PrISM_Green_PWM_START_SIGNAL_MODE   << PrISM_Green_START_SHIFT)))

#define PrISM_Green_TIMER_SIGNALS_MODES                                                            \
        (((uint32)(PrISM_Green_TC_CAPTURE_SIGNAL_MODE  << PrISM_Green_CAPTURE_SHIFT))         |\
         ((uint32)(PrISM_Green_TC_COUNT_SIGNAL_MODE    << PrISM_Green_COUNT_SHIFT))           |\
         ((uint32)(PrISM_Green_TC_RELOAD_SIGNAL_MODE   << PrISM_Green_RELOAD_SHIFT))          |\
         ((uint32)(PrISM_Green_TC_STOP_SIGNAL_MODE     << PrISM_Green_STOP_SHIFT))            |\
         ((uint32)(PrISM_Green_TC_START_SIGNAL_MODE    << PrISM_Green_START_SHIFT)))
        
#define PrISM_Green_TIMER_UPDOWN_CNT_USED                                                          \
                ((PrISM_Green__COUNT_UPDOWN0 == PrISM_Green_TC_COUNTER_MODE)                  ||\
                 (PrISM_Green__COUNT_UPDOWN1 == PrISM_Green_TC_COUNTER_MODE))

#define PrISM_Green_PWM_UPDOWN_CNT_USED                                                            \
                ((PrISM_Green__CENTER == PrISM_Green_PWM_ALIGN)                               ||\
                 (PrISM_Green__ASYMMETRIC == PrISM_Green_PWM_ALIGN))               
        
#define PrISM_Green_PWM_PR_INIT_VALUE              (1u)
#define PrISM_Green_QUAD_PERIOD_INIT_VALUE         (0x8000u)



#endif /* End CY_TCPWM_PrISM_Green_H */

/* [] END OF FILE */
